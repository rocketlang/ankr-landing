# Flow Canvas - Implementation TODO
## Complete Task List for Command Center Redesign

**Project:** WowTruck Flow Canvas
**Created:** January 12, 2026
**Target:** 6 Weeks

---

## Phase 1: Core Canvas Foundation (Week 1)

### 1.1 Project Setup
- [ ] Create `apps/wowtruck/frontend/src/pages/FlowCanvas.tsx`
- [ ] Create `apps/wowtruck/frontend/src/components/flow-canvas/` directory
- [ ] Create `apps/wowtruck/frontend/src/stores/flowCanvasStore.ts` (Zustand)
- [ ] Create `apps/wowtruck/frontend/src/hooks/useFlowCanvas.ts`
- [ ] Create `apps/wowtruck/frontend/src/types/flow-canvas.ts`
- [ ] Add route `/flow` or `/command-center` to App.tsx
- [ ] Install dependencies: `framer-motion`, `react-map-gl`, `zustand`

### 1.2 Pulse Bar Component
- [ ] Create `PulseBar.tsx` - Top KPI bar
- [ ] Create `KPITile.tsx` - Individual KPI tile
- [ ] Define KPI types: orders, trips, delays, revenue, alerts, fleet, drivers
- [ ] Add real-time subscription for KPI updates
- [ ] Add click handlers to open relevant floating panel
- [ ] Add trend indicators (up/down arrows)
- [ ] Add alert highlighting (red pulse for problems)
- [ ] Style: Glass morphism, dark theme compatible

### 1.3 Flow Lane Container
- [ ] Create `FlowLaneContainer.tsx` - Wrapper for all lanes
- [ ] Create `FlowLane.tsx` - Individual flow lane
- [ ] Create `StageTile.tsx` - Clickable stage tile
- [ ] Define flow types: Cargo, Finance, Doc, Ops, CRM
- [ ] Implement stage definitions for each flow
- [ ] Add item count badges on each stage
- [ ] Add drag-and-drop between stages (optional)
- [ ] Add lane collapse/expand functionality
- [ ] Add lane reordering (user preference)

### 1.4 GraphQL Integration
- [ ] Create `flowCanvasKPIs` query
- [ ] Create `flowStages` query
- [ ] Create `stageItems` query with pagination
- [ ] Create `flowCanvasUpdates` subscription
- [ ] Add Apollo cache updates for real-time data

---

## Phase 2: Floating Panel System (Week 2)

### 2.1 Floating Panel Core
- [ ] Create `FloatingPanel.tsx` - Right-side panel
- [ ] Create `PanelHeader.tsx` - Title, breadcrumb, close button
- [ ] Create `PanelBody.tsx` - Scrollable content area
- [ ] Create `PanelFooter.tsx` - Action buttons
- [ ] Implement slide-in/slide-out animations
- [ ] Add width options: 40%, 60%, 80%
- [ ] Add panel stacking (open panel within panel)
- [ ] Add breadcrumb navigation
- [ ] Add keyboard shortcuts (Escape to close)
- [ ] Add click-outside to close (optional)

### 2.2 Entity Detail Views
- [ ] Create `OrderDetail.tsx` - Order information panel
- [ ] Create `TripDetail.tsx` - Trip information panel
- [ ] Create `InvoiceDetail.tsx` - Invoice panel
- [ ] Create `CustomerDetail.tsx` - Customer panel
- [ ] Create `VehicleDetail.tsx` - Vehicle panel
- [ ] Create `DriverDetail.tsx` - Driver panel
- [ ] Create `QuoteDetail.tsx` - Quote panel
- [ ] Create `LeadDetail.tsx` - Lead panel
- [ ] Create `AlertDetail.tsx` - Alert panel

### 2.3 Quick Actions
- [ ] Create `QuickActions.tsx` - Contextual actions menu
- [ ] Define actions per entity type
- [ ] Implement action handlers (mutations)
- [ ] Add confirmation dialogs where needed
- [ ] Add success/error toasts
- [ ] Add keyboard shortcuts for common actions

### 2.4 Panel Animations
- [ ] Add Framer Motion for panel transitions
- [ ] Add staggered content fade-in
- [ ] Add skeleton loading states
- [ ] Add error boundary with retry

---

## Phase 3: Task Wizard (Week 3)

### 3.1 Wizard Core
- [ ] Create `TaskWizard.tsx` - Main wizard container
- [ ] Create `WizardTrigger.tsx` - FAB button (bottom-right)
- [ ] Create `WizardStep.tsx` - Individual step component
- [ ] Create `WizardProgress.tsx` - Step progress indicator
- [ ] Create `WizardNavigation.tsx` - Back/Next buttons
- [ ] Implement step validation
- [ ] Implement step state persistence
- [ ] Add keyboard navigation

### 3.2 Task Definitions
- [ ] Create `tasks/CreateOrderTask.ts` - 4 steps
- [ ] Create `tasks/DispatchTripTask.ts` - 3 steps
- [ ] Create `tasks/CreateInvoiceTask.ts` - 3 steps
- [ ] Create `tasks/RecordPaymentTask.ts` - 2 steps
- [ ] Create `tasks/GenerateEWayBillTask.ts` - 3 steps
- [ ] Create `tasks/UploadPODTask.ts` - 2 steps
- [ ] Create `tasks/AddVehicleTask.ts` - 4 steps
- [ ] Create `tasks/AddDriverTask.ts` - 4 steps
- [ ] Create `tasks/CreateQuoteTask.ts` - 3 steps
- [ ] Create `tasks/AddCustomerTask.ts` - 3 steps

### 3.3 Smart Forms
- [ ] Create `SmartCustomerSelect.tsx` - Search + recent
- [ ] Create `SmartVehicleSelect.tsx` - Available + suggested
- [ ] Create `SmartDriverSelect.tsx` - Available + nearby
- [ ] Create `SmartLocationInput.tsx` - Autocomplete + recent
- [ ] Create `SmartDatePicker.tsx` - Smart defaults
- [ ] Create `SmartAmountInput.tsx` - Calculator + split

### 3.4 Wizard UX
- [ ] Add task suggestions based on context
- [ ] Add recent tasks list
- [ ] Add task shortcuts (keyboard)
- [ ] Add task completion celebration
- [ ] Add undo for completed tasks

---

## Phase 4: Swayam AI Integration (Week 4)

### 4.1 AI Interface
- [ ] Create `SwayamAI.tsx` - Main AI component
- [ ] Create `VoiceInput.tsx` - Voice recording button
- [ ] Create `ChatHistory.tsx` - Conversation display
- [ ] Create `ActionSuggestions.tsx` - AI suggestions
- [ ] Create `SwayamAvatar.tsx` - Animated AI avatar

### 4.2 Voice Integration
- [ ] Integrate `@ankr/voice-ai` package
- [ ] Add Hindi language support
- [ ] Add wake word detection ("Hey Swayam")
- [ ] Add voice feedback (TTS responses)
- [ ] Add noise cancellation
- [ ] Add offline fallback (text input)

### 4.3 AI Backend
- [ ] Create AI intent parser endpoint
- [ ] Define intent types (create_order, track_vehicle, etc.)
- [ ] Create entity extraction logic
- [ ] Create action mapper (intent → mutation)
- [ ] Add conversation context management
- [ ] Add multi-turn conversation support

### 4.4 Command Library
- [ ] "Create order for [customer] from [origin] to [destination]"
- [ ] "Track vehicle [number]"
- [ ] "Show pending deliveries"
- [ ] "Send invoice to [customer]"
- [ ] "What's the status of order [number]?"
- [ ] "Assign nearest driver to trip [number]"
- [ ] "Generate E-Way Bill for order [number]"
- [ ] "Record payment of [amount] from [customer]"
- [ ] "Show today's summary"
- [ ] "Call driver [name]"

---

## Phase 5: Digital Twin Map (Week 5)

### 5.1 Map Core
- [ ] Create `DigitalTwinMap.tsx` - Main map component
- [ ] Create `MapMarker.tsx` - Base marker component
- [ ] Create `TruckMarker.tsx` - Vehicle marker with direction
- [ ] Create `OfficeMarker.tsx` - Branch/warehouse marker
- [ ] Create `PitstopMarker.tsx` - Pitstop marker
- [ ] Create `CustomerMarker.tsx` - Customer location marker
- [ ] Create `AlertMarker.tsx` - Alert marker (pulsing)
- [ ] Create `GeofencePolygon.tsx` - Geofence boundary

### 5.2 Map Layers
- [ ] Implement layer toggle controls
- [ ] Add fleet layer (trucks)
- [ ] Add infrastructure layer (offices, pitstops)
- [ ] Add routes layer (active trip paths)
- [ ] Add heatmap layer (delivery density)
- [ ] Add traffic layer (Google/Mapbox)
- [ ] Add weather overlay (optional)

### 5.3 Real-time Updates
- [ ] Subscribe to vehicle position updates
- [ ] Animate marker movements smoothly
- [ ] Add trail lines for recent path
- [ ] Add ETA recalculation
- [ ] Add geofence enter/exit alerts

### 5.4 Map Interactions
- [ ] Click marker → Open floating panel
- [ ] Click cluster → Zoom to bounds
- [ ] Draw geofence tool
- [ ] Search location
- [ ] Filter by status/branch/type
- [ ] Center on specific vehicle

### 5.5 Map Modes
- [ ] Mini-map mode (collapsed)
- [ ] Split view mode (50/50 with flows)
- [ ] Full map mode (100% width)
- [ ] 3D mode (future - Three.js)

### 5.6 Digital Twin Data
- [ ] Add vehicle telemetry display
- [ ] Add cargo condition indicators
- [ ] Add fuel level indicators
- [ ] Add driver status badges
- [ ] Add ETA countdown
- [ ] Add cost accumulator

---

## Phase 6: Role-Based Views (Week 5-6)

### 6.1 Role Configuration
- [ ] Create `roleConfigs.ts` - Role definitions
- [ ] Define visible flows per role
- [ ] Define quick actions per role
- [ ] Define default view per role
- [ ] Define permission mappings

### 6.2 Role Views
- [ ] Create Dispatcher view (Cargo + Ops focus)
- [ ] Create Accountant view (Finance + Doc focus)
- [ ] Create Fleet Manager view (Ops focus)
- [ ] Create Sales view (CRM + Cargo focus)
- [ ] Create Admin view (All flows)
- [ ] Create Customer view (My Orders + Invoices)

### 6.3 User Preferences
- [ ] Add flow lane ordering preference
- [ ] Add collapsed lanes preference
- [ ] Add default map view preference
- [ ] Add notification preferences
- [ ] Save preferences to localStorage/DB

---

## Phase 7: Mobile Optimization (Week 6)

### 7.1 Responsive Layout
- [ ] Add mobile breakpoints (<768px)
- [ ] Add tablet breakpoints (768-1280px)
- [ ] Convert floating panel to bottom sheet on mobile
- [ ] Convert flow lanes to swipeable cards on mobile
- [ ] Optimize map controls for touch

### 7.2 Mobile-Specific Features
- [ ] Add pull-to-refresh
- [ ] Add swipe gestures
- [ ] Add haptic feedback
- [ ] Add mobile-optimized wizard
- [ ] Add camera integration for POD

### 7.3 PWA Features
- [ ] Add service worker
- [ ] Add offline mode
- [ ] Add push notifications
- [ ] Add home screen install prompt

---

## Phase 8: Testing & Polish (Week 6)

### 8.1 Testing
- [ ] Add unit tests for stores
- [ ] Add component tests with React Testing Library
- [ ] Add E2E tests with Playwright
- [ ] Add visual regression tests
- [ ] Add performance benchmarks

### 8.2 Performance
- [ ] Implement virtualized lists for large datasets
- [ ] Add lazy loading for panel content
- [ ] Optimize re-renders with memo/useMemo
- [ ] Add Suspense boundaries
- [ ] Profile and fix memory leaks

### 8.3 Accessibility
- [ ] Add ARIA labels
- [ ] Add keyboard navigation
- [ ] Add screen reader support
- [ ] Add high contrast mode
- [ ] Test with accessibility tools

### 8.4 Polish
- [ ] Add loading skeletons
- [ ] Add empty states
- [ ] Add error boundaries
- [ ] Add success animations
- [ ] Add onboarding tour (first-time users)

---

## Backend Tasks

### GraphQL Schema
- [ ] Add `flowCanvasKPIs` query
- [ ] Add `flowStages(flow: FlowType!)` query
- [ ] Add `stageItems(flow, stage, limit)` query
- [ ] Add `moveToStage(entityId, targetStage)` mutation
- [ ] Add `flowCanvasUpdates` subscription
- [ ] Add `vehiclePositions` subscription
- [ ] Add `alertTriggered` subscription

### AI Endpoints
- [ ] Create `/api/swayam/intent` - Parse user intent
- [ ] Create `/api/swayam/execute` - Execute AI action
- [ ] Create `/api/swayam/suggest` - Get suggestions
- [ ] Create `/api/swayam/voice` - Voice transcription

### Real-time
- [ ] Add Socket.io room for flow canvas
- [ ] Emit `kpi:updated` events
- [ ] Emit `stage:changed` events
- [ ] Emit `vehicle:position` events
- [ ] Emit `alert:triggered` events

---

## Documentation

- [ ] Update CLAUDE.md with Flow Canvas info
- [ ] Create component documentation
- [ ] Create user guide
- [ ] Create video walkthrough
- [ ] Create keyboard shortcuts reference

---

## Definition of Done

Each task is complete when:
1. [ ] Code is written and compiles
2. [ ] Unit tests pass
3. [ ] Component renders correctly
4. [ ] Works on desktop and mobile
5. [ ] Keyboard accessible
6. [ ] No console errors
7. [ ] PR reviewed and merged

---

## Priority Legend

| Priority | Description |
|----------|-------------|
| 🔴 P0 | Must have for MVP |
| 🟠 P1 | Should have |
| 🟡 P2 | Nice to have |
| 🟢 P3 | Future enhancement |

---

## Quick Start Tomorrow

```bash
# Start here:
cd apps/wowtruck/frontend

# Create the main Flow Canvas page
touch src/pages/FlowCanvas.tsx

# Create the component directory
mkdir -p src/components/flow-canvas

# Create the store
touch src/stores/flowCanvasStore.ts

# Start the dev server
npm run dev
```

---

## Notes

- Use existing WowTruck theme/colors
- Reference FreightBox frontend for tile patterns
- Swayam AI integration via @ankr/ai-router
- Map tiles from Mapbox (free tier: 50k loads/month)
- Socket.io already configured in backend

---

*Jai GuruJi! Shree Ganesh!*
*Let's build something amazing tomorrow!*
