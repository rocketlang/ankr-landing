# Flow Canvas - Command Center Redesign
## Project Report v1.0

**Project:** WowTruck Flow Canvas - Single Screen Command Center
**Date:** January 12, 2026
**Author:** ANKR Labs
**Status:** Planning Complete, Ready for Development

---

## Executive Summary

This project transforms WowTruck's 60+ screen application into a **single-screen Flow Canvas** that any user - even a 5-year-old - can operate intuitively. The redesign introduces flow-based navigation, floating panels, a task wizard, and Swayam AI integration for voice commands.

### Key Metrics (Target)
| Metric | Current | Target |
|--------|---------|--------|
| Number of Screens | 60+ | 1 (with floating panels) |
| Training Time | 2-3 days | 15 minutes |
| Clicks to Complete Order | 12-15 | 3-4 |
| Voice Command Support | None | 100% coverage |
| Mobile-Desktop Sync | Partial | Real-time |

---

## 1. Problem Statement

### Current Pain Points
1. **Navigation Complexity**: Users must remember 60+ screen locations
2. **Context Switching**: Lose context when navigating between pages
3. **Training Overhead**: New users need extensive training
4. **Mobile Disconnect**: Driver app and web app feel disconnected
5. **No AI Assistance**: Users must know exactly what to do
6. **Multi-step Tasks**: Simple tasks require visiting multiple screens

### User Quotes
> "I can never remember where the E-Way Bill screen is" - Accountant
> "Creating an order takes too many clicks" - Dispatcher
> "I wish I could just tell the system what I want" - Fleet Manager

---

## 2. Solution: Flow Canvas Architecture

### 2.1 Core Concept
Replace traditional menu navigation with **Flow-Based Lanes** where users see their work organized by business process, not by feature.

```
┌─────────────────────────────────────────────────────────────────┐
│                         FLOW CANVAS                             │
├─────────────────────────────────────────────────────────────────┤
│  [PULSE BAR] - Live KPIs always visible                        │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│  FLOW LANES (Horizontal swimlanes)                              │
│  ┌─────────────────────────────────────────────────────────┐   │
│  │ 📦 CARGO:  [Quote]→[Order]→[Dispatch]→[Transit]→[POD]  │   │
│  │ 💰 FINANCE:[Invoice]→[Send]→[Collect]→[Reconcile]      │   │
│  │ 📄 DOC:    [LR]→[E-Invoice]→[E-WayBill]→[Archive]      │   │
│  │ 🚛 OPS:    [Fleet]→[Drivers]→[Assign]→[Track]          │   │
│  │ 👥 CRM:    [Lead]→[Contact]→[Qualify]→[Convert]        │   │
│  └─────────────────────────────────────────────────────────┘   │
│                                                                 │
│  [FLOATING PANEL] - Details open here, never navigate away     │
│  [TASK WIZARD] - Step-by-step guidance                         │
│  [SWAYAM AI] - Voice + Chat assistance                         │
│                                                                 │
└─────────────────────────────────────────────────────────────────┘
```

### 2.2 Component Hierarchy

```
FlowCanvas (Root)
├── PulseBar
│   └── KPITile[] (orders, trips, revenue, alerts, etc.)
├── FlowLaneContainer
│   └── FlowLane[] (Cargo, Finance, Doc, Ops, CRM)
│       └── StageTile[] (clickable stage tiles)
├── FloatingPanel
│   ├── PanelHeader (breadcrumb, close)
│   ├── EntityDetail (order, invoice, etc.)
│   └── QuickActions (contextual actions)
├── TaskWizard
│   ├── WizardTrigger (FAB button)
│   └── WizardSteps (step-by-step forms)
└── SwayamAI
    ├── VoiceInput
    ├── ChatHistory
    └── ActionSuggestions
```

---

## 3. The Six Core Flows

### 3.1 Cargo Flow (Order Lifecycle)
**Users:** Dispatcher, Customer, Operations Manager

| Stage | Description | Actions |
|-------|-------------|---------|
| Quote | Rate inquiry, estimation | Create quote, send to customer |
| Order | Confirmed booking | Create order, assign vehicle |
| Dispatch | Trip assigned, ready to go | Generate LR, E-Way Bill |
| In-Transit | Vehicle on the road | Track, update status, alerts |
| Delivered | Reached destination | Upload POD, confirm delivery |

### 3.2 Finance Flow (Invoice to Cash)
**Users:** Accountant, Finance Manager, Customer

| Stage | Description | Actions |
|-------|-------------|---------|
| Invoice | Bill generated | Create invoice, add line items |
| Sent | Invoice delivered | Send email/WhatsApp, track open |
| Partial | Partial payment received | Record payment, update balance |
| Paid | Fully paid | Mark complete, generate receipt |
| Reconcile | Bank matching | Match transactions, close books |

### 3.3 Document Flow (Compliance)
**Users:** Operations, Compliance Officer

| Stage | Description | Actions |
|-------|-------------|---------|
| LR | Lorry Receipt | Generate LR, print |
| E-Invoice | GST E-Invoice | Submit to NIC, get IRN |
| E-Way Bill | Transport permit | Generate EWB, validate |
| POD | Proof of Delivery | Upload signature, photos |
| Archive | Document storage | Search, download, share |

### 3.4 Operations Flow (Fleet Management)
**Users:** Fleet Manager, Operations Head

| Stage | Description | Actions |
|-------|-------------|---------|
| Fleet | Vehicle inventory | View status, maintenance alerts |
| Drivers | Driver management | Availability, documents, ratings |
| Assign | Trip assignment | Match vehicle-driver-order |
| Track | Live monitoring | GPS, geofence, ETA |
| Alerts | Exceptions | Delays, breakdowns, SOS |

### 3.5 CRM Flow (Customer Lifecycle)
**Users:** Sales Team, Account Managers

| Stage | Description | Actions |
|-------|-------------|---------|
| Lead | New inquiry | Capture, assign, schedule |
| Contact | Outreach | Call, email, WhatsApp |
| Qualify | Assessment | Requirements, budget, timeline |
| Convert | Deal closed | Create customer, first order |
| Retain | Ongoing relationship | Reviews, feedback, upsell |

### 3.6 Analytics Flow (Insights)
**Users:** Management, Business Analyst

| Stage | Description | Actions |
|-------|-------------|---------|
| Dashboard | High-level KPIs | View, filter, compare |
| Drill | Detailed analysis | Click-through, breakdown |
| Compare | Period comparison | MoM, YoY, benchmarks |
| Export | Data extraction | Excel, PDF, API |
| Share | Distribution | Email, schedule, embed |

---

## 4. Key Components

### 4.1 Pulse Bar (Top KPIs)
Always visible, real-time metrics:

```typescript
interface PulseKPI {
  id: string;
  label: string;
  value: number | string;
  trend?: 'up' | 'down' | 'stable';
  alert?: boolean;
  onClick?: () => void;
}

// Default KPIs
const defaultKPIs: PulseKPI[] = [
  { id: 'orders', label: 'Orders', value: 47 },
  { id: 'trips', label: 'Active Trips', value: 12 },
  { id: 'delays', label: 'Delays', value: 3, alert: true },
  { id: 'revenue', label: 'Today', value: '₹2.4L' },
  { id: 'pending', label: 'Pending POD', value: 8 },
  { id: 'fleet', label: 'Fleet', value: '156/180' },
  { id: 'drivers', label: 'Available', value: 23 },
];
```

### 4.2 Floating Panel (Tethered Details)
Opens on right side, never navigates away:

```typescript
interface FloatingPanel {
  isOpen: boolean;
  width: '40%' | '60%' | '80%';
  entity: Entity | null;
  breadcrumb: string[];

  // Nested navigation within panel
  pushView: (view: PanelView) => void;
  popView: () => void;
  close: () => void;
}

interface PanelView {
  title: string;
  component: React.ComponentType;
  props: Record<string, any>;
}
```

### 4.3 Task Wizard (Guided Workflows)
Step-by-step guidance for complex tasks:

```typescript
interface TaskWizard {
  isOpen: boolean;
  currentTask: Task | null;
  currentStep: number;

  // Available tasks
  tasks: Task[];

  // Actions
  startTask: (taskId: string) => void;
  nextStep: () => void;
  prevStep: () => void;
  complete: () => void;
  cancel: () => void;
}

interface Task {
  id: string;
  name: string;
  icon: IconType;
  steps: WizardStep[];
  onComplete: (data: any) => Promise<void>;
}

// Top 10 Wizard Tasks
const wizardTasks: Task[] = [
  { id: 'new-order', name: 'Create New Order', steps: [...] },
  { id: 'dispatch-trip', name: 'Dispatch Trip', steps: [...] },
  { id: 'create-invoice', name: 'Create Invoice', steps: [...] },
  { id: 'record-payment', name: 'Record Payment', steps: [...] },
  { id: 'generate-ewb', name: 'Generate E-Way Bill', steps: [...] },
  { id: 'upload-pod', name: 'Upload POD', steps: [...] },
  { id: 'add-vehicle', name: 'Add Vehicle', steps: [...] },
  { id: 'add-driver', name: 'Add Driver', steps: [...] },
  { id: 'create-quote', name: 'Create Quote', steps: [...] },
  { id: 'add-customer', name: 'Add Customer', steps: [...] },
];
```

### 4.4 Swayam AI (Voice + Chat)
Natural language interface:

```typescript
interface SwayamAI {
  isListening: boolean;
  transcript: string;
  response: AIResponse | null;

  // Voice commands
  startListening: () => void;
  stopListening: () => void;

  // Chat
  sendMessage: (text: string) => Promise<AIResponse>;

  // Suggestions
  suggestions: ActionSuggestion[];
}

// Sample voice commands
const voiceCommands = [
  "Create order for ABC Corp, Mumbai to Delhi, 10 tons",
  "Show today's pending deliveries",
  "Track vehicle MH-12-AB-1234",
  "Send invoice to XYZ Ltd",
  "What's the status of order 12345?",
  "Assign nearest driver to trip T-567",
];
```

---

## 5. Role-Based Views

### 5.1 Role Configuration

| Role | Visible Flows | Primary Actions | Dashboard Focus |
|------|---------------|-----------------|-----------------|
| **admin** | All | All | Overview |
| **dispatcher** | Cargo, Ops | Order, Dispatch, Track | Pending Orders |
| **accountant** | Finance, Doc | Invoice, Payment | Receivables |
| **fleet_manager** | Ops | Fleet, Drivers, Assign | Vehicle Status |
| **sales** | CRM, Cargo | Lead, Quote | Pipeline |
| **driver** | Ops (mobile) | Trip, POD | My Day |
| **customer** | Cargo, Finance | Track, Pay | My Orders |

### 5.2 Implementation

```typescript
interface RoleConfig {
  role: string;
  visibleFlows: string[];
  quickActions: string[];
  defaultView: string;
  permissions: Permission[];
}

const roleConfigs: Record<string, RoleConfig> = {
  dispatcher: {
    role: 'dispatcher',
    visibleFlows: ['cargo', 'ops'],
    quickActions: ['new-order', 'dispatch-trip', 'track'],
    defaultView: 'cargo',
    permissions: ['orders:*', 'trips:*', 'vehicles:read'],
  },
  // ... other roles
};
```

---

## 6. Technical Architecture

### 6.1 State Management

```typescript
// Zustand store for Flow Canvas
interface FlowCanvasStore {
  // Pulse Bar
  kpis: PulseKPI[];
  refreshKPIs: () => Promise<void>;

  // Flow Lanes
  flows: Flow[];
  activeFlow: string | null;
  setActiveFlow: (flowId: string) => void;

  // Floating Panel
  panel: FloatingPanelState;
  openPanel: (entity: Entity) => void;
  closePanel: () => void;

  // Task Wizard
  wizard: TaskWizardState;
  startWizard: (taskId: string) => void;

  // Swayam AI
  ai: SwayamAIState;
}
```

### 6.2 GraphQL Subscriptions (Real-time)

```graphql
subscription FlowCanvasUpdates {
  orderStatusChanged { id status }
  tripPositionUpdated { id lat lng }
  paymentReceived { invoiceId amount }
  alertTriggered { type message severity }
}
```

### 6.3 File Structure

```
apps/wowtruck/frontend/src/
├── pages/
│   └── FlowCanvas.tsx              # Main single-page app
├── components/
│   └── flow-canvas/
│       ├── index.ts
│       ├── FlowCanvas.tsx          # Root component
│       ├── PulseBar.tsx            # Top KPI bar
│       ├── FlowLaneContainer.tsx   # Flow lanes wrapper
│       ├── FlowLane.tsx            # Individual flow lane
│       ├── StageTile.tsx           # Clickable stage tile
│       ├── FloatingPanel.tsx       # Right-side detail panel
│       ├── TaskWizard.tsx          # Step-by-step wizard
│       ├── SwayamAI.tsx            # AI assistant
│       └── QuickActions.tsx        # Context menu actions
├── stores/
│   └── flowCanvasStore.ts          # Zustand state
├── hooks/
│   ├── useFlowCanvas.ts
│   ├── useFloatingPanel.ts
│   ├── useTaskWizard.ts
│   └── useSwayamAI.ts
└── types/
    └── flow-canvas.ts              # TypeScript types
```

---

## 7. UI/UX Specifications

### 7.1 Color Scheme

| Element | Color | Usage |
|---------|-------|-------|
| Cargo Flow | `#3B82F6` (Blue) | Order-related tiles |
| Finance Flow | `#10B981` (Green) | Money-related tiles |
| Doc Flow | `#F59E0B` (Amber) | Document tiles |
| Ops Flow | `#8B5CF6` (Purple) | Fleet/driver tiles |
| CRM Flow | `#EC4899` (Pink) | Customer tiles |
| Alert | `#EF4444` (Red) | Problems, delays |
| Success | `#22C55E` (Green) | Completed, paid |
| Warning | `#F59E0B` (Yellow) | Attention needed |

### 7.2 Typography

| Element | Font | Size | Weight |
|---------|------|------|--------|
| KPI Value | Inter | 24px | Bold |
| KPI Label | Inter | 12px | Medium |
| Stage Label | Inter | 14px | Semibold |
| Stage Count | Inter | 20px | Bold |
| Panel Title | Inter | 18px | Semibold |
| Body Text | Inter | 14px | Regular |

### 7.3 Spacing

| Element | Spacing |
|---------|---------|
| Pulse Bar Height | 80px |
| Flow Lane Height | 100px |
| Stage Tile Width | 120px |
| Panel Width | 40% (expandable to 60%, 80%) |
| Wizard Width | 400px |
| Gap between tiles | 16px |

### 7.4 Animations

| Interaction | Animation |
|-------------|-----------|
| Panel Open | Slide in from right (300ms) |
| Panel Close | Slide out to right (200ms) |
| Wizard Open | Scale up + fade (200ms) |
| Tile Hover | Scale 1.02 + shadow (100ms) |
| KPI Update | Number tick animation |
| Stage Count Change | Pulse effect |

---

## 8. Integration Points

### 8.1 Backend GraphQL

```graphql
# New queries for Flow Canvas
type Query {
  flowCanvasKPIs: FlowCanvasKPIs!
  flowStages(flow: FlowType!): [FlowStage!]!
  stageItems(flow: FlowType!, stage: String!, limit: Int): [Entity!]!
}

type FlowCanvasKPIs {
  ordersToday: Int!
  activeTrips: Int!
  delayedTrips: Int!
  todayRevenue: Float!
  pendingPODs: Int!
  fleetUtilization: String!
  availableDrivers: Int!
  alerts: Int!
}

type FlowStage {
  id: String!
  label: String!
  count: Int!
  items: [Entity!]!
}
```

### 8.2 Swayam AI API

```typescript
// AI Proxy integration
interface SwayamRequest {
  command: string;
  context: {
    currentFlow: string;
    selectedEntity?: Entity;
    userRole: string;
  };
}

interface SwayamResponse {
  intent: string;          // 'create_order', 'track_vehicle', etc.
  entities: Record<string, any>;
  action: {
    type: 'mutation' | 'query' | 'navigation';
    payload: any;
  };
  response: string;        // Natural language response
  suggestions: string[];   // Follow-up actions
}
```

### 8.3 Real-time Updates (WebSocket)

```typescript
// Socket.io events
const socketEvents = {
  'order:created': (order) => updateFlowStage('cargo', 'order'),
  'order:status': (data) => moveEntityBetweenStages(data),
  'trip:position': (pos) => updateMapMarker(pos),
  'payment:received': (payment) => updateFinanceFlow(payment),
  'alert:triggered': (alert) => showAlertNotification(alert),
};
```

---

## 9. Mobile Considerations

### 9.1 Responsive Breakpoints

| Breakpoint | Layout |
|------------|--------|
| Desktop (>1280px) | Full Flow Canvas with side panel |
| Tablet (768-1280px) | Stacked flows, full-screen panel |
| Mobile (<768px) | Single flow view, bottom sheet panel |

### 9.2 Driver App Sync

```typescript
// Driver actions sync to Flow Canvas
const driverActions = [
  'trip:started',      // Move to In-Transit
  'trip:completed',    // Move to Delivered
  'pod:uploaded',      // Update POD stage
  'location:updated',  // Real-time tracking
  'issue:reported',    // Create alert
];
```

---

## 10. Success Metrics

### 10.1 User Experience

| Metric | Current | Target | Measurement |
|--------|---------|--------|-------------|
| Task Completion Time | 5 min | 1 min | Timer from start to finish |
| Clicks per Task | 12 | 3 | Click tracking |
| Error Rate | 15% | 2% | Failed submissions |
| User Satisfaction | 3.2/5 | 4.5/5 | Survey |
| Training Time | 2 days | 15 min | Onboarding completion |

### 10.2 Technical

| Metric | Target | Measurement |
|--------|--------|-------------|
| Page Load Time | <2s | Lighthouse |
| Time to Interactive | <3s | Web Vitals |
| Real-time Latency | <500ms | Socket ping |
| API Response Time | <200ms | Backend metrics |

---

## 11. Risks & Mitigations

| Risk | Impact | Likelihood | Mitigation |
|------|--------|------------|------------|
| Learning curve for existing users | Medium | High | Parallel access to old UI for 30 days |
| Performance with many entities | High | Medium | Virtual scrolling, pagination |
| Voice recognition accuracy | Medium | Medium | Fallback to text, confirmation |
| Real-time sync failures | High | Low | Optimistic updates, retry logic |
| Mobile network issues | Medium | High | Offline mode, queue actions |

---

## 12. Timeline Estimate

| Phase | Duration | Deliverables |
|-------|----------|--------------|
| Phase 1: Core Canvas | 1 week | FlowCanvas, PulseBar, FlowLanes |
| Phase 2: Floating Panel | 1 week | Panel, EntityDetails, QuickActions |
| Phase 3: Task Wizard | 1 week | Wizard, Top 10 tasks |
| Phase 4: Swayam AI | 1 week | Voice input, AI integration |
| Phase 5: Role Views | 3 days | Role configs, permissions |
| Phase 6: Mobile Optimization | 3 days | Responsive, Driver sync |
| Phase 7: Testing & Polish | 1 week | QA, performance, UX refinement |
| **Total** | **~6 weeks** | Full Flow Canvas |

---

## 13. Live Map Component

### 13.1 Interactive Map View
The Flow Canvas includes an expandable live map showing all assets in real-time:

```
┌─────────────────────────────────────────────────────────────────────────────┐
│  🗺️ LIVE MAP (Click to expand, click markers to open details)              │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                             │
│    ┌─────────────────────────────────────────────────────────────────────┐ │
│    │                                                                     │ │
│    │         🏢 Delhi HQ                                                │ │
│    │            ↑                                                        │ │
│    │       🚛 MH-12-AB-1234                                             │ │
│    │       [In Transit → Delhi]                     🏢 Jaipur Branch    │ │
│    │            ↑                                        │               │ │
│    │            │                                   ⛽ Pitstop          │ │
│    │       🚛 MH-15-CD-5678                              │               │ │
│    │       [Loading at Mumbai]                           │               │ │
│    │            │                                        │               │ │
│    │    🏢 Mumbai HQ ─────────────────────────────────────              │ │
│    │                                                                     │ │
│    │    Legend: 🚛 Truck  🏢 Office  ⛽ Pitstop  ⚠️ Alert              │ │
│    │                                                                     │ │
│    └─────────────────────────────────────────────────────────────────────┘ │
│                                                                             │
│    [🔍 Zoom] [📍 Center] [🚛 Trucks] [🏢 Offices] [⛽ Pitstops] [📊 Heat] │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

### 13.2 Map Marker Types

| Marker | Icon | Click Action | Info Popup |
|--------|------|--------------|------------|
| **Truck** | 🚛 | Open vehicle panel | Driver, Trip, ETA, Status |
| **Office/Branch** | 🏢 | Open branch panel | Staff, Orders, Revenue |
| **Pitstop** | ⛽ | Open pitstop info | Fuel, Rest, Services |
| **Customer** | 📍 | Open customer panel | Orders, Contact, Balance |
| **Alert** | ⚠️ | Open alert panel | Issue, Severity, Actions |
| **Geofence** | 🔵 | Show boundary | Entry/Exit logs |

### 13.3 Map Interactions

```typescript
interface MapComponent {
  // View state
  center: [number, number];
  zoom: number;
  bounds: LatLngBounds;

  // Markers
  trucks: TruckMarker[];
  offices: OfficeMarker[];
  pitstops: PitstopMarker[];
  customers: CustomerMarker[];
  alerts: AlertMarker[];
  geofences: GeofencePolygon[];

  // Layers (toggleable)
  layers: {
    trucks: boolean;
    offices: boolean;
    pitstops: boolean;
    heatmap: boolean;
    routes: boolean;
    geofences: boolean;
  };

  // Actions
  onMarkerClick: (marker: Marker) => void;  // Opens floating panel
  onClusterClick: (cluster: Cluster) => void;
  onGeofenceEnter: (vehicle: Vehicle, geofence: Geofence) => void;
  onZoomChange: (zoom: number) => void;
}

interface TruckMarker {
  id: string;
  vehicleNumber: string;
  position: [number, number];
  heading: number;           // Direction arrow
  status: 'moving' | 'stopped' | 'idle' | 'offline';
  speed: number;
  driver: { name: string; phone: string };
  currentTrip?: {
    origin: string;
    destination: string;
    eta: Date;
    progress: number;       // 0-100%
  };
}
```

### 13.4 Map Features

| Feature | Description |
|---------|-------------|
| **Cluster Zoom** | Click cluster → Zooms to show individual markers |
| **Route Lines** | Show active trip routes with progress |
| **Heatmap Mode** | Density visualization of deliveries/pickups |
| **Geofence Alerts** | Visual boundaries, entry/exit notifications |
| **Traffic Layer** | Optional traffic overlay for ETA accuracy |
| **Search** | Search by vehicle, driver, location |
| **Filter** | Filter by status, branch, vehicle type |

### 13.5 Map Integration with Flow Canvas

```
┌─────────────────────────────────────────────────────────────────────────────┐
│  FLOW CANVAS                                                                │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                             │
│  ┌──────────────────────────────┐  ┌──────────────────────────────────────┐ │
│  │  FLOW LANES                   │  │  LIVE MAP (Collapsed/Expanded)       │ │
│  │  ┌────────────────────────┐  │  │                                      │ │
│  │  │ 📦 CARGO FLOW          │  │  │  🗺️ [Click to expand]               │ │
│  │  │ [Quote]→[Order]→[...]  │  │  │  ┌────────────────────────────────┐ │ │
│  │  └────────────────────────┘  │  │  │     Mini-map preview           │ │ │
│  │                              │  │  │     🚛 🚛 🏢 🚛                 │ │ │
│  │  ┌────────────────────────┐  │  │  └────────────────────────────────┘ │ │
│  │  │ 🚛 OPS FLOW            │  │  │                                      │ │
│  │  │ [Fleet]→[Track]→[...]  │──┼──│  Click "Track" → Expands map        │ │
│  │  └────────────────────────┘  │  │                                      │ │
│  │                              │  │                                      │ │
│  └──────────────────────────────┘  └──────────────────────────────────────┘ │
│                                                                             │
│                              OR (Expanded Map Mode)                         │
│                                                                             │
│  ┌──────────────────────────────────────────────────────────────────────┐  │
│  │                         FULL MAP VIEW                                 │  │
│  │  ┌────────────────────────────────────────────────────────────────┐  │  │
│  │  │                                                                │  │  │
│  │  │                    🏢                                          │  │  │
│  │  │                     ↑                                          │  │  │
│  │  │              🚛━━━━━━━                                         │  │  │
│  │  │             ╱                                                  │  │  │
│  │  │        🚛━━╱                        Click on 🚛                │  │  │
│  │  │       ╱                                  ↓                     │  │  │
│  │  │  🏢━━╱                             Opens Panel →              │  │  │
│  │  │                                                                │  │  │
│  │  └────────────────────────────────────────────────────────────────┘  │  │
│  │  [← Collapse] [Trucks: 45] [Moving: 32] [Stopped: 8] [Alerts: 3]    │  │
│  └──────────────────────────────────────────────────────────────────────┘  │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

### 13.6 Digital Twin Concept

The map is not just a tracker - it's a **Digital Twin** of your entire logistics operation:

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                         🌐 DIGITAL TWIN MAP                                 │
│              Real-time virtual replica of your logistics network            │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                             │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │                                                                     │   │
│  │   🏭 Warehouse Delhi                    [Live Inventory: 450 tons]  │   │
│  │   ├── 🚛 Bay 1: Loading (MH-12-AB-1234)  ████████░░ 80%            │   │
│  │   ├── 🚛 Bay 2: Empty                                               │   │
│  │   └── 🚛 Bay 3: Unloading (DL-05-CD-5678) ██████████ Done!         │   │
│  │                           │                                         │   │
│  │                           │ Route: NH-48                            │   │
│  │                           │ Distance: 1,450 km                      │   │
│  │                           │ Traffic: 🟢 Clear                       │   │
│  │                           ↓                                         │   │
│  │                    🚛 MH-12-AB-1234                                 │   │
│  │                    [In Transit]                                     │   │
│  │                    Speed: 62 km/h                                   │   │
│  │                    ETA: 14:30                                       │   │
│  │                    Driver: Ramesh (📞)                              │   │
│  │                    Fuel: ████████░░ 78%                             │   │
│  │                    Temp: 4°C ✓ (Cold Chain)                         │   │
│  │                           │                                         │   │
│  │                           ↓                                         │   │
│  │                    ⛽ Pitstop Jaipur                                │   │
│  │                    [Scheduled Break: 12:00]                         │   │
│  │                    Services: Fuel, Food, Rest                       │   │
│  │                           │                                         │   │
│  │                           ↓                                         │   │
│  │   🏢 Customer: ABC Corp Mumbai           [Expecting: 2:30 PM]      │   │
│  │   └── Dock 3 Reserved                                               │   │
│  │                                                                     │   │
│  └─────────────────────────────────────────────────────────────────────┘   │
│                                                                             │
│  DIGITAL TWIN LAYERS:                                                       │
│  ┌─────┐ ┌─────┐ ┌─────┐ ┌─────┐ ┌─────┐ ┌─────┐ ┌─────┐ ┌─────┐         │
│  │Fleet│ │Route│ │Cargo│ │Temp │ │Fuel │ │Time │ │Money│ │Alert│         │
│  │ 🚛  │ │ 🛣️  │ │ 📦  │ │ 🌡️  │ │ ⛽  │ │ ⏱️  │ │ 💰  │ │ ⚠️  │         │
│  └─────┘ └─────┘ └─────┘ └─────┘ └─────┘ └─────┘ └─────┘ └─────┘         │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

#### Digital Twin Features

| Feature | Description | Data Source |
|---------|-------------|-------------|
| **Live Vehicle State** | Position, speed, direction, status | GPS Tracker |
| **Cargo Condition** | Temperature, humidity, shock sensors | IoT Sensors |
| **Fuel Level** | Real-time fuel monitoring | OBD-II / FMS |
| **Driver Status** | Driving hours, rest periods, alerts | Driver App |
| **Route Progress** | Completed %, ETA, delays | GPS + Traffic API |
| **Warehouse Bays** | Loading/unloading status | Dock Management |
| **Inventory Flow** | What's moving where | WMS Integration |
| **Cost Accumulation** | Running cost per trip | Finance System |
| **Document Status** | LR, E-Invoice, E-Way Bill | Doc Management |
| **Customer Visibility** | Shared tracking links | Customer Portal |

#### Predictive Capabilities

```typescript
interface DigitalTwinPredictions {
  // ETA Prediction
  predictedArrival: Date;
  confidenceLevel: number;       // 0-100%
  delayRisk: 'low' | 'medium' | 'high';
  delayReasons: string[];        // Traffic, weather, driver break

  // Maintenance Prediction
  nextServiceDue: Date;
  componentHealth: {
    engine: number;              // 0-100%
    brakes: number;
    tires: number;
    battery: number;
  };

  // Cost Prediction
  estimatedTripCost: number;
  costBreakdown: {
    fuel: number;
    toll: number;
    driver: number;
    maintenance: number;
  };

  // Risk Assessment
  riskScore: number;             // 0-100
  riskFactors: string[];         // Weather, route, driver fatigue
}
```

#### 3D Visualization (Future)

```
┌─────────────────────────────────────────────────────────────────┐
│                    🌐 3D DIGITAL TWIN (Future)                  │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│         ╱─────────╲                                            │
│        ╱  DELHI    ╲                                           │
│       ╱   WAREHOUSE ╲         🚛 ← 3D Truck Model              │
│      ╱_______________╲         │  with real-time orientation   │
│           │                    │                                │
│           │ ← Animated route   │                                │
│           ↓   with traffic     │                                │
│        ═══════════════════════╪════                            │
│                               │                                 │
│                          ╱────────╲                            │
│                         ╱ CUSTOMER ╲                           │
│                        ╱____________╲                          │
│                                                                 │
│  [2D] [3D] [Satellite] [Traffic] [Weather]                     │
│                                                                 │
└─────────────────────────────────────────────────────────────────┘
```

### 13.7 Map Technology Stack

| Layer | Technology |
|-------|------------|
| Map Tiles | Mapbox GL / OpenStreetMap |
| Markers | React-Map-GL / Deck.gl |
| Clustering | Supercluster |
| Real-time Updates | Socket.io |
| Geofencing | Turf.js |
| Routing | OSRM / Mapbox Directions |
| 3D Rendering | Three.js / Deck.gl |
| IoT Data | MQTT / WebSocket |
| Predictions | TensorFlow.js / ML API |

---

## 14. Dependencies

### 13.1 External
- `@ankr/ai-router` - LLM routing for Swayam
- `@ankr/voice-ai` - Voice recognition
- Socket.io - Real-time updates
- Framer Motion - Animations

### 13.2 Internal
- WowTruck Backend GraphQL - Flow data queries
- Swayam AI Proxy - Natural language processing
- Driver App - Real-time position updates

---

## 14. Appendix

### A. Wireframe Links
- Figma: [To be created]
- Prototype: [To be created]

### B. Related Documents
- [FLOW-CANVAS-TODO.md](./FLOW-CANVAS-TODO.md) - Implementation tasks
- [HRMS-PROJECT-REPORT.md](./HRMS-PROJECT-REPORT.md) - HRMS integration

### C. Reference Implementations
- Notion - Block-based UI
- Linear - Issue flow lanes
- Airtable - Kanban views
- Superhuman - Keyboard-first, fast

---

**Document Version:** 1.0
**Last Updated:** January 12, 2026
**Next Review:** Before Phase 1 start

---

*Jai GuruJi! Shree Ganesh!*
*ANKR Labs - Building the future of logistics*
