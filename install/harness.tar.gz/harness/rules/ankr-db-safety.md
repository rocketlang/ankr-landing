---
paths:
  - "**/prisma/**"
  - "**/migrations/**"
  - "**/*.sql"
  - "**/drizzle/**"
  - "**/schema.*"
---

# ANKR rule — database safety

A database with data in it is the owner's memory. It only ever grows by addition.

- **Refused by the guard hook:** `prisma db push`, `prisma migrate reset`, `DROP TABLE`, `DROP DATABASE`, `DROP SCHEMA`, `TRUNCATE`.
- **Additive only:** new tables, new nullable columns, new indexes, new rows. A column that must change type gets a new column and a copy step, never an in-place change.
- **Before any migration:** generate it, open it, and tell the owner in plain English what every statement does. If any line drops, renames, truncates or alters a column, stop and write the additive alternative.
- **Backups:** before touching a schema, ask where the last backup is. If the answer is "none", make one first (`pg_dump`, `mysqldump`, `sqlite3 .backup`, or a copy of the file) and show its size.
- **Local throwaway databases** (a fresh SQLite file, a dev container with seed data only) may be reset — say that this is the case and why you know it, then proceed.
