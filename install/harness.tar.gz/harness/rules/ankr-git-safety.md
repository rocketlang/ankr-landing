# ANKR rule — git safety (always on)

The guard hook at `~/.claude/ankr/hooks/ankr-guard.sh` refuses these commands with the reason. Do not work around it and do not ask the owner to disable it.

| Refused | Why | Do this instead |
|---|---|---|
| `git add .` · `git add -A` · `git add --all` · `git add -u` | sweeps in files you did not mean to commit (keys, junk, someone else's work) | `git add path/one path/two` |
| `git stash` | hides uncommitted work where a novice never finds it again | commit on a branch: `git checkout -b wip && git add <paths> && git commit -m "wip"` |
| `git clean` | deletes untracked files, unrecoverably | list them first: `git status --short`; delete by name if truly unwanted |
| `git reset --hard` | throws away every uncommitted change | `git status`, then commit or discuss |
| `git checkout -- <file>` · `git restore` | overwrites a file with the last committed copy, silently | copy the file aside first, or commit it |
| `git commit --amend` · `git rebase` | rewrite history that may already be shared | make a new commit |
| `git push --force` · `git push -f` | overwrites the remote's history for everyone | `git pull`, resolve, then an ordinary `git push` |

A text tool that merely mentions these words (`grep "git stash" notes.md`, `echo`) is not refused.

If a task truly needs one of these, write one sentence saying what will be lost and what the owner must do by hand; the owner runs it themselves, outside Claude, with that knowledge.
