#!/usr/bin/env bash
# ankr-session.sh — ANKR harness SessionStart hook. Prints one line: harness version + how this machine is signed in.
# Compute or null: it reads files, it never guesses. macOS keeps a subscription sign-in in the Keychain, which this
# script cannot read, so there it says "unknown" instead of "none".
CLAUDE_HOME="${CLAUDE_CONFIG_DIR:-$HOME/.claude}"
ANKR="$CLAUDE_HOME/ankr"
ver="?"
if [ -f "$ANKR/harness.json" ]; then
  ver=$(sed -n 's/.*"version"[[:space:]]*:[[:space:]]*"\([^"]*\)".*/\1/p' "$ANKR/harness.json" | head -1)
fi
S="$CLAUDE_HOME/settings.json"
mode="none"
if [ -n "${ANTHROPIC_AUTH_TOKEN:-}" ]; then mode="gateway (environment)"
elif [ -n "${ANTHROPIC_API_KEY:-}" ]; then mode="api-key (environment)"
elif [ -f "$S" ] && grep -q '"ANTHROPIC_AUTH_TOKEN"' "$S" 2>/dev/null; then mode="gateway (settings.json)"
elif [ -f "$S" ] && grep -q '"ANTHROPIC_API_KEY"' "$S" 2>/dev/null; then mode="api-key (settings.json)"
elif [ -f "$CLAUDE_HOME/.credentials.json" ]; then mode="subscription (signed in)"
elif [ "$(uname -s 2>/dev/null)" = "Darwin" ]; then mode="unknown (macOS keeps a sign-in in the Keychain)"
fi
hint=""
[ "$mode" = "none" ] && hint=" — no sign-in found yet: run /ankr-byok, or simply sign in when Claude asks"
printf '[ANKR harness v%s] auth: %s%s · check: /ankr-doctor · rules: ~/.claude/ankr/ANKR.md\n' "$ver" "$mode" "$hint"
exit 0
