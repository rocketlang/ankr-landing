#!/usr/bin/env bash
# ankr-guard.sh — ANKR harness PreToolUse(Bash) hook.
# Refuses (exit 2, reason on stderr) the commands that delete or rewrite work a non-coder cannot get back:
#   git add . / -A / --all / -u · git stash · git clean · git reset --hard · git checkout -- <path> · git restore ·
#   git commit --amend · git rebase · git push --force / -f · rm -rf on / ~ or a bare * · prisma db push ·
#   prisma migrate reset · DROP TABLE/DATABASE/SCHEMA · TRUNCATE · mkfs · dd onto a device.
# A segment whose first word is a text tool (grep, echo, cat, ...) is never refused for quoting those words.
# Runs under bash on Linux/macOS/WSL/Termux and under Git Bash on Windows. Needs nothing but bash, awk, sed.
# Exit 0 = allow. Exit 2 = refuse. Any parse failure = allow (a guard must never break an honest command).

INPUT=$(cat 2>/dev/null)
[ -z "$INPUT" ] && exit 0

extract_command() {
  if [ -z "${ANKR_GUARD_FLOOR:-}" ] && command -v python3 >/dev/null 2>&1; then
    printf '%s' "$INPUT" | python3 -c 'import sys,json
try:
  d=json.load(sys.stdin); c=(d.get("tool_input") or {}).get("command",""); sys.stdout.write(c if isinstance(c,str) else "")
except Exception: pass' 2>/dev/null && return 0
  fi
  if [ -z "${ANKR_GUARD_FLOOR:-}" ] && command -v node >/dev/null 2>&1; then
    printf '%s' "$INPUT" | node -e 'let s="";process.stdin.on("data",d=>s+=d).on("end",()=>{try{const d=JSON.parse(s);const c=(d.tool_input||{}).command;process.stdout.write(typeof c==="string"?c:"")}catch(e){}})' 2>/dev/null && return 0
  fi
  # Floor: sed extraction of "command":"..." (handles \" and \n escapes; enough for the verbs above)
  local raw
  raw=$(printf '%s' "$INPUT" | tr -d '\n' | sed -E 's/.*"command"[[:space:]]*:[[:space:]]*"((\\.|[^"\\])*)".*/\1/')
  [ "$raw" = "$INPUT" ] && { printf ''; return 0; }
  printf '%s' "$raw" | sed -e 's/\\"/"/g' -e 's/\\\//\//g' -e 's/\\n/ /g' -e 's/\\t/ /g' -e 's/\\\\/\\/g'
}

CMD=$(extract_command)
[ -z "$CMD" ] && exit 0

refuse() { printf 'ANKR guard refused this command.\n%s\nRule: ~/.claude/ankr/rules/ankr-git-safety.md · ankr-db-safety.md\n' "$1" >&2; exit 2; }

TEXT_TOOLS=' grep egrep fgrep rg ag echo printf cat sed awk less more head tail comm sort uniq jq tr xargs find man help type which '

# Split on && || ; | and newlines — one segment per line.
SEGMENTS=$(printf '%s\n' "$CMD" | awk '{ gsub(/\|\||&&|;|\|/, "\n"); print }')

while IFS= read -r seg; do
  [ -z "${seg// /}" ] && continue
  # tokens
  # shellcheck disable=SC2206
  toks=( $seg )
  n=${#toks[@]}; i=0
  # skip env assignments and wrappers
  while [ $i -lt $n ]; do
    t=${toks[$i]}
    case "$t" in
      *=*) i=$((i+1)); continue;;
      sudo|env|time|nohup|command|exec|nice|doas) i=$((i+1)); continue;;
      -*) i=$((i+1)); continue;;
    esac
    break
  done
  [ $i -ge $n ] && continue
  t0=${toks[$i]}; t0=${t0##*/}
  case "$TEXT_TOOLS" in *" $t0 "*) continue;; esac
  rest=("${toks[@]:$((i+1))}")
  lower=$(printf '%s' "$seg" | tr '[:upper:]' '[:lower:]')

  case "$t0" in
    git)
      sub=""; j=0; args=()
      while [ $j -lt ${#rest[@]} ]; do
        a=${rest[$j]}
        if [ -z "$sub" ]; then
          case "$a" in
            -C|-c|--git-dir|--work-tree|--namespace) j=$((j+2)); continue;;
            -*) j=$((j+1)); continue;;
            *) sub=$a; j=$((j+1)); continue;;
          esac
        fi
        args+=("$a"); j=$((j+1))
      done
      has() { local x; for x in "${args[@]:-}"; do [ "$x" = "$1" ] && return 0; done; return 1; }
      hasprefix() { local x; for x in "${args[@]:-}"; do case "$x" in "$1"*) return 0;; esac; done; return 1; }
      case "$sub" in
        add)
          if has . || has -A || has --all || has -u || has --update || has '*' || has ':/' ; then
            refuse "git add with '.', -A, --all, -u or '*' stages everything, including files you did not mean to commit. Stage by name: git add path/to/file"
          fi;;
        stash)  refuse "git stash hides uncommitted work where it is easily lost. Commit on a branch instead: git checkout -b wip && git add <paths> && git commit -m wip";;
        clean)  refuse "git clean deletes untracked files and nothing can bring them back. List them first (git status --short) and delete by name if truly unwanted.";;
        reset)  if has --hard; then refuse "git reset --hard throws away every uncommitted change. Run git status, then commit or discuss."; fi;;
        checkout) if has -- || has . ; then refuse "git checkout -- <file> overwrites a file with the last committed copy, silently. Copy the file aside or commit it first."; fi;;
        restore) refuse "git restore overwrites files with the last committed copy. Copy the file aside or commit it first; to unstage use: git reset <path>";;
        commit) if has --amend; then refuse "git commit --amend rewrites the last commit. Make a new commit instead."; fi;;
        rebase) refuse "git rebase rewrites history and can lose work on a conflict. Merge instead, or ask the owner to run it by hand.";;
        push)   if has -f || hasprefix --force; then refuse "git push --force overwrites the remote's history for everyone. git pull, resolve, then an ordinary git push."; fi;;
        filter-branch) refuse "git filter-branch rewrites all history. Not from here.";;
      esac;;
    rm)
      recursive=0; for a in "${rest[@]:-}"; do case "$a" in -*r*|-*R*|--recursive) recursive=1;; esac; done
      if [ $recursive -eq 1 ]; then
        for a in "${rest[@]:-}"; do
          q=${a//\"/}; q=${q//\'/}   # strip quotes: "$HOME" and '~' are the same target
          # tildes are QUOTED in the patterns: an unquoted ~ in a case pattern undergoes tilde expansion
          case "$q" in
            /|'/*'|'~'|'~/'|'~/*'|'$HOME'|'$HOME/'|'$HOME/*'|'${HOME}'|'*'|--no-preserve-root|/home|/home/|/Users|/Users/|/root|/root/|/etc|/usr|/var|/bin|/lib|/opt|/boot|C:|C:/|'C:\'|/c|/c/|/mnt/c|/mnt/c/)
              refuse "rm -r on '$a' would delete far more than a project. Delete a named folder inside the project instead.";;
          esac
          [ -n "${HOME:-}" ] && { [ "$q" = "$HOME" ] || [ "$q" = "$HOME/" ]; } && refuse "rm -r on your home folder ('$a') would delete everything you own. Delete a named folder inside the project instead."
        done
      fi;;
    mkfs|mkfs.*) refuse "mkfs formats a disk. Not from here.";;
    dd) case "$seg" in *of=/dev/*) refuse "dd onto a device overwrites a disk. Not from here.";; esac;;
  esac

  # prisma / SQL in any position of the segment
  case "$lower" in
    *"prisma db push"*)       refuse "prisma db push rewrites the database schema in place and can drop columns with data. Use an additive migration: prisma migrate dev --create-only, then read it.";;
    *"prisma migrate reset"*) refuse "prisma migrate reset DROPS the database and recreates it empty. Not on a database with data.";;
  esac
  case "$lower" in
    *"drop table"*|*"drop database"*|*"drop schema"*|*"truncate "*|*"truncate;"*)
      refuse "This statement destroys data (DROP / TRUNCATE). Schema changes are additive; write the additive alternative and show the owner.";;
  esac
done <<EOF
$SEGMENTS
EOF

exit 0
