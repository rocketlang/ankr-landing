---
name: ankr-byok
description: Open the ANKR "bring your own key" page so the owner can add, check or remove their own API key or switch to a subscription sign-in. The key is written to ~/.claude/settings.json on this computer and goes nowhere else.
---

# /ankr-byok — your key, your computer

Run this, in the background so the page can stay up while you report:

```bash
bash "${CLAUDE_CONFIG_DIR:-$HOME/.claude}/ankr/byok/byok.sh" --background
```

**You should see** a line `BYOK page: http://127.0.0.1:<port>/?t=<token>` and a browser tab opening on this computer.

Tell the owner, in plain words:
1. A page has opened on this computer (or give them the printed link to open by hand).
2. They choose one of three: **I pay Anthropic for Claude** (no key: they just type `claude` and sign in), **I have an Anthropic API key** (paste it there), or **another provider that speaks Anthropic's API** (a URL and a token).
3. The key is written only to their own settings file on this computer. ANKR never receives it. There is a button to remove it in one act.
4. When the page says **Done**, they close the tab and start `claude` again so the new sign-in is used.

**If not** — if no browser can open (a server, Termux without a browser, SSH), run the floor:

```bash
bash "${CLAUDE_CONFIG_DIR:-$HOME/.claude}/ankr/byok/byok.sh" --terminal
```

It asks for the key in the terminal without echoing it and writes the same file.

Never ask the owner to paste a key into this chat. Never read the key back to them.
