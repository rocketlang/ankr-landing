---
name: ankr-doctor
description: Check that Claude Code, the ANKR harness (guard hooks, rules, skills) and the sign-in on this computer are healthy, and print the fix beside anything that is not.
---

# /ankr-doctor — is everything in place?

Run:

```bash
bash "${CLAUDE_CONFIG_DIR:-$HOME/.claude}/ankr/bin/ankr-doctor.sh"
```

**You should see** one line per check, each starting with ✓ (fine), ✗ (broken, with the fix after the dash) or · (optional, not installed).

Relay the lines to the owner as they are. For every ✗, do the fix if it is a file on this computer (a missing hook, an import line, a rule file) by re-running the install line from ankr.in/install; if it is a sign-in (auth: none), point them to `/ankr-byok`; if it is a program that must be installed (git, VS Code), give the one command or link printed after the dash.

**If not** — if the script itself is missing, the harness is not installed: re-run the install line for this device from https://ankr.in/install.
