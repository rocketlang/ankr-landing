#!/usr/bin/env bash
# byok.sh — ANKR harness: dispatcher for the bring-your-own-key page.
#   byok.sh                 open the page (python3, else node); falls to the terminal floor if neither exists
#   byok.sh --background    start the page helper detached and print its URL (for the /ankr-byok skill)
#   byok.sh --terminal      the floor: ask in the terminal, never a browser
#   byok.sh --status        print the sign-in state
# On Windows under Git Bash it hands over to byok.ps1 (PowerShell is always present there).
HERE=$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)
CLAUDE_HOME="${CLAUDE_CONFIG_DIR:-$HOME/.claude}"
MODE="page"; ARGS=()
for a in "$@"; do
  case "$a" in
    --background) MODE="background";;
    --terminal)   MODE="terminal";;
    --status)     MODE="status";;
    *)            ARGS+=("$a");;
  esac
done

case "$(uname -s 2>/dev/null)" in
  MINGW*|MSYS*|CYGWIN*)
    ps1=$(cygpath -w "$HERE/byok.ps1" 2>/dev/null || printf '%s' "$HERE/byok.ps1")
    case "$MODE" in
      terminal) exec powershell.exe -NoProfile -ExecutionPolicy Bypass -File "$ps1" -Terminal;;
      status)   exec powershell.exe -NoProfile -ExecutionPolicy Bypass -File "$ps1" -Status;;
      background) powershell.exe -NoProfile -ExecutionPolicy Bypass -File "$ps1" -Serve -Background; exit $?;;
      *)        exec powershell.exe -NoProfile -ExecutionPolicy Bypass -File "$ps1" -Serve;;
    esac;;
esac

runtime=""
if [ "${ANKR_BYOK_RUNTIME:-}" = "node" ] && command -v node >/dev/null 2>&1; then runtime="node"
elif [ "${ANKR_BYOK_RUNTIME:-}" = "python" ] && command -v python3 >/dev/null 2>&1; then runtime="python"
elif command -v python3 >/dev/null 2>&1; then runtime="python"
elif command -v node >/dev/null 2>&1; then runtime="node"
fi

run() {  # run <args...>
  case "$runtime" in
    python) python3 "$HERE/byok.py" "$@";;
    node)   node "$HERE/byok.mjs" "$@";;
  esac
}

if [ -z "$runtime" ]; then
  # The floor of the floor: no python3, no node. Say exactly what to do by hand; never guess at a JSON merge.
  cat <<EOF
ANKR BYOK: neither python3 nor node is on this computer, so the page cannot run and the file cannot be edited safely by script.
Two ways forward:
  1) Subscription (no key): open a terminal in your project and type   claude   — sign in when the browser opens. Nothing to write.
  2) API key: open $CLAUDE_HOME/settings.json in a text editor and add, inside the outer { }:
       "env": { "ANTHROPIC_API_KEY": "sk-ant-...your key..." }
     Keep the file valid JSON (commas between entries). Then run /ankr-doctor.
EOF
  exit 1
fi

case "$MODE" in
  status)     run --status;;
  terminal)   run --terminal "${ARGS[@]}";;
  background)
    log="${TMPDIR:-/tmp}/ankr-byok-$$.log"
    if [ "$runtime" = "python" ]; then nohup python3 "$HERE/byok.py" --serve "${ARGS[@]}" >"$log" 2>&1 &
    else nohup node "$HERE/byok.mjs" --serve "${ARGS[@]}" >"$log" 2>&1 & fi
    pid=$!
    for _ in 1 2 3 4 5 6 7 8 9 10; do sleep 0.3; grep -q 'BYOK page:' "$log" 2>/dev/null && break; done
    if grep -q 'BYOK page:' "$log"; then grep 'BYOK page:' "$log"; echo "helper pid $pid (stops after 10 quiet minutes or on Close)"; exit 0
    else echo "BYOK helper did not start:"; cat "$log"; exit 1; fi;;
  *)          run --serve "${ARGS[@]}";;
esac
