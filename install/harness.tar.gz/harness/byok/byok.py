#!/usr/bin/env python3
"""byok.py — ANKR harness: bring-your-own-key helper (python3 runtime).

  byok.py --serve [--port N] [--no-open] [--idle SECONDS]   serve byok.html on 127.0.0.1 with a one-time token
  byok.py --terminal [--from-stdin] [--no-verify]           the floor: ask for the key in the terminal, write the file
  byok.py --mode subscription|remove                        non-interactive forms
  byok.py --mode gateway --base-url URL --token-from-stdin
  byok.py --status                                          print the sign-in state as JSON

Writes ONLY the env block of ~/.claude/settings.json (CLAUDE_CONFIG_DIR honoured), mode 600, atomically.
Verifies an Anthropic key ONLY against https://api.anthropic.com/v1/models. Never prints or logs a key.
"""
import json, os, re, sys, secrets, threading, time, stat, getpass, urllib.request, urllib.error
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

CLAUDE_HOME = os.environ.get("CLAUDE_CONFIG_DIR") or os.path.join(os.path.expanduser("~"), ".claude")
SETTINGS = os.path.join(CLAUDE_HOME, "settings.json")
ANKR_DIR = os.path.join(CLAUDE_HOME, "ankr")
HARNESS = os.path.join(ANKR_DIR, "harness.json")
HTML = os.path.join(os.path.dirname(os.path.abspath(__file__)), "byok.html")
KEY_RE = re.compile(r"^sk-ant-[A-Za-z0-9_\-]{20,}$")
ENV_KEYS = ("ANTHROPIC_API_KEY", "ANTHROPIC_AUTH_TOKEN", "ANTHROPIC_BASE_URL")


class SettingsError(Exception):
    pass


def read_settings():
    if not os.path.exists(SETTINGS):
        return {}
    with open(SETTINGS, "r", encoding="utf-8-sig") as f:
        raw = f.read()
    if not raw.strip():
        return {}
    try:
        d = json.loads(raw)
    except Exception as e:
        raise SettingsError("%s is not valid JSON (%s). Fix it or restore a settings.json.bak-* copy; nothing was written." % (SETTINGS, e))
    if not isinstance(d, dict):
        raise SettingsError("%s does not hold a JSON object; nothing was written." % SETTINGS)
    return d


def write_settings(d):
    os.makedirs(CLAUDE_HOME, exist_ok=True)
    tmp = SETTINGS + ".tmp-%d" % os.getpid()
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(d, f, indent=2, ensure_ascii=False)
        f.write("\n")
    try:
        os.chmod(tmp, stat.S_IRUSR | stat.S_IWUSR)
    except Exception:
        pass
    os.replace(tmp, SETTINGS)
    with open(SETTINGS, "r", encoding="utf-8") as f:
        json.load(f)  # re-validate: a settings file that does not parse is silently ignored by Claude Code


def set_env(updates, removes):
    d = read_settings()
    env = d.get("env")
    if not isinstance(env, dict):
        env = {}
    for k in removes:
        env.pop(k, None)
    env.update(updates)
    if env:
        d["env"] = env
    else:
        d.pop("env", None)
    write_settings(d)


def note_mode(mode):
    try:
        with open(HARNESS, "r", encoding="utf-8") as f:
            h = json.load(f)
        h["auth_mode"] = mode
        with open(HARNESS, "w", encoding="utf-8") as f:
            json.dump(h, f, indent=2)
            f.write("\n")
    except Exception:
        pass


def harness_version():
    try:
        with open(HARNESS, "r", encoding="utf-8") as f:
            return json.load(f).get("version")
    except Exception:
        return None


def status():
    try:
        d = read_settings()
        env = d.get("env") if isinstance(d.get("env"), dict) else {}
        err = None
    except SettingsError as e:
        env, err = {}, str(e)
    if os.environ.get("ANTHROPIC_AUTH_TOKEN") or env.get("ANTHROPIC_AUTH_TOKEN"):
        mode = "gateway"
    elif os.environ.get("ANTHROPIC_API_KEY") or env.get("ANTHROPIC_API_KEY"):
        mode = "api-key"
    elif os.path.exists(os.path.join(CLAUDE_HOME, ".credentials.json")):
        mode = "subscription"
    elif sys.platform == "darwin":
        mode = "unknown"
    else:
        mode = "none"
    return {"ok": True, "mode": mode, "settings_path": SETTINGS, "harness_version": harness_version(), "settings_error": err}


def verify_anthropic(key):
    req = urllib.request.Request("https://api.anthropic.com/v1/models", headers={"x-api-key": key, "anthropic-version": "2023-06-01", "user-agent": "ankr-harness-byok"})
    try:
        with urllib.request.urlopen(req, timeout=10) as r:
            return (True, "Anthropic accepted the key (HTTP %d)." % r.status)
    except urllib.error.HTTPError as e:
        if e.code in (401, 403):
            return (False, "Anthropic rejected this key (HTTP %d). Check it on console.anthropic.com and paste again." % e.code)
        return (None, "Anthropic answered HTTP %d; the key was saved unverified." % e.code)
    except Exception as e:
        return (None, "Could not reach Anthropic (%s); the key was saved unverified." % e.__class__.__name__)


def save_anthropic_key(key, verify):
    key = (key or "").strip()
    if not KEY_RE.match(key):
        return {"ok": False, "error": "That does not look like an Anthropic API key (they start with sk-ant- and are long). Nothing was written."}
    note = None
    if verify:
        ok, msg = verify_anthropic(key)
        if ok is False:
            return {"ok": False, "error": msg}
        if ok is None:
            note = msg
    set_env({"ANTHROPIC_API_KEY": key}, ["ANTHROPIC_AUTH_TOKEN", "ANTHROPIC_BASE_URL"])
    note_mode("api-key")
    return {"ok": True, "message": "Key saved to %s (mode 600). Any gateway setting was removed." % SETTINGS, "verified": bool(verify and note is None), "note": note}


def save_gateway(base_url, token):
    base_url = (base_url or "").strip()
    token = (token or "").strip()
    if not re.match(r"^https?://[^\s/]+", base_url):
        return {"ok": False, "error": "The base URL must start with http:// or https://. Nothing was written."}
    if len(token) < 8:
        return {"ok": False, "error": "The token is too short to be real. Nothing was written."}
    set_env({"ANTHROPIC_BASE_URL": base_url, "ANTHROPIC_AUTH_TOKEN": token}, ["ANTHROPIC_API_KEY"])
    note_mode("gateway")
    return {"ok": True, "message": "Gateway saved to %s — unverified. If Claude Code cannot talk to it, come back and remove it." % SETTINGS, "verified": False}


def use_subscription():
    set_env({}, list(ENV_KEYS))
    note_mode("subscription")
    return {"ok": True, "message": "Any saved key or gateway was removed. Type claude and sign in when the browser opens."}


def remove_all():
    set_env({}, list(ENV_KEYS))
    note_mode(None)
    return {"ok": True, "message": "Removed."}


# ---------------------------------------------------------------- server
def serve(port, open_browser, idle):
    token = secrets.token_urlsafe(24)
    last = {"t": time.time()}
    with open(HTML, "rb") as f:
        page = f.read()

    class H(BaseHTTPRequestHandler):
        server_version = "ankr-byok"

        def log_message(self, fmt, *args):  # never log bodies; keep quiet
            pass

        def _json(self, code, obj):
            body = json.dumps(obj).encode("utf-8")
            self.send_response(code)
            self.send_header("Content-Type", "application/json; charset=utf-8")
            self.send_header("Content-Length", str(len(body)))
            self.send_header("Cache-Control", "no-store")
            self.end_headers()
            self.wfile.write(body)

        def _host_ok(self):
            h = (self.headers.get("Host") or "").split(":")[0]
            return h in ("127.0.0.1", "localhost", "[::1]", "::1")

        def _auth(self):
            return self.headers.get("X-ANKR-Token") == token

        def do_GET(self):
            last["t"] = time.time()
            if not self._host_ok():
                return self._json(403, {"ok": False, "error": "wrong host"})
            if self.path.split("?")[0] == "/":
                self.send_response(200)
                self.send_header("Content-Type", "text/html; charset=utf-8")
                self.send_header("Content-Length", str(len(page)))
                self.send_header("Cache-Control", "no-store")
                self.send_header("X-Frame-Options", "DENY")
                self.end_headers()
                self.wfile.write(page)
                return
            if self.path == "/api/status":
                if not self._auth():
                    return self._json(403, {"ok": False, "error": "token"})
                return self._json(200, status())
            self._json(404, {"ok": False, "error": "not found"})

        def do_POST(self):
            last["t"] = time.time()
            if not self._host_ok():
                return self._json(403, {"ok": False, "error": "wrong host"})
            if not self._auth():
                return self._json(403, {"ok": False, "error": "token"})
            n = int(self.headers.get("Content-Length") or 0)
            try:
                body = json.loads(self.rfile.read(n).decode("utf-8")) if n else {}
            except Exception:
                return self._json(400, {"ok": False, "error": "bad JSON"})
            try:
                if self.path == "/api/anthropic-key":
                    r = save_anthropic_key(body.get("key"), bool(body.get("verify", True)))
                elif self.path == "/api/gateway":
                    r = save_gateway(body.get("base_url"), body.get("token"))
                elif self.path == "/api/subscription":
                    r = use_subscription()
                elif self.path == "/api/remove":
                    r = remove_all()
                elif self.path == "/api/close":
                    self._json(200, {"ok": True})
                    threading.Thread(target=self.server.shutdown, daemon=True).start()
                    return
                else:
                    return self._json(404, {"ok": False, "error": "not found"})
            except SettingsError as e:
                return self._json(500, {"ok": False, "error": str(e)})
            self._json(200 if r.get("ok") else 400, r)

    srv = None
    for p in range(port, port + 10):
        try:
            srv = ThreadingHTTPServer(("127.0.0.1", p), H)
            port = p
            break
        except OSError:
            continue
    if srv is None:
        print("BYOK: no free port between %d and %d" % (port, port + 9), file=sys.stderr)
        return 1
    url = "http://127.0.0.1:%d/?t=%s" % (port, token)
    print("BYOK page: %s" % url, flush=True)

    def watchdog():
        while True:
            time.sleep(5)
            if time.time() - last["t"] > idle:
                srv.shutdown()
                return
    threading.Thread(target=watchdog, daemon=True).start()
    if open_browser:
        threading.Thread(target=open_url, args=(url,), daemon=True).start()
    try:
        srv.serve_forever()
    except KeyboardInterrupt:
        pass
    print("BYOK helper stopped.", flush=True)
    return 0


def open_url(url):
    import subprocess, shutil
    cands = []
    if "com.termux" in os.environ.get("PREFIX", ""):
        cands.append(["termux-open-url", url])
    if os.path.exists("/proc/version"):
        try:
            with open("/proc/version") as f:
                if "microsoft" in f.read().lower():
                    cands.append(["wslview", url]); cands.append(["cmd.exe", "/c", "start", "", url.replace("&", "^&")])
        except Exception:
            pass
    for c in cands:
        if shutil.which(c[0]):
            try:
                subprocess.Popen(c, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
                return
            except Exception:
                pass
    try:
        import webbrowser
        webbrowser.open(url)
    except Exception:
        pass


# ---------------------------------------------------------------- terminal floor
def terminal(from_stdin, no_verify):
    if from_stdin:
        key = sys.stdin.readline().strip()
        r = save_anthropic_key(key, not no_verify)
    else:
        print("ANKR — your key stays on this computer (written to %s)." % SETTINGS)
        print("1) I pay Anthropic for Claude (subscription)  2) I have an Anthropic API key  3) remove any saved key")
        choice = input("Choose 1, 2 or 3: ").strip()
        if choice == "1":
            r = use_subscription()
        elif choice == "3":
            r = remove_all()
        else:
            key = getpass.getpass("Paste the key (it will not be shown): ")
            r = save_anthropic_key(key, not no_verify)
    print(("OK: " if r.get("ok") else "NOT SAVED: ") + (r.get("message") or r.get("error") or ""))
    if r.get("note"):
        print("Note: " + r["note"])
    return 0 if r.get("ok") else 1


def main(argv):
    a = argv[1:]
    def opt(name, default=None):
        return a[a.index(name) + 1] if name in a and a.index(name) + 1 < len(a) else default
    try:
        if "--status" in a:
            print(json.dumps(status())); return 0
        if "--serve" in a:
            return serve(int(opt("--port", "47617")), "--no-open" not in a, int(opt("--idle", "600")))
        if "--terminal" in a:
            return terminal("--from-stdin" in a, "--no-verify" in a)
        if "--mode" in a:
            m = opt("--mode")
            if m == "subscription": r = use_subscription()
            elif m == "remove": r = remove_all()
            elif m == "gateway": r = save_gateway(opt("--base-url"), sys.stdin.readline().strip() if "--token-from-stdin" in a else "")
            else: r = {"ok": False, "error": "unknown mode"}
            print(json.dumps(r)); return 0 if r.get("ok") else 1
    except SettingsError as e:
        print("NOT SAVED: %s" % e, file=sys.stderr); return 1
    print(__doc__); return 2


if __name__ == "__main__":
    sys.exit(main(sys.argv))
