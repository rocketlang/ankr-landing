#!/usr/bin/env node
// byok.mjs — ANKR harness: bring-your-own-key helper (node runtime; same protocol as byok.py).
//   --serve [--port N] [--no-open] [--idle SECONDS] · --terminal [--from-stdin] [--no-verify] ·
//   --mode subscription|remove · --mode gateway --base-url URL --token-from-stdin · --status
// Writes ONLY the env block of ~/.claude/settings.json (CLAUDE_CONFIG_DIR honoured), mode 600, atomically.
// Verifies an Anthropic key ONLY against https://api.anthropic.com/v1/models. Never prints or logs a key.
import http from 'node:http';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import crypto from 'node:crypto';
import { spawn } from 'node:child_process';
import { fileURLToPath } from 'node:url';

const CLAUDE_HOME = process.env.CLAUDE_CONFIG_DIR || path.join(os.homedir(), '.claude');
const SETTINGS = path.join(CLAUDE_HOME, 'settings.json');
const HARNESS = path.join(CLAUDE_HOME, 'ankr', 'harness.json');
const HTML = path.join(path.dirname(fileURLToPath(import.meta.url)), 'byok.html');
const KEY_RE = /^sk-ant-[A-Za-z0-9_-]{20,}$/;
const ENV_KEYS = ['ANTHROPIC_API_KEY', 'ANTHROPIC_AUTH_TOKEN', 'ANTHROPIC_BASE_URL'];

class SettingsError extends Error {}

function readSettings() {
  if (!fs.existsSync(SETTINGS)) return {};
  const raw = fs.readFileSync(SETTINGS, 'utf8').replace(/^﻿/, '');
  if (!raw.trim()) return {};
  let d;
  try { d = JSON.parse(raw); } catch (e) { throw new SettingsError(`${SETTINGS} is not valid JSON (${e.message}). Fix it or restore a settings.json.bak-* copy; nothing was written.`); }
  if (!d || typeof d !== 'object' || Array.isArray(d)) throw new SettingsError(`${SETTINGS} does not hold a JSON object; nothing was written.`);
  return d;
}
function writeSettings(d) {
  fs.mkdirSync(CLAUDE_HOME, { recursive: true });
  const tmp = `${SETTINGS}.tmp-${process.pid}`;
  fs.writeFileSync(tmp, JSON.stringify(d, null, 2) + '\n', { mode: 0o600 });
  try { fs.chmodSync(tmp, 0o600); } catch {}
  fs.renameSync(tmp, SETTINGS);
  JSON.parse(fs.readFileSync(SETTINGS, 'utf8')); // re-validate
}
function setEnv(updates, removes) {
  const d = readSettings();
  const env = d.env && typeof d.env === 'object' && !Array.isArray(d.env) ? d.env : {};
  for (const k of removes) delete env[k];
  Object.assign(env, updates);
  if (Object.keys(env).length) d.env = env; else delete d.env;
  writeSettings(d);
}
function noteMode(mode) {
  try { const h = JSON.parse(fs.readFileSync(HARNESS, 'utf8')); h.auth_mode = mode; fs.writeFileSync(HARNESS, JSON.stringify(h, null, 2) + '\n'); } catch {}
}
function harnessVersion() { try { return JSON.parse(fs.readFileSync(HARNESS, 'utf8')).version; } catch { return null; } }
function status() {
  let env = {}, err = null;
  try { const d = readSettings(); env = d.env && typeof d.env === 'object' ? d.env : {}; } catch (e) { err = e.message; }
  let mode = 'none';
  if (process.env.ANTHROPIC_AUTH_TOKEN || env.ANTHROPIC_AUTH_TOKEN) mode = 'gateway';
  else if (process.env.ANTHROPIC_API_KEY || env.ANTHROPIC_API_KEY) mode = 'api-key';
  else if (fs.existsSync(path.join(CLAUDE_HOME, '.credentials.json'))) mode = 'subscription';
  else if (process.platform === 'darwin') mode = 'unknown';
  return { ok: true, mode, settings_path: SETTINGS, harness_version: harnessVersion(), settings_error: err };
}
async function verifyAnthropic(key) {
  try {
    const ctl = new AbortController(); const t = setTimeout(() => ctl.abort(), 10000);
    const r = await fetch('https://api.anthropic.com/v1/models', { headers: { 'x-api-key': key, 'anthropic-version': '2023-06-01', 'user-agent': 'ankr-harness-byok' }, signal: ctl.signal });
    clearTimeout(t);
    if (r.status === 200) return [true, `Anthropic accepted the key (HTTP ${r.status}).`];
    if (r.status === 401 || r.status === 403) return [false, `Anthropic rejected this key (HTTP ${r.status}). Check it on console.anthropic.com and paste again.`];
    return [null, `Anthropic answered HTTP ${r.status}; the key was saved unverified.`];
  } catch (e) { return [null, `Could not reach Anthropic (${e.name}); the key was saved unverified.`]; }
}
async function saveAnthropicKey(key, verify) {
  key = (key || '').trim();
  if (!KEY_RE.test(key)) return { ok: false, error: 'That does not look like an Anthropic API key (they start with sk-ant- and are long). Nothing was written.' };
  let note = null;
  if (verify) { const [ok, msg] = await verifyAnthropic(key); if (ok === false) return { ok: false, error: msg }; if (ok === null) note = msg; }
  setEnv({ ANTHROPIC_API_KEY: key }, ['ANTHROPIC_AUTH_TOKEN', 'ANTHROPIC_BASE_URL']);
  noteMode('api-key');
  return { ok: true, message: `Key saved to ${SETTINGS} (mode 600). Any gateway setting was removed.`, verified: !!(verify && note === null), note };
}
function saveGateway(baseUrl, token) {
  baseUrl = (baseUrl || '').trim(); token = (token || '').trim();
  if (!/^https?:\/\/[^\s/]+/.test(baseUrl)) return { ok: false, error: 'The base URL must start with http:// or https://. Nothing was written.' };
  if (token.length < 8) return { ok: false, error: 'The token is too short to be real. Nothing was written.' };
  setEnv({ ANTHROPIC_BASE_URL: baseUrl, ANTHROPIC_AUTH_TOKEN: token }, ['ANTHROPIC_API_KEY']);
  noteMode('gateway');
  return { ok: true, message: `Gateway saved to ${SETTINGS} — unverified. If Claude Code cannot talk to it, come back and remove it.`, verified: false };
}
function useSubscription() { setEnv({}, ENV_KEYS); noteMode('subscription'); return { ok: true, message: 'Any saved key or gateway was removed. Type claude and sign in when the browser opens.' }; }
function removeAll() { setEnv({}, ENV_KEYS); noteMode(null); return { ok: true, message: 'Removed.' }; }

function openUrl(url) {
  const cands = [];
  if ((process.env.PREFIX || '').includes('com.termux')) cands.push(['termux-open-url', [url]]);
  try { if (fs.existsSync('/proc/version') && /microsoft/i.test(fs.readFileSync('/proc/version', 'utf8'))) { cands.push(['wslview', [url]]); cands.push(['cmd.exe', ['/c', 'start', '', url.replace(/&/g, '^&')]]); } } catch {}
  if (process.platform === 'darwin') cands.push(['open', [url]]);
  else if (process.platform === 'win32') cands.push(['cmd', ['/c', 'start', '', url.replace(/&/g, '^&')]]);
  else cands.push(['xdg-open', [url]]);
  const tryNext = (i) => { if (i >= cands.length) return; try { const p = spawn(cands[i][0], cands[i][1], { stdio: 'ignore', detached: true }); p.on('error', () => tryNext(i + 1)); p.unref(); } catch { tryNext(i + 1); } };
  tryNext(0);
}

function serve(port, open, idle) {
  const token = crypto.randomBytes(24).toString('base64url');
  const page = fs.readFileSync(HTML);
  let last = Date.now();
  const json = (res, code, obj) => { const b = Buffer.from(JSON.stringify(obj)); res.writeHead(code, { 'Content-Type': 'application/json; charset=utf-8', 'Content-Length': b.length, 'Cache-Control': 'no-store' }); res.end(b); };
  const hostOk = (req) => ['127.0.0.1', 'localhost', '[::1]', '::1'].includes(String(req.headers.host || '').split(':')[0]);
  const srv = http.createServer(async (req, res) => {
    last = Date.now();
    if (!hostOk(req)) return json(res, 403, { ok: false, error: 'wrong host' });
    const p = req.url.split('?')[0];
    if (req.method === 'GET' && p === '/') { res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8', 'Content-Length': page.length, 'Cache-Control': 'no-store', 'X-Frame-Options': 'DENY' }); return res.end(page); }
    if (req.headers['x-ankr-token'] !== token) return json(res, 403, { ok: false, error: 'token' });
    if (req.method === 'GET' && p === '/api/status') return json(res, 200, status());
    if (req.method !== 'POST') return json(res, 404, { ok: false, error: 'not found' });
    let body = ''; for await (const c of req) body += c;
    let b = {}; try { b = body ? JSON.parse(body) : {}; } catch { return json(res, 400, { ok: false, error: 'bad JSON' }); }
    try {
      let r;
      if (p === '/api/anthropic-key') r = await saveAnthropicKey(b.key, b.verify !== false);
      else if (p === '/api/gateway') r = saveGateway(b.base_url, b.token);
      else if (p === '/api/subscription') r = useSubscription();
      else if (p === '/api/remove') r = removeAll();
      else if (p === '/api/close') { json(res, 200, { ok: true }); setTimeout(() => srv.close(() => process.exit(0)), 50); return; }
      else return json(res, 404, { ok: false, error: 'not found' });
      return json(res, r.ok ? 200 : 400, r);
    } catch (e) { return json(res, e instanceof SettingsError ? 500 : 500, { ok: false, error: e.message }); }
  });
  const tryListen = (p, left) => {
    srv.once('error', (e) => { if (e.code === 'EADDRINUSE' && left > 0) tryListen(p + 1, left - 1); else { console.error(`BYOK: no free port near ${p}`); process.exit(1); } });
    srv.listen(p, '127.0.0.1', () => {
      const url = `http://127.0.0.1:${p}/?t=${token}`;
      console.log(`BYOK page: ${url}`);
      if (open) openUrl(url);
      const w = setInterval(() => { if (Date.now() - last > idle * 1000) { clearInterval(w); srv.close(() => { console.log('BYOK helper stopped.'); process.exit(0); }); } }, 5000);
    });
  };
  tryListen(port, 9);
}

async function readLine() { let s = ''; for await (const c of process.stdin) { s += c; if (s.includes('\n')) break; } return s.split('\n')[0].trim(); }
async function askHidden(prompt) {
  process.stdout.write(prompt);
  const rl = (await import('node:readline')).createInterface({ input: process.stdin, output: process.stdout, terminal: true });
  const mute = { on: false };
  rl._writeToOutput = (s) => { if (!mute.on) rl.output.write(s); };
  return new Promise((resolve) => { mute.on = true; rl.question('', (a) => { mute.on = false; rl.close(); process.stdout.write('\n'); resolve(a.trim()); }); });
}
async function terminal(fromStdin, noVerify) {
  let r;
  if (fromStdin) r = await saveAnthropicKey(await readLine(), !noVerify);
  else {
    console.log(`ANKR — your key stays on this computer (written to ${SETTINGS}).`);
    console.log('1) I pay Anthropic for Claude (subscription)  2) I have an Anthropic API key  3) remove any saved key');
    const rl = (await import('node:readline')).createInterface({ input: process.stdin, output: process.stdout });
    const choice = await new Promise((res) => rl.question('Choose 1, 2 or 3: ', (a) => { rl.close(); res(a.trim()); }));
    if (choice === '1') r = useSubscription();
    else if (choice === '3') r = removeAll();
    else r = await saveAnthropicKey(await askHidden('Paste the key (it will not be shown): '), !noVerify);
  }
  console.log((r.ok ? 'OK: ' : 'NOT SAVED: ') + (r.message || r.error || ''));
  if (r.note) console.log('Note: ' + r.note);
  return r.ok ? 0 : 1;
}

const a = process.argv.slice(2);
const opt = (n, d) => (a.includes(n) && a[a.indexOf(n) + 1] !== undefined ? a[a.indexOf(n) + 1] : d);
try {
  if (a.includes('--status')) { console.log(JSON.stringify(status())); process.exit(0); }
  else if (a.includes('--serve')) serve(parseInt(opt('--port', '47617'), 10), !a.includes('--no-open'), parseInt(opt('--idle', '600'), 10));
  else if (a.includes('--terminal')) terminal(a.includes('--from-stdin'), a.includes('--no-verify')).then((c) => process.exit(c));
  else if (a.includes('--mode')) {
    const m = opt('--mode');
    (async () => {
      let r;
      if (m === 'subscription') r = useSubscription();
      else if (m === 'remove') r = removeAll();
      else if (m === 'gateway') r = saveGateway(opt('--base-url'), a.includes('--token-from-stdin') ? await readLine() : '');
      else r = { ok: false, error: 'unknown mode' };
      console.log(JSON.stringify(r)); process.exit(r.ok ? 0 : 1);
    })();
  } else { console.log('usage: byok.mjs --serve | --terminal | --mode <m> | --status'); process.exit(2); }
} catch (e) { console.error('NOT SAVED: ' + e.message); process.exit(1); }
