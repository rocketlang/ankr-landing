# byok.ps1 - ANKR harness: bring-your-own-key helper for Windows (PowerShell 5.1+; same protocol as byok.py).
#   -Serve [-Port 47617] [-NoOpen] [-Idle 600] [-Background]   serve byok.html on localhost with a one-time token
#   -Terminal [-FromStdin] [-NoVerify]                          the floor: ask in the terminal, write the file
#   -Mode subscription|remove|gateway [-BaseUrl URL -TokenFromStdin]
#   -Status
# Writes ONLY the env block of %USERPROFILE%\.claude\settings.json (CLAUDE_CONFIG_DIR honoured), UTF-8 without BOM,
# atomically. Verifies an Anthropic key ONLY against https://api.anthropic.com/v1/models. Never prints or logs a key.
# UNTESTED ON THE BUILD BOX (Linux): the first Windows run is the founder's laptop - see ankr.in/install.
param(
  [switch]$Serve, [switch]$Background, [switch]$Terminal, [switch]$Status,
  [int]$Port = 47617, [switch]$NoOpen, [int]$Idle = 600,
  [switch]$FromStdin, [switch]$NoVerify,
  [string]$Mode, [string]$BaseUrl, [switch]$TokenFromStdin
)
$ErrorActionPreference = 'Stop'
$ProgressPreference = 'SilentlyContinue'
try { [Net.ServicePointManager]::SecurityProtocol = [Net.ServicePointManager]::SecurityProtocol -bor [Net.SecurityProtocolType]::Tls12 } catch {}

$ClaudeHome = if ($env:CLAUDE_CONFIG_DIR) { $env:CLAUDE_CONFIG_DIR } else { Join-Path $HOME '.claude' }
$SettingsPath = Join-Path $ClaudeHome 'settings.json'
$HarnessPath = Join-Path (Join-Path $ClaudeHome 'ankr') 'harness.json'
$HtmlPath = Join-Path $PSScriptRoot 'byok.html'
$KeyRe = '^sk-ant-[A-Za-z0-9_\-]{20,}$'
$EnvKeys = @('ANTHROPIC_API_KEY', 'ANTHROPIC_AUTH_TOKEN', 'ANTHROPIC_BASE_URL')

function Write-Utf8NoBom([string]$Path, [string]$Text) { [IO.File]::WriteAllText($Path, $Text, (New-Object System.Text.UTF8Encoding($false))) }

function Read-Settings {
  if (-not (Test-Path $SettingsPath)) { return New-Object PSObject }
  $raw = [IO.File]::ReadAllText($SettingsPath)
  if (-not $raw.Trim()) { return New-Object PSObject }
  try { $o = $raw | ConvertFrom-Json } catch { throw "$SettingsPath is not valid JSON ($($_.Exception.Message)). Fix it or restore a settings.json.bak-* copy; nothing was written." }
  if ($o -isnot [PSCustomObject]) { throw "$SettingsPath does not hold a JSON object; nothing was written." }
  return $o
}
function Write-Settings($Obj) {
  New-Item -ItemType Directory -Force -Path $ClaudeHome | Out-Null
  $json = ($Obj | ConvertTo-Json -Depth 32) + "`n"
  $tmp = "$SettingsPath.tmp-$PID"
  Write-Utf8NoBom $tmp $json
  if ($env:OS -ne 'Windows_NT') { try { & chmod 600 $tmp } catch {} }   # Unix modes only where they exist
  Move-Item -Force $tmp $SettingsPath
  [IO.File]::ReadAllText($SettingsPath) | ConvertFrom-Json | Out-Null   # re-validate
}
function Set-EnvBlock([hashtable]$Updates, [string[]]$Removes) {
  $d = Read-Settings
  $e = $null
  if ($d.PSObject.Properties['env'] -and $d.env -is [PSCustomObject]) { $e = $d.env } else { $e = New-Object PSObject }
  foreach ($k in $Removes) { if ($e.PSObject.Properties[$k]) { $e.PSObject.Properties.Remove($k) } }
  foreach ($k in $Updates.Keys) { if ($e.PSObject.Properties[$k]) { $e.$k = $Updates[$k] } else { $e | Add-Member -NotePropertyName $k -NotePropertyValue $Updates[$k] } }
  if (@($e.PSObject.Properties).Count -gt 0) {
    if ($d.PSObject.Properties['env']) { $d.env = $e } else { $d | Add-Member -NotePropertyName 'env' -NotePropertyValue $e }
  } elseif ($d.PSObject.Properties['env']) { $d.PSObject.Properties.Remove('env') }
  Write-Settings $d
}
function Set-AuthMode($m) {
  try { $h = [IO.File]::ReadAllText($HarnessPath) | ConvertFrom-Json; if ($h.PSObject.Properties['auth_mode']) { $h.auth_mode = $m } else { $h | Add-Member -NotePropertyName auth_mode -NotePropertyValue $m }; Write-Utf8NoBom $HarnessPath (($h | ConvertTo-Json -Depth 8) + "`n") } catch {}
}
function Get-HarnessVersion { try { return ([IO.File]::ReadAllText($HarnessPath) | ConvertFrom-Json).version } catch { return $null } }
function Get-Status {
  $envObj = $null; $err = $null
  try { $d = Read-Settings; if ($d.PSObject.Properties['env']) { $envObj = $d.env } } catch { $err = $_.Exception.Message }
  $has = { param($k) ($envObj -and $envObj.PSObject.Properties[$k] -and $envObj.$k) }
  $mode = 'none'
  if ($env:ANTHROPIC_AUTH_TOKEN -or (& $has 'ANTHROPIC_AUTH_TOKEN')) { $mode = 'gateway' }
  elseif ($env:ANTHROPIC_API_KEY -or (& $has 'ANTHROPIC_API_KEY')) { $mode = 'api-key' }
  elseif (Test-Path (Join-Path $ClaudeHome '.credentials.json')) { $mode = 'subscription' }
  return @{ ok = $true; mode = $mode; settings_path = $SettingsPath; harness_version = (Get-HarnessVersion); settings_error = $err }
}
function Test-AnthropicKey([string]$Key) {
  try {
    $r = Invoke-WebRequest -Uri 'https://api.anthropic.com/v1/models' -Headers @{ 'x-api-key' = $Key; 'anthropic-version' = '2023-06-01'; 'user-agent' = 'ankr-harness-byok' } -UseBasicParsing -TimeoutSec 10
    return @($true, "Anthropic accepted the key (HTTP $($r.StatusCode)).")
  } catch {
    $code = $null; try { $code = [int]$_.Exception.Response.StatusCode } catch {}
    if ($code -eq 401 -or $code -eq 403) { return @($false, "Anthropic rejected this key (HTTP $code). Check it on console.anthropic.com and paste again.") }
    if ($code) { return @($null, "Anthropic answered HTTP $code; the key was saved unverified.") }
    return @($null, "Could not reach Anthropic; the key was saved unverified.")
  }
}
function Save-AnthropicKey([string]$Key, [bool]$Verify) {
  $Key = ($Key + '').Trim()
  if ($Key -notmatch $KeyRe) { return @{ ok = $false; error = 'That does not look like an Anthropic API key (they start with sk-ant- and are long). Nothing was written.' } }
  $note = $null
  if ($Verify) { $v = Test-AnthropicKey $Key; if ($v[0] -eq $false) { return @{ ok = $false; error = $v[1] } }; if ($null -eq $v[0]) { $note = $v[1] } }
  Set-EnvBlock @{ ANTHROPIC_API_KEY = $Key } @('ANTHROPIC_AUTH_TOKEN', 'ANTHROPIC_BASE_URL')
  Set-AuthMode 'api-key'
  return @{ ok = $true; message = "Key saved to $SettingsPath. Any gateway setting was removed."; verified = ($Verify -and $null -eq $note); note = $note }
}
function Save-Gateway([string]$Base, [string]$Token) {
  $Base = ($Base + '').Trim(); $Token = ($Token + '').Trim()
  if ($Base -notmatch '^https?://[^\s/]+') { return @{ ok = $false; error = 'The base URL must start with http:// or https://. Nothing was written.' } }
  if ($Token.Length -lt 8) { return @{ ok = $false; error = 'The token is too short to be real. Nothing was written.' } }
  Set-EnvBlock @{ ANTHROPIC_BASE_URL = $Base; ANTHROPIC_AUTH_TOKEN = $Token } @('ANTHROPIC_API_KEY')
  Set-AuthMode 'gateway'
  return @{ ok = $true; message = "Gateway saved to $SettingsPath - unverified. If Claude Code cannot talk to it, come back and remove it."; verified = $false }
}
function Use-Subscription { Set-EnvBlock @{} $EnvKeys; Set-AuthMode 'subscription'; return @{ ok = $true; message = 'Any saved key or gateway was removed. Type claude and sign in when the browser opens.' } }
function Remove-All { Set-EnvBlock @{} $EnvKeys; Set-AuthMode $null; return @{ ok = $true; message = 'Removed.' } }

function Send-Json($Res, [int]$Code, $Obj) {
  $b = [Text.Encoding]::UTF8.GetBytes(($Obj | ConvertTo-Json -Depth 8 -Compress))
  $Res.StatusCode = $Code; $Res.ContentType = 'application/json; charset=utf-8'; $Res.Headers['Cache-Control'] = 'no-store'
  $Res.ContentLength64 = $b.Length; $Res.OutputStream.Write($b, 0, $b.Length); $Res.OutputStream.Close()
}
function Start-Server {
  $token = -join ((1..32) | ForEach-Object { 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789'[(Get-Random -Maximum 62)] })
  $page = [IO.File]::ReadAllBytes($HtmlPath)
  $listener = $null; $p = $Port
  for ($p = $Port; $p -lt ($Port + 10); $p++) {
    $l = New-Object System.Net.HttpListener
    $l.Prefixes.Add("http://localhost:$p/")
    try { $l.Start(); $listener = $l; break } catch { $l = $null }
  }
  if (-not $listener) {
    Write-Host "BYOK: could not listen on localhost (ports $Port-$($Port+9)). Use the terminal floor instead:"
    Write-Host "  powershell -ExecutionPolicy Bypass -File `"$PSCommandPath`" -Terminal"
    exit 1
  }
  $url = "http://localhost:$p/?t=$token"
  Write-Host "BYOK page: $url"
  if (-not $NoOpen) { try { Start-Process $url | Out-Null } catch {} }
  $last = Get-Date
  $running = $true
  while ($running) {
    $task = $listener.GetContextAsync()
    while (-not $task.Wait(5000)) { if (((Get-Date) - $last).TotalSeconds -gt $Idle) { $running = $false; break } }
    if (-not $running) { break }
    $ctx = $task.Result; $req = $ctx.Request; $res = $ctx.Response; $last = Get-Date
    try {
      $host_ = ($req.Headers['Host'] + '').Split(':')[0]
      if ($host_ -notin @('127.0.0.1', 'localhost', '[::1]', '::1')) { Send-Json $res 403 @{ ok = $false; error = 'wrong host' }; continue }
      $path = $req.Url.AbsolutePath
      if ($req.HttpMethod -eq 'GET' -and $path -eq '/') {
        $res.StatusCode = 200; $res.ContentType = 'text/html; charset=utf-8'; $res.Headers['Cache-Control'] = 'no-store'; $res.Headers['X-Frame-Options'] = 'DENY'
        $res.ContentLength64 = $page.Length; $res.OutputStream.Write($page, 0, $page.Length); $res.OutputStream.Close(); continue
      }
      if ($req.Headers['X-ANKR-Token'] -ne $token) { Send-Json $res 403 @{ ok = $false; error = 'token' }; continue }
      if ($req.HttpMethod -eq 'GET' -and $path -eq '/api/status') { Send-Json $res 200 (Get-Status); continue }
      if ($req.HttpMethod -ne 'POST') { Send-Json $res 404 @{ ok = $false; error = 'not found' }; continue }
      $body = @{}
      if ($req.HasEntityBody) { $sr = New-Object IO.StreamReader($req.InputStream, $req.ContentEncoding); $txt = $sr.ReadToEnd(); $sr.Close(); if ($txt.Trim()) { try { $body = $txt | ConvertFrom-Json } catch { Send-Json $res 400 @{ ok = $false; error = 'bad JSON' }; continue } } }
      $r = $null
      switch ($path) {
        '/api/anthropic-key' { $verify = $true; if ($body.PSObject.Properties['verify']) { $verify = [bool]$body.verify }; $r = Save-AnthropicKey ($body.key) $verify }
        '/api/gateway'       { $r = Save-Gateway ($body.base_url) ($body.token) }
        '/api/subscription'  { $r = Use-Subscription }
        '/api/remove'        { $r = Remove-All }
        '/api/close'         { Send-Json $res 200 @{ ok = $true }; $running = $false; continue }
        default              { Send-Json $res 404 @{ ok = $false; error = 'not found' }; continue }
      }
      if ($r.ok) { Send-Json $res 200 $r } else { Send-Json $res 400 $r }
    } catch {
      try { Send-Json $res 500 @{ ok = $false; error = $_.Exception.Message } } catch {}
    }
  }
  $listener.Stop()
  Write-Host 'BYOK helper stopped.'
}

function Convert-Secure([Security.SecureString]$s) { $b = [Runtime.InteropServices.Marshal]::SecureStringToBSTR($s); try { return [Runtime.InteropServices.Marshal]::PtrToStringBSTR($b) } finally { [Runtime.InteropServices.Marshal]::ZeroFreeBSTR($b) } }
function Start-Terminal {
  if ($FromStdin) { $key = [Console]::In.ReadLine(); $r = Save-AnthropicKey $key (-not $NoVerify) }
  else {
    Write-Host "ANKR - your key stays on this computer (written to $SettingsPath)."
    Write-Host '1) I pay Anthropic for Claude (subscription)  2) I have an Anthropic API key  3) remove any saved key'
    $c = (Read-Host 'Choose 1, 2 or 3').Trim()
    if ($c -eq '1') { $r = Use-Subscription }
    elseif ($c -eq '3') { $r = Remove-All }
    else { $sec = Read-Host 'Paste the key (it will not be shown)' -AsSecureString; $r = Save-AnthropicKey (Convert-Secure $sec) (-not $NoVerify) }
  }
  if ($r.ok) { Write-Host ("OK: " + $r.message) } else { Write-Host ("NOT SAVED: " + $r.error) }
  if ($r.note) { Write-Host ("Note: " + $r.note) }
  if ($r.ok) { exit 0 } else { exit 1 }
}

try {
  if ($Status) { (Get-Status) | ConvertTo-Json -Compress; exit 0 }
  if ($Terminal) { Start-Terminal }
  if ($Mode) {
    switch ($Mode) {
      'subscription' { $r = Use-Subscription }
      'remove'       { $r = Remove-All }
      'gateway'      { $tok = ''; if ($TokenFromStdin) { $tok = [Console]::In.ReadLine() }; $r = Save-Gateway $BaseUrl $tok }
      default        { $r = @{ ok = $false; error = 'unknown mode' } }
    }
    $r | ConvertTo-Json -Compress; if ($r.ok) { exit 0 } else { exit 1 }
  }
  if ($Serve) {
    if ($Background) {
      $log = Join-Path ([IO.Path]::GetTempPath()) "ankr-byok-$PID.log"
      Start-Process -FilePath ((Get-Process -Id $PID).Path) -ArgumentList @('-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', "`"$PSCommandPath`"", '-Serve', '-Port', "$Port", '-Idle', "$Idle") -WindowStyle Hidden -RedirectStandardOutput $log | Out-Null
      for ($i = 0; $i -lt 20; $i++) { Start-Sleep -Milliseconds 300; if ((Test-Path $log) -and (Select-String -Path $log -Pattern 'BYOK page:' -Quiet)) { break } }
      if ((Test-Path $log) -and (Select-String -Path $log -Pattern 'BYOK page:' -Quiet)) { (Select-String -Path $log -Pattern 'BYOK page:').Line; exit 0 }
      Write-Host 'BYOK helper did not start.'; if (Test-Path $log) { Get-Content $log }; exit 1
    }
    Start-Server; exit 0
  }
  Write-Host 'usage: byok.ps1 -Serve | -Terminal | -Mode <m> | -Status'; exit 2
} catch {
  Write-Host ("NOT SAVED: " + $_.Exception.Message); exit 1
}
