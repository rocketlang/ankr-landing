THE TANK THAT WASN'T THERE: WHOLE-RUN SERIES, PRE-IMAGES

This folder holds the files whose SHA-256 values are in the pre-registration, Sigstore log
index 3438316337 (24 October 2026, 08:17:03Z), so that anyone can check each value.

  _preregistration.json   the text entered on the log (1,883 bytes)
  whole-run-plan-for-shayne--v2.3--2026-10-23.txt   the plan        -> plan_sha256
  _manifest.json          the run list, with its seed                -> run_list_sha256
  code/                   the 18 files of the run and scoring code   -> code.files
                          exactly as at git commit 93d44fd72

To check: compare `sha256sum` of each file with the value the pre-registration gives it,
and the SHA-256 of _preregistration.json with the hash in the log entry.
SHA256SUMS lists them all.

code/verdict-verify/ is Verdict's published reference verifier (github.com/verdictsystems/ser-spec,
commit 17c9c8f449), copied unchanged, Apache-2.0 (its LICENSE is beside it), with Rekor's public key
from Sigstore's trusted root.

The code is published so its hashes can be checked. It is not a package: it names paths on the
machine that ran the series and does not run elsewhere as it stands.
