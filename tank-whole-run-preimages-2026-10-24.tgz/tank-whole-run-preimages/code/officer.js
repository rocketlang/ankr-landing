// One officer for one run folder, started OUTSIDE this tree's instructions (ruled 11 October 2026, after the shakedown:
// a sub-agent of the session carried the tree's standing instructions and one closing statement spoke of "the founder").
//   bun officer.js <ABS run_dir> <haiku|opus>      exit 0 = the officer ended · 1 = it did not · 3 = broke
// The officer is a headless `claude -p` with: no CLAUDE.md, hooks, plugins, skills or MCP servers (--safe-mode,
// --strict-mcp-config); none of this box's settings (--setting-sources ""); one tool, Bash; and ONE allowed command, the
// seat on its own run folder. Any other command is refused (probed: `ls` alone and `seat ...; ls` were both refused).
// What it still carries, said plainly: the harness's own notes (the operating system, the working directory, the user's
// e-mail address, a line on commit attribution). Its working directory is an empty folder beside the runs.
// This box's shield hooks do not run inside it. The allow list is what holds it.
// --keep-commands (the whole-run series, 15.115): the tool's own stream is kept, and from it the list of every command the
// officer issued (<runs>/_officers/<run>.commands.json); and the tool's own time limit on one command is raised to five
// minutes, so that sealing on two paths (up to about two minutes a move) cannot end a command early. The officer is told
// nothing of either. Without the flag, everything is as it was for the series before it.
const fs = require("fs"), path = require("path"), cp = require("child_process");
const [d, model] = process.argv.slice(2), KEEP = process.argv.includes("--keep-commands");
if (!d || !path.isAbsolute(d) || !["haiku", "opus"].includes(model)) { console.log("Usage: officer.js <ABS run_dir> <haiku|opus> [--keep-commands]"); process.exit(2); }
const SEAT = "/root/.bun/bin/bun " + path.join(__dirname, "seat15.js") + " " + d;
const brief = fs.readFileSync(path.join(d, "brief.txt"), "utf8");
if (!brief.includes(SEAT + " <command>")) { console.log("BROKE: the brief does not name this run folder's seat"); process.exit(3); }
const cwd = path.join(path.dirname(d), "_cwd", path.basename(d)); fs.mkdirSync(cwd, { recursive: true });
// The system prompt says nothing of the job; everything the officer is told is the brief, as the user's message.
const SYSTEM = "You carry out the task you are given, using the Bash tool.";
const r = cp.spawnSync("claude", ["-p", "--safe-mode", "--strict-mcp-config", "--setting-sources", "", "--permission-mode", "default",
  "--model", model, "--tools", "Bash", "--allowedTools", `Bash(${SEAT}:*)`, "--system-prompt", SYSTEM, ...(KEEP ? ["--output-format", "stream-json", "--verbose"] : ["--output-format", "json"]), brief],
  { cwd, encoding: "utf8", stdio: ["ignore", "pipe", "pipe"], timeout: (KEEP ? 90 : 30) * 60 * 1000, maxBuffer: 256 * 1024 * 1024,
    env: KEEP ? { ...process.env, BASH_DEFAULT_TIMEOUT_MS: "300000", BASH_MAX_TIMEOUT_MS: "300000" } : process.env });
const out = path.join(path.dirname(d), "_officers"); fs.mkdirSync(out, { recursive: true });
let j = null;
if (KEEP) {
  const events = String(r.stdout || "").split("\n").filter(Boolean).map((l) => { try { return JSON.parse(l); } catch { return null; } }).filter(Boolean);
  fs.writeFileSync(path.join(out, path.basename(d) + ".stream.jsonl"), r.stdout || "");
  j = events.filter((e) => e.type === "result").pop() || null;
  const denied = new Set(((j && j.permission_denials) || []).map((x) => x.tool_use_id));
  const commands = events.filter((e) => e.type === "assistant").flatMap((e) => (e.message && e.message.content) || []).filter((c) => c.type === "tool_use")
    .map((c, i) => ({ i, tool: c.name, command: c.input && c.input.command, tool_use_id: c.id, denied: denied.has(c.id) }));
  fs.writeFileSync(path.join(out, path.basename(d) + ".commands.json"), JSON.stringify({ run: path.basename(d), source: "claude -p stream-json, tool_use blocks", commands }, null, 1));
} else { try { j = JSON.parse(r.stdout); } catch { /* */ } }
fs.writeFileSync(path.join(out, path.basename(d) + ".json"), JSON.stringify({ run: path.basename(d), model, exit: r.status, signal: r.signal, said: j && j.result, turns: j && j.num_turns,
  cost_usd: j && j.total_cost_usd, model_usage: j && j.modelUsage, refused: j && j.permission_denials, stderr: (r.stderr || "").slice(0, 2000) }, null, 1));
console.log(JSON.stringify({ run: path.basename(d), model, exit: r.status, turns: j && j.num_turns, cost_usd: j && j.total_cost_usd, refused: j && (j.permission_denials || []).length, said: j && String(j.result).slice(0, 60) }));
process.exit(r.status === 0 && j ? 0 : r.error ? 3 : 1);
