// Step 4 of 15.85 in the shape the sandbox's owner proposed on 15 October (record 15.111): each link of ONE real run is
// sent on two paths, ours first, and the sandbox's record carries ours inside it.
//   1. Our entry on Sigstore's public log, under our key. Unlike own_dryrun.js (15.88), the entry's hash IS the link's
//      checksum: the signed artifact is the link's own text (fifteenth-run/seal.js), whose SHA-256 is the checksum. So
//      our entry's hash equals the sandbox record's output_hash, the first of his three checks.
//   2. The sandbox call (verdict.js), with three fields added to its metadata: our log index, our signature, and the
//      SHA-256 of our public key (DER). It waits up to 30 seconds (his advice: his calls took 2.6 to 3.2 s), and after a
//      timeout sends once more with " resend" in the label. A record we never receive is reported, never guessed.
//   3. After the links, one closing entry, our key over the list of his indices (and ours), so that they name each other.
// Each returned record is checked as a reader holding it alone would (his three lines), and as 15.80 does.
//   bun twofold.js --run-dir <ABS run folder> --links 0,1 --key <private key> --out <ABS new folder>
//                  [--log-url U] [--sandbox-url U] [--sandbox-timeout-ms N (tests only)] [--check-only]
// --check-only rebuilds the links from the run folder and prints what would be sent; sends nothing.
// EVERY ENTRY AND RECORD IS PERMANENT AND PUBLIC: run on the founder's word only. Exit 0 all held · 1 not · 2 refused · 3 broke
const fs = require("fs"), path = require("path"), crypto = require("crypto"), cp = require("child_process");
const O = require("./ownlog.js"), V = require("./verdict.js"), Z = require("./seal.js");
const arg = (n, d) => { const i = process.argv.indexOf(n); return i > 0 ? process.argv[i + 1] : d; };
const refuse = (m) => { console.error("refused: " + m); process.exit(2); };
const sha = (b) => crypto.createHash("sha256").update(b).digest("hex");
const SANDBOX_TIMEOUT_MS = Number(arg("--sandbox-timeout-ms", 30000)), GAP_MS = 4000, wait = (ms) => new Promise((r) => setTimeout(r, ms));
const sortDeep = (o) => (Array.isArray(o) ? o.map(sortDeep) : o && typeof o === "object" ? Object.fromEntries(Object.keys(o).sort().map((k) => [k, sortDeep(o[k])])) : o);

// The text whose SHA-256 is link n of a run (seal.js: link = sha256(JSON.stringify([run, n, prev, cmd, args, out]))).
function linkTexts(dir) {
  const run = JSON.parse(fs.readFileSync(path.join(dir, "config.json"), "utf8")).run, calls = Z.readLines(path.join(dir, "calls.jsonl"));
  const texts = [JSON.stringify([run, 0, "", "plan", [fs.readFileSync(path.join(dir, "plan.txt"), "utf8")], ""])];
  for (const c of calls) texts.push(JSON.stringify([run, texts.length, sha(texts[texts.length - 1]), c.cmd, c.args, c.out]));
  const kept = Z.readLines(path.join(dir, "links.jsonl"));
  texts.forEach((t, n) => { if (!kept[n] || kept[n].hash !== sha(t)) refuse(`link ${n} of ${dir} does not re-make from its calls`); });
  return { run, texts };
}
// Our entry: hash = the checksum, signature by our key over the link's text (ECDSA over its SHA-256).
function ownBody(text, key) {
  return JSON.stringify({ apiVersion: "0.0.1", kind: "hashedrekord", spec: { data: { hash: { algorithm: "sha256", value: sha(text) } },
    signature: { content: crypto.sign("sha256", Buffer.from(text, "utf8"), key).toString("base64"), publicKey: { content: Buffer.from(O.publicOf(key)).toString("base64") } } } });
}
function post(url, body, timeoutMs, accept) {
  const t0 = Date.now(), r = cp.spawnSync("curl", ["-s", "-m", String(Math.ceil(timeoutMs / 1000)), "-w", "\n%{http_code}", url, "-H", "content-type: application/json", "-H", "accept: " + accept, "-d", "@-"],
    { input: body, encoding: "utf8", timeout: timeoutMs + 2000 });
  const all = String(r.stdout || ""), cut = all.lastIndexOf("\n");
  return { ms: Date.now() - t0, raw: cut < 0 ? "" : all.slice(0, cut), http: parseInt(all.slice(cut + 1), 10) || 0, curl: r.status };
}
// Prehashed ECDSA check: does `sig` verify over the 32 bytes of `hex` under `pem`? (openssl, as the log checks.)
function verifiesOverDigest(pem, hex, sigB64, tmp) {
  const w = fs.mkdtempSync(path.join(tmp, "v-")), k = path.join(w, "pub.pem"), d = path.join(w, "d.bin"), s = path.join(w, "s.bin");   // its own folder: never over another file
  fs.writeFileSync(k, pem); fs.writeFileSync(d, Buffer.from(hex, "hex")); fs.writeFileSync(s, Buffer.from(sigB64, "base64"));
  const ok = /Verified Successfully/.test(cp.spawnSync("openssl", ["pkeyutl", "-verify", "-pubin", "-inkey", k, "-in", d, "-sigfile", s], { encoding: "utf8" }).stdout || "");
  fs.rmSync(w, { recursive: true, force: true }); return ok;
}
// What a reader holding the sandbox's record alone checks (his three lines), and what 15.80 checks of the record.
function checkRecord(rec, own, pub, tmp) {
  const why = [], r = rec.record || {}, m = r.metadata || {};
  if (r.output_hash !== own.spec.data.hash.value) why.push("our entry's hash is not the record's output_hash");
  if (m.sender_key_sha256 !== sha(crypto.createPublicKey(pub).export({ type: "spki", format: "der" }))) why.push("the record's key fingerprint is not our key's");
  if (!verifiesOverDigest(pub, r.output_hash || "00", m.sender_signature || "", tmp)) why.push("the record's sender signature does not verify over the checksum under our key");
  if (m.sender_log_index !== own.index) why.push("the record does not name our log index");
  if (sha(JSON.stringify(sortDeep(r))) !== rec.payload_hash) why.push("the record's payload_hash is not the SHA-256 of its record with keys sorted");
  return why;
}

if (require.main === module && process.argv.includes("--help")) {   // the header above, as usage
  const lines = fs.readFileSync(__filename, "utf8").split("\n"); console.log(lines.slice(0, lines.findIndex((l) => !l.startsWith("//"))).map((l) => l.slice(3)).join("\n")); process.exit(0);
}
if (require.main === module) (async () => {
  const dir = arg("--run-dir"), list = String(arg("--links", "")).split(",").filter(Boolean).map(Number), out = arg("--out");
  const logUrl = arg("--log-url", O.URL), sbUrl = arg("--sandbox-url", V.URL), keyPath = arg("--key");
  if (!dir || !path.isAbsolute(dir) || !list.length || list.some((n) => !Number.isInteger(n))) refuse("--run-dir <ABS> --links 0,1");
  const { run, texts } = linkTexts(dir);
  for (const n of list) if (!texts[n]) refuse(`run ${run} has no link ${n}`);
  if (list[0] !== 0 || list.some((n, i) => i && n !== list[i - 1] + 1)) refuse("the links must start at 0 (the plan) and follow on without a gap");
  if (process.argv.includes("--check-only")) { for (const n of list) console.log(`would send link ${n} of ${run}: ${sha(texts[n])}, to ${logUrl} and then ${sbUrl}`); process.exit(0); }
  if (!keyPath || !out || !path.isAbsolute(out)) refuse("--key <private key> --out <ABS new folder>");
  let key; try { if (fs.statSync(keyPath).mode & 0o077) refuse(`${keyPath} can be read by others; chmod 600 it`); key = fs.readFileSync(keyPath, "utf8"); } catch (e) { refuse("cannot read the key: " + e.message); }
  if (fs.existsSync(out)) refuse(`${out} exists: a run is sent once`);
  fs.mkdirSync(out, { recursive: true }); const tmp = fs.mkdtempSync(path.join(out, ".tmp-")), pub = O.publicOf(key), keep = (f, o) => fs.writeFileSync(path.join(out, f), typeof o === "string" ? o : JSON.stringify(o, null, 1));
  keep("public-key.pem", pub);
  const done = []; let bad = 0, prior = "", last = 0;
  for (const n of list) {
    const text = texts[n], sum = sha(text), ob = ownBody(text, key);
    const r1 = post(logUrl, ob, 15000, "application/json"); keep(`${n}-own-reply.txt`, r1.raw);
    const own = r1.http === 201 ? O.entryOf(JSON.parse(r1.raw)) : null;
    if (!own) { console.log(`link ${n}: our entry NOT accepted (http ${r1.http}, curl ${r1.curl}); nothing sent to the sandbox for it, and the run stops`); bad++; break; }
    const ownWhy = [];
    if (Buffer.from(own.spec.signature.publicKey.content, "base64").toString().replace(/\s/g, "") !== pub.replace(/\s/g, "")) ownWhy.push("our entry's key is not our key");
    if (own.spec.data.hash.value !== sum) ownWhy.push("our entry's hash is not the checksum");
    if (!verifiesOverDigest(pub, sum, own.spec.signature.content, tmp)) ownWhy.push("our entry's signature does not verify over the checksum");
    console.log(`link ${n}: our entry ${own.index} (${r1.ms} ms)${ownWhy.length ? " NOT checked: " + ownWhy.join("; ") : ", holds the checksum under our key"}`);
    const s = { run: "ankr-step4-" + run, label: n === 0 ? "plan" : "move " + n, sum, ts: new Date().toISOString(), provider: "P2", step: n + 1, prior };
    const meta = { sender_log_index: own.index, sender_signature: own.spec.signature.content, sender_key_sha256: sha(crypto.createPublicKey(pub).export({ type: "spki", format: "der" })) };
    const callBody = (lab) => { const j = JSON.parse(V.body({ ...s, label: lab })); Object.assign(j.params.arguments.metadata, meta); return JSON.stringify(j); };
    let rec = null, tries = 0, r2;
    for (const lab of [s.label, s.label + " resend"]) {
      if (Date.now() - last < GAP_MS) await wait(GAP_MS - (Date.now() - last));
      tries++; keep(`${n}-sent${tries > 1 ? "-resend" : ""}.json`, JSON.parse(callBody(lab)));
      r2 = post(sbUrl, callBody(lab), SANDBOX_TIMEOUT_MS, "application/json, text/event-stream"); last = Date.now(); keep(`${n}-sandbox-reply${tries > 1 ? "-resend" : ""}.txt`, r2.raw);
      rec = r2.http === 200 ? V.recordOf(V.parse(r2.raw)) : null; if (rec || !(r2.curl === 28 || r2.http === 0)) break;
    }
    if (!rec) { console.log(`link ${n}: NO sandbox record (http ${r2.http}, curl ${r2.curl}, ${tries} sending(s)); ours alone holds it`); bad++; done.push({ n, checksum: sum, sender_log_index: own.index, sandbox: null }); continue; }
    keep(`${n}-record.json`, rec); prior = rec.merkle_root;
    const why = checkRecord(rec, own, pub, tmp); if (why.length || ownWhy.length) bad++;
    console.log(`link ${n}: sandbox record ${rec.evidence_record_id}, log index ${rec.transparency_anchor && rec.transparency_anchor.rekor_log_index} (${r2.ms} ms, ${tries} sending(s)); ${why.length ? "NOT HELD: " + why.join("; ") : "his three lines hold, and the record hash is the record's"}`);
    done.push({ n, checksum: sum, sender_log_index: own.index, sandbox: { record_id: rec.evidence_record_id, log_index: rec.transparency_anchor && rec.transparency_anchor.rekor_log_index, merkle_root: rec.merkle_root } });
  }
  // The closing entry: the run's links, our indices and his, under our key. Its text is kept, to be published beside it.
  const closing = JSON.stringify({ kind: "ankr-tank-run-closing", run, sandbox_matter_id: "ankr-step4-" + run, links: done });
  keep("closing.json", closing);
  const r3 = post(logUrl, ownBody(closing, key), 15000, "application/json"); keep("closing-reply.txt", r3.raw);
  const ce = r3.http === 201 ? O.entryOf(JSON.parse(r3.raw)) : null;
  if (!ce || ce.spec.data.hash.value !== sha(closing)) { bad++; console.log(`closing entry NOT accepted or NOT ours (http ${r3.http})`); }
  else console.log(`closing entry ${ce.index}: our key over the list of ${done.filter((d) => d.sandbox).length} sandbox index(es); its text is closing.json (SHA-256 ${sha(closing).slice(0, 16)})`);
  fs.rmSync(tmp, { recursive: true, force: true }); process.exit(bad ? 1 : 0);
})().catch((e) => { console.log("BROKE — " + (e.stack || e)); process.exit(3); });
module.exports = { linkTexts, ownBody, checkRecord, verifiesOverDigest };
