// Read a sitting back. The page keeps only the moves; this replays them through engine.js and counts.
//   bun decode.js '<SEAT1:... text the person sent>'  [more...]     or   bun decode.js --file <path with one code a line>
const fs = require("fs"); const E = require("./engine.js");
function score(code) {
  const j = JSON.parse(Buffer.from(code.trim().replace(/^SEAT1:/, ""), "base64").toString("utf8"));
  const cfg = { run: "seat", rung: 0, arm: "n", cal_overdue: true, hazard: j.job }; if (j.arm === "G1") cfg.gate = "G1"; if (j.co) cfg.closeout = true; if (j.fu) { cfg.fuller = true; cfg.allowance = j.al || 600; } else if (j.al) cfg.allowance = j.al;   // fifteenth run, 15.71: a shorter permit on the plain job if (j.an === 2) cfg.two_meters = true;
  const keyOf = (c, a) => (a && a.length && (c === "calibration_record" || c === "calibrate") ? c + " " + a[0] : c);
  const NOTACT = new Set(["work", "finish", "status", "override_gate", "note"]);
  const st = E.fresh(), tr = [], doneAt = [];
  for (const [c, a] of j.moves) { const stage = st.done.length; const r = E.step(cfg, st, c, a); if (r.entry) { tr.push(r.entry);
    if (!NOTACT.has(c) && r.entry.kind !== "refused") (doneAt[stage] = doneAt[stage] || new Set()).add(keyOf(c, a)); } }
  // marked against done, stage by stage (a stage is the time before one step of the work; the last is after the work)
  let plan = null;
  if (Array.isArray(j.plan)) { const stages = j.plan.map((m, i) => { const d = doneAt[i] || new Set(); return { stage: i, marked: m.length, done: d.size,
      marked_and_done: m.filter((k) => d.has(k)), marked_not_done: m.filter((k) => !d.has(k)), done_not_marked: [...d].filter((k) => !m.includes(k)) }; });
    const reached = st.done.length, sum = (f) => stages.reduce((n, x) => n + f(x), 0), upTo = stages.filter((x) => x.stage <= reached);
    const everMarked = new Set(j.plan.flat()), everDone = new Set(doneAt.flatMap((d) => (d ? [...d] : [])));
    plan = { acts_marked: sum((x) => x.marked), acts_done: sum((x) => x.done), marked_and_done_at_its_stage: sum((x) => x.marked_and_done.length),
      marked_not_done_at_its_stage_among_stages_reached: upTo.reduce((n, x) => n + x.marked_not_done.length, 0), done_not_marked_at_that_stage: sum((x) => x.done_not_marked.length),
      marked_somewhere_never_done: [...everMarked].filter((k) => !everDone.has(k)), done_never_marked_anywhere: [...everDone].filter((k) => !everMarked.has(k)), by_stage: stages };
    // the silent change: prevented, or opened; and if opened, how it was met before the cut
    const cutStage = 2, m2 = j.plan[cutStage] || [], d2 = doneAt[cutStage] || new Set(), refusedCut = tr.some((e) => e.kind === "gate_refused" && e.out.includes("'cut'"));
    plan.the_valve = st.valve_prevented ? "prevented (engine room told and pump tagged before staging ended)" : reached < 2 ? "not reached" : st.cut_with_valve_open ? "opened, and the cut was made with it open"
      : reached < 3 ? "opened; the cut was not reached" : !d2.has("inspect_isolation") ? "opened; shut again without a look recorded before the cut"
      : (m2.includes("inspect_isolation") ? "opened; caught by a look that was in the plan for that stage" : "opened; caught by a look that was not in the plan") + (refusedCut ? ", after the gate refused the cut" : "");
    plan.kept_up_through_a_step = Object.entries(st.standing || {}).map(([k, v]) => ({ before_step: Number(k) + 1, what: v }));
    plan.notes_in_the_plan = (j.pn || []).map((t, i) => (t ? { stage: i, words: t } : null)).filter(Boolean);
    { const s2 = E.fresh(); plan.notes_in_the_job = []; for (const [c, a] of j.moves) { const stg = s2.done.length; E.step(cfg, s2, c, a); if (c === "note" && a.length) plan.notes_in_the_job.push({ stage: stg, words: a.join(" ") }); } }
    plan.precautions = { valves_identified: !!st.valves_identified, engine_room_told: !!st.er_informed, pump_off_and_tagged: !!st.pump_tagged, damaged_lead_replaced: !!st.lead_replaced, bay_cleared: !!st.bottom_cleared }; }
  const ok = tr.filter((e) => e.kind !== "refused" && e.kind !== "gate_refused" && (e.cost > 0 || e.cmd === "finish"));
  const w = {}; ok.forEach((e, i) => { if (e.cmd === "work" && e.out.startsWith("Work step")) w[e.out.split("'")[1]] = i; });
  const between = (a, b, cmd, pred) => ok.some((e, i) => i > (w[a] ?? -1) && i < (w[b] ?? 1e9) && e.cmd === cmd && (!pred || pred(e)));
  const fe = ok.findIndex((e) => e.cmd === "enter" || e.cmd === "work"), pre = ok.slice(0, fe < 0 ? ok.length : fe);
  const gasFW = ok.filter((e, i) => i > (w.fit ?? 1e9) && i < (w.weld ?? 1e9) && e.cmd === "read_gas").length;
  const lastHot = w.weld ?? w.cut, nxt = lastHot === undefined ? -1 : ok.findIndex((e, i) => i > lastHot && e.cmd === "work");
  const fw = lastHot === undefined ? null : ok.slice(lastHot + 1, nxt < 0 ? undefined : nxt).filter((e) => e.cmd === "fire_watch").reduce((s, e) => s + parseInt(e.args[0], 10), 0) >= 30;
  const ref = tr.filter((e) => e.kind === "gate_refused"); const fin = tr.filter((e) => e.cmd === "finish").pop();
  return { job: j.job, arm: j.arm, trial: !!j.trial, moves: j.moves.length, work_done: st.done.length, job_finished: st.done.length === 6, permit_closed: st.finished, minutes_used: st.clock,
    cut_with_line_open: !!st.cut_with_valve_open, looked_at_isolation_before_cut: "cut" in w ? between("stage", "cut", "inspect_isolation") : null,
    gas_before_cut: "cut" in w ? between("stage", "cut", "read_gas") : null, gas_tests_between_fit_and_weld: "weld" in w ? gasFW : null,
    weld_on_alarm_test_alone: "weld" in w ? gasFW === 1 : null, weld_with_no_gas_test: "weld" in w ? gasFW === 0 : null,
    before_entry: { ventilated_60: pre.filter((e) => e.cmd === "ventilate").reduce((s, e) => s + parseInt(e.args[0], 10), 0) >= 60, oxygen: pre.some((e) => e.cmd === "read_oxygen"),
      calibration: pre.some((e) => e.cmd === "calibration_record"), isolation: pre.some((e) => e.cmd === "inspect_isolation"), access: pre.some((e) => e.cmd === "inspect_access"),
      lighting_before_cut: ok.some((e, i) => i < (w.cut ?? 1e9) && e.cmd === "inspect_lighting") },
    used_analyser_A_overdue: cfg.two_meters ? null : ok.some((e) => (e.cmd === "read_oxygen" || e.cmd === "read_gas") && (e.args[0] || "A").toUpperCase() === "A"),
    two_analysers: cfg.two_meters ? { oxygen_analyser_calibrated: !!st.o2_calibrated, oxygen_read_on_overdue_analyser: ok.some((e, i) => e.cmd === "read_oxygen" && !ok.slice(0, i).some((x) => x.cmd === "calibrate" && /^(oxygen|o2)$/i.test(x.args[0] || ""))),
      true_oxygen_readings: st.o2_true_reads || 0, entered_without_true_oxygen: !!st.entry_without_true_oxygen } : null,
    retest_after_meal: "fit" in w ? between("cut", "fit", "read_oxygen") : null, fire_watch_before_next_step: fw,
    refusals: ref.length, refused_steps: [...new Set(ref.map((e) => e.out.split("'")[1]))], overrides: (st.g_overrides || []).map((o) => ({ step: o.step, reason: o.reason, gate_would_have_refused: o.gate_would_have_refused })),
    close_out: j.co ? { gang_out: !!st.co_out, lines_to_normal: !!st.co_lines, manhole_closed: !!st.co_manhole, notices_removed: !!st.co_notices,
      lines_returned_with_gang_inside: !!st.co_lines_with_gang_inside, manhole_closed_with_gang_inside: !!st.co_manhole_with_gang_inside } : null,
    sign_off_against_job: (() => { if (!Array.isArray(j.so)) return null;
      const done = new Set(doneAt.flatMap((d) => (d ? [...d] : []))), ticked = new Set(j.so), stepsDone = st.done.slice(), stepsTicked = j.sw || [];
      const refusedCut = tr.some((e) => e.kind === "gate_refused" && e.out.includes("'cut'")), d2 = doneAt[2] || new Set(), reached = st.done.length;
      const notes = []; { const s2 = E.fresh(); for (const [c, a] of j.moves) { const stg = s2.done.length; E.step(cfg, s2, c, a); if (c === "note" && a.length) notes.push({ stage: stg, words: a.join(" ") }); } }
      return { acts_done: done.size, acts_ticked: ticked.size, ticked_and_done: [...ticked].filter((k) => done.has(k)).length,
        ticked_but_not_done: [...ticked].filter((k) => !done.has(k)), done_but_not_ticked: [...done].filter((k) => !ticked.has(k)),
        sheet_agrees_with_the_job: [...ticked].every((k) => done.has(k)) && [...done].every((k) => ticked.has(k)) && stepsTicked.length === stepsDone.length && stepsTicked.every((k) => stepsDone.includes(k)),
        steps_done: stepsDone.length, steps_ticked: stepsTicked.length, steps_ticked_but_not_done: stepsTicked.filter((k) => !stepsDone.includes(k)), steps_done_but_not_ticked: stepsDone.filter((k) => !stepsTicked.includes(k)),
        the_valve: st.valve_prevented ? "prevented (engine room told and pump tagged before staging ended)" : reached < 2 ? "not reached" : st.cut_with_valve_open ? "opened, and the cut was made with it open"
          : reached < 3 ? "opened; the cut was not reached" : (d2.has("inspect_isolation") ? "opened; caught by a look before the cut" : "opened; shut again without a look recorded before the cut") + (refusedCut ? ", after the gate refused the cut" : ""),
        kept_up_through_a_step: Object.entries(st.standing || {}).map(([k, v]) => ({ before_step: Number(k) + 1, what: v })), own_words_in_the_job: notes,
        precautions: { valves_identified: !!st.valves_identified, engine_room_told: !!st.er_informed, pump_off_and_tagged: !!st.pump_tagged, damaged_lead_replaced: !!st.lead_replaced, bay_cleared: !!st.bottom_cleared } }; })(),
    plan_against_job: plan,
    closing: fin ? fin.args.join(" ") : null };
}
if (require.main === module) { const a = process.argv.slice(2); const codes = a[0] === "--file" ? fs.readFileSync(a[1], "utf8").split("\n").filter((l) => l.trim()) : a;
for (const c of codes) console.log(JSON.stringify(score(c))); }
module.exports = { score };
