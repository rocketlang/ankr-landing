// The runner of the whole-run series (record 15.115).   bun series.js <ABS runs_dir> [--check-only]
// One run at a time, in the manifest's (shuffled) order: the officer (officer.js --keep-commands), then its closing
// entry (close_run.js). The rules the plan sent to the sandbox's owner states, here as code:
// - No run is repeated or replaced. A run with an officer record is done. A run that has begun (state.json) but has no
//   officer record broke: it is written down as broken, never started again.
// - Stop rule: if the last five calls on either path all failed (<runs>/_health.jsonl, written by twopath.js), no new
//   run starts. The run in progress is never stopped by this. Start again only after the sandbox's owner says it is well.
// Every step is appended to <runs>/_series.jsonl. Exit 0 every run done · 1 stopped by the rule or a run broke · 2 refused · 3 broke
// SERIES_OFFICER=<script> stands in a scripted officer for the test (whole_test.js); never set it for the counted series.
const fs = require("fs"), path = require("path"), cp = require("child_process"); const Z = require("./seal.js");
const BUN = process.execPath, H = __dirname, [runs] = process.argv.slice(2), CHECK = process.argv.includes("--check-only");
if (!runs || !path.isAbsolute(runs)) { console.log("Usage: series.js <ABS runs_dir> [--check-only]"); process.exit(2); }
const man = JSON.parse(fs.readFileSync(path.join(runs, "_manifest.json"), "utf8")).runs;
// Before any run: every twopath log's key must be there, readable by its owner alone, and (when the log names
// public_key_file) the key whose public half is that file. A run started without it could seal nothing, and it would
// still be spent: no run is repeated.
for (const l of JSON.parse(fs.readFileSync(path.join(runs, "_logs.json"), "utf8")).filter((x) => x.kind === "twopath")) {
  const no = (m) => { console.log("refused: " + m + "; no run started"); process.exit(2); };
  if (!l.key_file || !path.isAbsolute(l.key_file) || !fs.existsSync(l.key_file)) no(`the ${l.name} log's key_file is not a file: ${String(l.key_file).slice(0, 80)}`);
  if (fs.statSync(l.key_file).mode & 0o077) no(`${l.key_file} can be read by others; chmod 600 it`);
  if (l.public_key_file) { const crypto = require("crypto"), pub = (f) => crypto.createPublicKey(fs.readFileSync(f, "utf8")).export({ type: "spki", format: "der" }).toString("hex");
    let same = false; try { same = pub(l.key_file) === pub(l.public_key_file); } catch { /* not a key */ }
    if (!same) no(`the key in ${l.key_file} is not the one whose public half is ${l.public_key_file}`); }
}
const note = (o) => { const row = { at: new Date().toISOString(), ...o }; fs.appendFileSync(path.join(runs, "_series.jsonl"), JSON.stringify(row) + "\n"); console.log(JSON.stringify(row)); };
const LAST = 5;
function unwell() {
  const h = Z.readLines(path.join(runs, "_health.jsonl")), why = [];
  for (const p of ["own", "sandbox"]) { const t = h.filter((x) => x.path === p).slice(-LAST); if (t.length === LAST && t.every((x) => !x.ok)) why.push(`the last ${LAST} calls on the ${p} path all failed`); }
  return why;
}
let stopped = false, broke = 0;
for (const m of man) {
  const d = path.join(runs, m.run), done = fs.existsSync(path.join(runs, "_officers", m.run + ".json"));
  if (done) continue;
  if (fs.existsSync(path.join(d, "state.json"))) { if (!CHECK) note({ run: m.run, event: "broken", why: "it had begun and has no officer record; counted as broken, not run again" }); broke++; continue; }
  const why = unwell(); if (why.length) { note({ run: m.run, event: "stopped", why }); stopped = true; break; }
  if (CHECK) { console.log(`would run ${m.run} (${m.model}), then its closing entry`); continue; }
  note({ run: m.run, event: "start", model: m.model });
  const off = process.env.SERIES_OFFICER ? [process.env.SERIES_OFFICER, d, m.model] : [path.join(H, "officer.js"), d, m.model, "--keep-commands"];
  const o = cp.spawnSync(BUN, off, { encoding: "utf8", timeout: 100 * 60 * 1000 });
  note({ run: m.run, event: "officer", exit: o.status, said: String(o.stdout || "").trim().slice(-300) });
  const c = cp.spawnSync(BUN, [path.join(H, "close_run.js"), d], { encoding: "utf8", timeout: 120000 });
  note({ run: m.run, event: "closing", exit: c.status, said: String(c.stdout || "").trim().slice(-300) });
}
process.exit(stopped || broke ? 1 : 0);
