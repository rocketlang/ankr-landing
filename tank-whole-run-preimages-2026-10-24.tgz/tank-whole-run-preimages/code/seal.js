// The checksum chain and the senders for the fifteenth run (record 15.66, 15.67).
// A link is SHA-256 over the run's name, the link's number, the previous checksum, the command, its arguments and
// the rig's reply, in that order. Link 0 is the plan. Only checksums are sent anywhere.
const crypto = require("crypto"), fs = require("fs"), path = require("path");
const sha = (s) => crypto.createHash("sha256").update(s, "utf8").digest("hex");
const link = (run, n, prev, cmd, args, out) => sha(JSON.stringify([run, n, prev, cmd, args, out]));
const planLink = (run, text) => link(run, 0, "", "plan", [text], "");
const TIMEOUT_MS = 5000;   // fixed in 15.67: a log that has not answered in five seconds is given up for that entry

// A log is {name, kind, url, every}. `every` true: the plan and each move. false: the plan and the close only.
// kind "standin" is the test's own log (standin_log.js). kind "verdict" is the outside sandbox (verdict.js, record
// 15.79); it needs to know which link this is, so the seat passes `ctx`. No sender is written for a second public log.
const wait = (ms) => new Promise((r) => setTimeout(r, ms));
// The outside sandbox, by the rules of 15.79. ctx = {dir, run, kind, n, at, provider, state}; state = {last_ms, root} is
// kept by the seat between calls. At least gap_ms between two seals of a run. The plan: refused for pace or unanswered,
// wait and send again, up to five sendings. A move: one sending, given up after TIMEOUT_MS, never sent again.
// Whatever comes back is kept whole in <run>/outside/. The next seal carries the root of the last one ACCEPTED.
// `ms` is the time spent in the sendings alone; the waits (the gap, and the plan's waits) are `waited_ms` (mended after 15.83).
async function sendVerdict(log, hash, ctx) {
  const V = require("./verdict.js"), t0 = Date.now(), step = ctx.n + 1, isPlan = ctx.kind === "plan";
  const gap = log.gap_ms ?? 4000, planWait = log.plan_wait_ms ?? 60000, planLimit = log.plan_timeout_ms ?? 20000, out = path.join(ctx.dir, "outside");
  fs.mkdirSync(out, { recursive: true }); const since = Date.now() - (ctx.state.last_ms || 0); let waited = 0, took = 0; if (since < gap) { waited += gap - since; await wait(gap - since); }
  const s = { run: (log.prefix || "") + ctx.run, label: isPlan ? "plan" : "move " + step, sum: hash, ts: ctx.at, provider: ctx.provider, step, prior: ctx.state.root || "" };
  fs.writeFileSync(path.join(out, step + "-sent.json"), V.body(s));
  let r, tries = 0;
  for (;;) { tries++; r = V.sendOnce(s, isPlan ? planLimit : TIMEOUT_MS, log.url); fs.writeFileSync(path.join(out, `${step}-reply${tries > 1 ? "-try" + tries : ""}.txt`), r.raw);
    took += r.ms || 0; if (r.ok || !isPlan || tries >= 5 || (r.http !== 429 && r.http !== 0)) break; waited += planWait; await wait(planWait); }
  ctx.state.last_ms = Date.now(); const rec = r.ok ? V.recordOf(r.reply) : null;
  if (!rec || !/^[0-9a-f]{64}$/.test(String(rec.merkle_root))) return { log: log.name, sealed: false, why: (r.error || "the reply held no record with a root").slice(0, 120), http: r.http, tries, ms: took, waited_ms: waited };
  fs.writeFileSync(path.join(out, step + "-record.json"), JSON.stringify(rec, null, 1)); ctx.state.root = rec.merkle_root;
  return { log: log.name, sealed: true, id: rec.evidence_record_id, index: rec.transparency_anchor && rec.transparency_anchor.rekor_log_index, root: rec.merkle_root, step, tries, ms: took, waited_ms: waited };
}
async function send(log, hash, ctx) {
  if (log.kind === "twopath") return require("./twopath.js").send(log, hash, ctx);   // the whole-run series (15.115); never throws
  const t0 = Date.now();
  if (log.kind === "verdict") { try { return await sendVerdict(log, hash, ctx); } catch (e) { return { log: log.name, sealed: false, why: String(e.message || e).slice(0, 120), ms: Date.now() - t0 }; } }
  try {
    if (log.kind !== "standin") throw new Error("no sender for a log of kind '" + log.kind + "'");
    const r = await fetch(log.url + "/add", { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ hash }), signal: AbortSignal.timeout(TIMEOUT_MS) });
    if (!r.ok) throw new Error("the log answered " + r.status);
    const j = await r.json(); if (typeof j.index !== "number") throw new Error("the log gave no index");
    return { log: log.name, sealed: true, index: j.index, at: j.at, ms: Date.now() - t0 };
  } catch (e) { return { log: log.name, sealed: false, why: String(e.message || e).slice(0, 120), ms: Date.now() - t0 }; }
}
async function entries(log) {
  const r = await fetch(log.url + "/entries", { signal: AbortSignal.timeout(TIMEOUT_MS) }); return (await r.json()).entries;
}
const readLines = (f) => (fs.existsSync(f) ? fs.readFileSync(f, "utf8").split("\n").filter(Boolean).map((l) => JSON.parse(l)) : []);
// Re-make the chain from the calls as they stand in a folder. Returns the checksums, link 0 first.
function remake(dir) {
  const run = JSON.parse(fs.readFileSync(path.join(dir, "config.json"), "utf8")).run;
  const out = [planLink(run, fs.readFileSync(path.join(dir, "plan.txt"), "utf8"))];
  for (const c of readLines(path.join(dir, "calls.jsonl"))) out.push(link(run, out.length, out[out.length - 1], c.cmd, c.args, c.out));
  return out;
}
module.exports = { sha, link, planLink, send, entries, readLines, remake, TIMEOUT_MS };
