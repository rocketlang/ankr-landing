// The whole-run series (record 15.115): each link sent on TWO paths as it happens, in the shape of step 4 (twofold.js),
// inside the live seat. Used only when a log in <runs>/_logs.json has kind "twopath"; nothing else changes.
//   1. Our entry on the public log (Sigstore, or a stand-in), under our key: the signed artifact is the link's own text,
//      so the entry's hash IS the link's checksum. 15 s, then one resend.
//   2. The outside sandbox (verdict.js), its metadata carrying our log index, our signature and our key's fingerprint
//      (empty when our entry failed: the call still goes, and that is counted). 30 s, then ONE resend with " resend" in
//      the label. A resend makes a new record; it never stands for the one that timed out.
// 429: wait the seconds its Retry-After gives (wait_429_ms when it gives none), then the one resend, its label marked
// (the sandbox's owner, 23 Oct). A Retry-After longer than max_429_wait_ms is not waited out: no resend, and counted, so
// one move stays inside the officer tool's two-minute command limit. 5xx and no answer: the one resend. Anything
// else: no resend.
// At least gap_ms between two sandbox calls of a run. Every call is appended to <runs>/_health.jsonl, which the series
// runner reads for its stop rule. Whatever comes back is kept whole in <run>/outside/. Never throws.
// EVERY ENTRY AND RECORD IS PERMANENT AND PUBLIC when the urls are the real ones: the founder's word only.
const fs = require("fs"), path = require("path"), crypto = require("crypto"), cp = require("child_process");
const O = require("./ownlog.js"), V = require("./verdict.js"), T = require("./twofold.js");
const sha = (s) => crypto.createHash("sha256").update(s).digest("hex");
const wait = (ms) => new Promise((r) => setTimeout(r, ms));

function post(url, body, timeoutMs, accept) {
  const t0 = Date.now(), r = cp.spawnSync("curl", ["-s", "-m", String(Math.ceil(timeoutMs / 1000)), "-w", "\n%header{retry-after}\n%{http_code}", url, "-H", "content-type: application/json", "-H", "accept: " + accept, "-d", "@-"],
    { input: body, encoding: "utf8", timeout: timeoutMs + 2000 });
  const all = String(r.stdout || ""), cut = all.lastIndexOf("\n"), cut2 = cut < 0 ? -1 : all.lastIndexOf("\n", cut - 1);
  return { ms: Date.now() - t0, raw: cut2 < 0 ? "" : all.slice(0, cut2), retry_after: cut2 < 0 ? "" : all.slice(cut2 + 1, cut).trim(), http: parseInt(all.slice(cut + 1), 10) || 0, curl: r.status };
}
// What a failed call earns: "wait" (429), "again" (5xx, timeout, no answer), or "stop" (anything else).
const after = (r) => (r.http === 429 ? "wait" : r.http >= 500 || r.http === 0 || r.curl === 28 ? "again" : "stop");
// How long a 429 asks us to wait, in ms: Retry-After as seconds or as a date; wait_429_ms when it gives neither.
function wait429(r, log) {
  const v = String(r.retry_after || ""), s = /^\d+$/.test(v) ? Number(v) * 1000 : Date.parse(v) - Date.now();
  return Number.isFinite(s) && v ? Math.max(0, s) : (log.wait_429_ms ?? 10000);
}
const health = (runs, o) => { try { fs.appendFileSync(path.join(runs, "_health.jsonl"), JSON.stringify({ at: new Date().toISOString(), ...o }) + "\n"); } catch { /* the health file is a help, never a gate on the run */ } };

// The key is read once a call from the file the log names; a key others can read is refused (as twofold.js).
function keyOf(file) {
  if (!file) throw new Error("the twopath log names no key_file");
  if (fs.statSync(file).mode & 0o077) throw new Error(file + " can be read by others; chmod 600 it");
  return fs.readFileSync(file, "utf8");
}

// One link. ctx = {dir, runs, run, kind, n, at, provider, text, state}; state = {last_ms, root} is kept by the seat.
async function send(log, hash, ctx) {
  const t0 = Date.now(), out = path.join(ctx.dir, "outside"), step = ctx.n + 1, label = ctx.kind === "plan" ? "plan" : "move " + step;
  const keep = (f, o) => fs.writeFileSync(path.join(out, f), typeof o === "string" ? o : JSON.stringify(o, null, 1));
  const res = { log: log.name, sealed: false, own: { ok: false, sendings: [] }, sandbox: { ok: false, sendings: [] }, ms: 0, waited_ms: 0 };
  try {
    fs.mkdirSync(out, { recursive: true });
    if (sha(ctx.text) !== hash) throw new Error("the link's text does not give its checksum");
    const key = keyOf(log.key_file), pub = O.publicOf(key);
    // 1. our entry
    let own = null;
    for (let i = 0; i < 2 && !own; i++) {
      const r = post(log.own_url || O.URL, T.ownBody(ctx.text, key), log.own_timeout_ms ?? 15000, "application/json");
      keep(`${step}-own-reply${i ? "-resend" : ""}.txt`, r.raw);
      own = r.http === 201 ? O.entryOf(JSON.parse(r.raw)) : null;
      if (own && own.spec.data.hash.value !== hash) own = null;
      res.own.sendings.push({ http: r.http, curl: r.curl, ms: r.ms, ok: !!own, ...(r.http === 429 ? { retry_after: r.retry_after } : {}) }); res.ms += r.ms;
      health(ctx.runs, { run: ctx.run, step, path: "own", http: r.http, curl: r.curl, ok: !!own });
      if (own) break; const next = after(r); if (next === "stop") break;
      if (next === "wait" && i === 0) { const w = wait429(r, log); if (w > (log.max_429_wait_ms ?? 30000)) { res.own.wait_too_long_ms = w; break; } res.waited_ms += w; await wait(w); }
    }
    if (own) Object.assign(res.own, { ok: true, index: own.index, uuid: own.uuid, integrated_time: own.at });
    // 2. the sandbox, carrying ours (or empty fields when ours failed)
    const meta = own ? { sender_log_index: own.index, sender_signature: own.spec.signature.content, sender_key_sha256: sha(crypto.createPublicKey(pub).export({ type: "spki", format: "der" })) }
      : { sender_log_index: null, sender_signature: "", sender_key_sha256: sha(crypto.createPublicKey(pub).export({ type: "spki", format: "der" })) };
    const s = { run: (log.prefix || "") + ctx.run, label, sum: hash, ts: ctx.at, provider: ctx.provider, step, prior: ctx.state.root || "" };
    const callBody = (lab) => { const j = JSON.parse(V.body({ ...s, label: lab })); Object.assign(j.params.arguments.metadata, meta); return JSON.stringify(j); };
    let rec = null;
    for (const [i, lab] of [label, label + " resend"].entries()) {
      const gap = log.gap_ms ?? 4000, since = Date.now() - (ctx.state.last_ms || 0);
      if (since < gap) { res.waited_ms += gap - since; await wait(gap - since); }
      keep(`${step}-sent${i ? "-resend" : ""}.json`, JSON.parse(callBody(lab)));
      const r = post(log.sandbox_url || V.URL, callBody(lab), log.sandbox_timeout_ms ?? 30000, "application/json, text/event-stream");
      ctx.state.last_ms = Date.now(); keep(`${step}-sandbox-reply${i ? "-resend" : ""}.txt`, r.raw);
      rec = r.http === 200 ? V.recordOf(V.parse(r.raw)) : null;
      if (rec && !/^[0-9a-f]{64}$/.test(String(rec.merkle_root))) rec = null;
      res.sandbox.sendings.push({ label: lab, http: r.http, curl: r.curl, ms: r.ms, ok: !!rec, ...(r.http === 429 ? { retry_after: r.retry_after } : {}) }); res.ms += r.ms;
      health(ctx.runs, { run: ctx.run, step, path: "sandbox", http: r.http, curl: r.curl, ok: !!rec });
      if (rec) break; const next = after(r); if (next === "stop") break;
      if (next === "wait" && i === 0) { const w = wait429(r, log); if (w > (log.max_429_wait_ms ?? 30000)) { res.sandbox.wait_too_long_ms = w; break; } res.waited_ms += w; await wait(w); }
    }
    if (rec) {
      keep(`${step}-record${res.sandbox.sendings.length > 1 ? "-resend" : ""}.json`, rec); ctx.state.root = rec.merkle_root;
      Object.assign(res.sandbox, { ok: true, id: rec.evidence_record_id, index: rec.transparency_anchor && rec.transparency_anchor.rekor_log_index, root: rec.merkle_root, by_resend: res.sandbox.sendings.length > 1 });
      if (own) { const why = T.checkRecord(rec, { index: own.index, spec: own.spec }, pub, out); res.sandbox.names_ours = why.length === 0; if (why.length) res.sandbox.why = why; }
    }
    res.sealed = res.own.ok && res.sandbox.ok;
  } catch (e) { res.why = String(e.message || e).slice(0, 160); }
  res.took_ms = Date.now() - t0; return res;
}
module.exports = { send, after, wait429 };
