// The closing entry of one run of the whole-run series (record 15.115), made after the officer has ended.
//   bun close_run.js <ABS run_dir> [--check-only]
// One entry on our public log, under our key, over closing.json: every link of the run with its checksum, our entry's
// index and the sandbox's record (or null, said as null), and the SHA-256 of the officer's own command list when it was
// kept (officer.js --keep-commands). So the two records name each other for the whole run, and the command list is fixed.
// The log and key are the twopath log's in <runs>/_logs.json. 15 s, then one resend. --check-only writes closing.json
// and sends nothing. EVERY ENTRY IS PERMANENT AND PUBLIC with the real log: the founder's word only.
// Exit 0 entered · 1 not entered · 2 refused · 3 broke
const fs = require("fs"), path = require("path"), crypto = require("crypto");
const O = require("./ownlog.js"), T = require("./twofold.js"), Z = require("./seal.js");
const sha = (s) => crypto.createHash("sha256").update(s).digest("hex");
const [d] = process.argv.slice(2), CHECK = process.argv.includes("--check-only");
const refuse = (m) => { console.log("refused: " + m); process.exit(2); };
if (!d || !path.isAbsolute(d)) refuse("usage: close_run.js <ABS run_dir> [--check-only]");
(async () => {
  const runs = path.dirname(d), run = JSON.parse(fs.readFileSync(path.join(d, "config.json"), "utf8")).run;
  const log = JSON.parse(fs.readFileSync(path.join(runs, "_logs.json"), "utf8")).find((l) => l.kind === "twopath");
  if (!log) refuse("no twopath log in _logs.json");
  if (fs.existsSync(path.join(d, "closing-reply.txt"))) refuse("this run's closing entry was already sent: a run is closed once");
  const links = Z.readLines(path.join(d, "links.jsonl")).map((e) => {
    const s = (e.sent || []).find((x) => x.log === log.name);
    return { n: e.n, kind: e.kind, checksum: e.hash, own: s && s.own && s.own.ok ? { index: s.own.index } : null,
      sandbox: s && s.sandbox && s.sandbox.ok ? { record_id: s.sandbox.id, log_index: s.sandbox.index, merkle_root: s.sandbox.root, by_resend: !!s.sandbox.by_resend } : null,
      sent_outside: !!s };
  });
  const cf = path.join(runs, "_officers", run + ".commands.json");
  const closing = JSON.stringify({ kind: "ankr-tank-run-closing", series: log.prefix || "", run, links,
    officer_commands_sha256: fs.existsSync(cf) ? sha(fs.readFileSync(cf)) : null });
  fs.writeFileSync(path.join(d, "closing.json"), closing);
  const n = links.length, own = links.filter((l) => l.own).length, sb = links.filter((l) => l.sandbox).length;
  if (CHECK) { console.log(`closing.json written for ${run}: ${n} link(s), ${own} with our entry, ${sb} with a sandbox record, command list ${fs.existsSync(cf) ? "hashed" : "not kept"}; nothing sent`); process.exit(0); }
  let key; try { if (fs.statSync(log.key_file).mode & 0o077) refuse(log.key_file + " can be read by others; chmod 600 it"); key = fs.readFileSync(log.key_file, "utf8"); } catch (e) { refuse("cannot read the key: " + e.message); }
  const cp = require("child_process"); let entry = null, last = null;
  for (let i = 0; i < 2 && !entry; i++) {
    const r = cp.spawnSync("curl", ["-s", "-m", String(Math.ceil((log.own_timeout_ms ?? 15000) / 1000)), "-w", "\n%{http_code}", log.own_url || O.URL, "-H", "content-type: application/json", "-d", "@-"],
      { input: T.ownBody(closing, key), encoding: "utf8", timeout: (log.own_timeout_ms ?? 15000) + 2000 });
    const all = String(r.stdout || ""), cut = all.lastIndexOf("\n"), raw = cut < 0 ? "" : all.slice(0, cut), http = parseInt(all.slice(cut + 1), 10) || 0;
    fs.writeFileSync(path.join(d, `closing-reply${i ? "-resend" : ""}.txt`), raw); last = http;
    entry = http === 201 ? O.entryOf(JSON.parse(raw)) : null;
    if (entry && entry.spec.data.hash.value !== sha(closing)) entry = null;
    if (!entry && !(http === 429 || http >= 500 || http === 0)) break;
  }
  if (!entry) { console.log(`closing entry for ${run} NOT entered (http ${last})`); process.exit(1); }
  console.log(`closing entry ${entry.index} for ${run}: ${n} link(s), ${own} with our entry, ${sb} with a sandbox record; closing.json SHA-256 ${sha(closing).slice(0, 16)}`);
  process.exit(0);
})().catch((e) => { console.log("BROKE — " + (e.stack || e)); process.exit(3); });
