// Our own sender for the outside sandbox, written from the line its owner sent (record 15.79). His line is not run.
// One seal = one web call, no key: the tool verdict_create_evidence_record at https://verdict.systems/api/mcp.
// What leaves the box: a run name, a label, a checksum, a time, a provider code, a step number, the previous root.
// The call is made by curl with the body on standard input: no shell, and nothing here is built into a command line.
const cp = require("child_process");
const URL = "https://verdict.systems/api/mcp";
function body(s) {
  if (!/^[0-9a-f]{64}$/.test(s.sum)) throw new Error("a checksum is 64 hex characters");
  return JSON.stringify({ jsonrpc: "2.0", id: 1, method: "tools/call", params: { name: "verdict_create_evidence_record", arguments: {
    matter_id: s.run, workflow: "agentic_action", input_summary: s.label, output_summary: "checksum only", output_hash: s.sum, event_time: s.ts,
    human_review_status: "not_required", model_provider: s.provider, metadata: { step: s.step, prior_merkle_root: s.prior || "" } } } });
}
// The reply is JSON, or a stream of "data:" lines each holding JSON. Returned whole as text, and parsed where it can be.
function parse(text) {
  const tries = [text, ...text.split("\n").filter((l) => l.startsWith("data:")).map((l) => l.slice(5).trim())];
  for (const t of tries) { try { return JSON.parse(t); } catch { /* next */ } } return null;
}
// One sending. Never throws: { ok, http, ms, raw, reply, error }.
function sendOnce(s, timeoutMs, url) {
  const t0 = Date.now(), URL = url || module.exports.URL;
  const r = cp.spawnSync("curl", ["-s", "-m", String(Math.ceil(timeoutMs / 1000)), "-w", "\n%{http_code}", URL, "-H", "content-type: application/json", "-H", "accept: application/json, text/event-stream", "-d", "@-"],
    { input: body(s), encoding: "utf8", timeout: timeoutMs + 2000 });
  const ms = Date.now() - t0, all = String(r.stdout || ""), cut = all.lastIndexOf("\n"), raw = cut < 0 ? "" : all.slice(0, cut), http = parseInt(all.slice(cut + 1), 10) || 0;
  if (r.status !== 0) return { ok: false, http, ms, raw, reply: null, error: "curl ended " + r.status + (r.signal ? " " + r.signal : "") };
  const reply = parse(raw); return { ok: http === 200 && !!reply && !reply.error, http, ms, raw, reply, error: reply && reply.error ? JSON.stringify(reply.error).slice(0, 200) : http === 200 ? null : "http " + http };
}
// The record inside a reply (the tool's text), or null. What we read from it: its ID, its root, its place in the public log.
function recordOf(reply) { try { return JSON.parse(reply.result.content[0].text); } catch { return null; } }
module.exports = { URL, body, parse, sendOnce, recordOf };
