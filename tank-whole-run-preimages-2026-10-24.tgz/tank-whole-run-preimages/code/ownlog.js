// Our OWN entry on the public log, beside the outside sandbox's record (record 15.85). Nothing here is used by the seat yet.
// One entry = one web call, no account: Sigstore's log, kind "hashedrekord". What is entered, by a rule anyone can redo:
//   the artifact is our checksum as 64 hex characters of text, no line end; the entry holds SHA-256 of that text,
//   an ECDSA P-256 signature over it, and the public key. The key is ONE key, kept by us and published, so that the
//   log shows who entered it. Every entry is permanent and public: send only on the founder's word for that run.
// What it does not show: that the script sent what the rig logged, or that an entry was true. A key on this box is as
// safe as the box.
const cp = require("child_process"), crypto = require("crypto");
const URL = "https://rekor.sigstore.dev/api/v1/log/entries";
const sha = (s) => crypto.createHash("sha256").update(s, "utf8").digest("hex");
// A new key pair, PEM. Made once by a person's word; the private part is never committed and never printed.
function newKey() { return crypto.generateKeyPairSync("ec", { namedCurve: "prime256v1", publicKeyEncoding: { type: "spki", format: "pem" }, privateKeyEncoding: { type: "pkcs8", format: "pem" } }); }
const publicOf = (privatePem) => crypto.createPublicKey(privatePem).export({ type: "spki", format: "pem" });
function body(sum, privatePem) {
  if (!/^[0-9a-f]{64}$/.test(sum)) throw new Error("not a checksum of 64 hex characters");
  const sig = crypto.sign("sha256", Buffer.from(sum, "utf8"), privatePem).toString("base64");
  return JSON.stringify({ apiVersion: "0.0.1", kind: "hashedrekord", spec: { data: { hash: { algorithm: "sha256", value: sha(sum) } },
    signature: { content: sig, publicKey: { content: Buffer.from(publicOf(privatePem)).toString("base64") } } } });
}
// What the log returns for one entry: { "<uuid>": { body (base64), logIndex, integratedTime, ... } }.
function entryOf(reply) { try { const [uuid, e] = Object.entries(reply)[0]; return { uuid, index: e.logIndex, at: e.integratedTime, spec: JSON.parse(Buffer.from(e.body, "base64").toString()).spec }; } catch { return null; } }
// Does a returned entry hold OUR checksum under OUR key, with a signature that verifies? Returns the reasons it does not.
function check(entry, sum, publicPem) {
  const why = []; if (!entry || !entry.spec) return ["no entry"];
  if (entry.spec.data.hash.value !== sha(sum)) why.push("the entry's hash is not the SHA-256 of our checksum");
  const pem = Buffer.from(entry.spec.signature.publicKey.content, "base64").toString();
  if (pem.replace(/\s/g, "") !== String(publicPem).replace(/\s/g, "")) why.push("the entry's key is not our published key");
  let ok = false; try { ok = crypto.verify("sha256", Buffer.from(sum, "utf8"), publicPem, Buffer.from(entry.spec.signature.content, "base64")); } catch { /* not verified */ }
  if (!ok) why.push("the signature does not verify under our key"); return why;
}
// One sending. Never throws: { ok, http, ms, raw, entry, error }. The log answers 201 for a new entry, 409 for one it holds.
function sendOnce(sum, privatePem, timeoutMs, url) {
  const t0 = Date.now();
  const r = cp.spawnSync("curl", ["-s", "-m", String(Math.ceil(timeoutMs / 1000)), "-w", "\n%{http_code}", url || URL, "-H", "content-type: application/json", "-H", "accept: application/json", "-d", "@-"],
    { input: body(sum, privatePem), encoding: "utf8", timeout: timeoutMs + 2000 });
  const ms = Date.now() - t0, all = String(r.stdout || ""), cut = all.lastIndexOf("\n"), raw = cut < 0 ? "" : all.slice(0, cut), http = parseInt(all.slice(cut + 1), 10) || 0;
  if (r.status !== 0) return { ok: false, http, ms, raw, entry: null, error: "curl ended " + r.status };
  let reply = null; try { reply = JSON.parse(raw); } catch { /* not JSON */ }
  const entry = http === 201 ? entryOf(reply) : null;
  return { ok: !!entry, http, ms, raw, entry, error: entry ? null : "http " + http };
}
module.exports = { URL, sha, newKey, publicOf, body, entryOf, check, sendOnce };
