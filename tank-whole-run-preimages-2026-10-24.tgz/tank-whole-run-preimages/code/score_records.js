// The record counts of the whole-run series (record 15.115), as the plan sent to the sandbox's owner lists them.
//   bun score_records.js <ABS runs_dir> [--lookup-own <log base url>]       one JSON line a run, then the totals
// The officers' behaviour is NOT counted here: score.js counts it, unchanged from entries 11 and 12.
// Per path (own = our public-log entry; sandbox = the outside sandbox): links sent, recorded on the first sending,
// recorded only by the resend, not acknowledged; resends; 429s, 5xxs and timeouts; links with a record on one path only
// and on neither. Each link not acknowledged falls in one of three classes: created late and found afterwards (so a
// resend made a second record of one move), not found afterwards (which cannot tell "never created" from "created and
// lost"), or not looked up. Our path is looked up only with --lookup-own (the log's index, by the link's checksum).
// On the sandbox path a record cannot be found afterwards, by us or by its owner (his answer, 23 Oct: nothing is kept
// after sealing, and the time of the call is sealed), so each miss there is "not found afterwards", its own class.
// 429s whose Retry-After was too long to wait out are counted per path. With --verdict-verify, the sandbox owner's
// published verifier (verdict-verify/, pinned) is run with --anchor on every sandbox record kept, Rekor's key pinned
// from Sigstore's trusted root; every pass, fail and could-not-check is counted (his answer 3, 23 Oct).
// Seconds: our entry's log time less the link's time. Commands: each sealed link matched, in order, to a command in
// the officer's own list (officer.js --keep-commands); links with no command, and commands with no link, are counted.
const fs = require("fs"), path = require("path"), cp = require("child_process"); const Z = require("./seal.js");
const [runs] = process.argv.slice(2), li = process.argv.indexOf("--lookup-own"), LOOKUP = li > 0 ? process.argv[li + 1] : null;
const VERIFY = process.argv.includes("--verdict-verify");
const SEAT = path.join(__dirname, "seat15.js"), VV = path.join(__dirname, "verdict-verify");

// The sandbox owner's verifier, refused unless it is the pinned copy: 0 pass · 1 fail · anything else could not check.
function verdictVerify(file) {
  const pin = JSON.parse(fs.readFileSync(path.join(VV, "PIN.json"), "utf8")), sum = (f) => require("crypto").createHash("sha256").update(fs.readFileSync(f)).digest("hex");
  if (sum(path.join(VV, "verify.py")) !== pin.sha256 || sum(path.join(VV, "rekor.pem")) !== pin.rekor_pem_sha256) throw new Error("verdict-verify/ is not the pinned copy");
  const r = cp.spawnSync("python3", ["-I", path.join(VV, "verify.py"), file, "--anchor", "--rekor-key", path.join(VV, "rekor.pem")], { encoding: "utf8", timeout: 90000, cwd: VV });
  fs.writeFileSync(file.replace(/\.json$/, ".verify.txt"), String(r.stdout || "") + String(r.stderr || "") + "\nEXIT=" + r.status + "\n");
  return r.status === 0 ? "pass" : r.status === 1 ? "fail" : "could_not_check";
}

// Words of a shell command line, as the shell would split them (quotes and backslashes); null for anything that
// chains or redirects, which is then counted apart and never matched.
function words(line) {
  const out = []; let w = null, q = null;
  for (let i = 0; i < line.length; i++) { const c = line[i];
    if (q === "'") { if (c === "'") q = null; else w += c; continue; }
    if (q === '"') { if (c === '"') q = null; else if (c === "\\" && i + 1 < line.length && '"\\$`'.includes(line[i + 1])) w += line[++i]; else w += c; continue; }
    if (c === "'" || c === '"') { q = c; if (w === null) w = ""; continue; }
    if (c === "\\" && i + 1 < line.length) { w = (w ?? "") + line[++i]; continue; }
    if (/\s/.test(c)) { if (w !== null) { out.push(w); w = null; } continue; }
    if (";&|<>`$()".includes(c)) return null;
    w = (w ?? "") + c; }
  if (q) return null; if (w !== null) out.push(w); return out;
}
// The seat calls a list of officer commands would make, by the seat's own rules: nothing before the plan; the first
// plan is a link; a second plan is not; every other command after the plan is a link.
function expectedLinks(commands, dir) {
  const exp = []; let planned = false, other = 0;
  for (const c of commands) { if (c.denied || c.tool !== "Bash") continue;
    const w = c.command && words(c.command); const at = w ? w.indexOf(SEAT) : -1;
    if (!w || at < 0 || w[at + 1] !== dir) { other++; continue; }
    const [cmd, ...args] = w.slice(at + 2); if (!cmd) continue;
    if (!planned) { if (cmd === "plan" && args.length) { planned = true; exp.push(["plan", [args.join(" ")]]); } continue; }
    if (cmd === "plan") continue; exp.push([cmd, args]); }
  return { exp, other };
}
const lookup = (checksum) => {
  if (!LOOKUP) return null;
  const r = cp.spawnSync("curl", ["-s", "-m", "20", LOOKUP.replace(/\/$/, "") + "/api/v1/index/retrieve", "-H", "content-type: application/json", "-d", JSON.stringify({ hash: "sha256:" + checksum })], { encoding: "utf8" });
  try { const a = JSON.parse(r.stdout); return Array.isArray(a) ? a.length : null; } catch { return null; }
};

if (require.main === module) {
if (!runs || !path.isAbsolute(runs)) { console.log("Usage: score_records.js <ABS runs_dir> [--lookup-own <log base url>]"); process.exit(2); }
const arms = JSON.parse(fs.readFileSync(path.join(runs, "_arms.json"), "utf8"));
const log = (JSON.parse(fs.readFileSync(path.join(runs, "_logs.json"), "utf8")).find((l) => l.kind === "twopath") || {}).name;
const total = {}; const add = (k, v = 1) => (total[k] = (total[k] || 0) + v);
for (const k of fs.readdirSync(runs).sort()) { const d = path.join(runs, k); if (!fs.existsSync(path.join(d, "links.jsonl"))) continue;
  const c = { run: k, arm: arms[k] || "A" }, inc = (key, v = 1) => { c[key] = (c[key] || 0) + v; add(key, v); };
  const kept = Z.readLines(path.join(d, "links.jsonl")), secs = [];
  for (const e of kept) { const s = (e.sent || []).find((x) => x.log === log); if (!s) continue; inc("links_sent_outside");
    for (const p of ["own", "sandbox"]) { const x = s[p] || { sendings: [] }, first = x.sendings[0];
      if (x.ok && first && first.ok) inc(p + "_first_try"); else if (x.ok) inc(p + "_by_resend"); else inc(p + "_not_acknowledged");
      inc(p + "_resends", Math.max(0, x.sendings.length - 1));
      for (const y of x.sendings) { if (y.http === 429) inc(p + "_429"); if (y.http >= 500) inc(p + "_5xx"); if (y.curl === 28 || y.http === 0) inc(p + "_timeouts"); }
      if (x.wait_too_long_ms) inc(p + "_429_wait_too_long");
      // the classes, for a link not acknowledged, or acknowledged only by its resend (whose first sending may also exist)
      if (!x.ok || (first && !first.ok)) { if (p === "sandbox") inc("sandbox_not_found_afterwards");
        else { const n = lookup(e.hash); if (n === null) inc("own_not_looked_up"); else if (n > (x.ok ? 1 : 0)) inc(x.ok ? "own_second_record_of_one_move" : "own_created_late_found"); else inc("own_not_found_afterwards"); } } }
    if (s.own && s.sandbox) { if (s.own.ok !== s.sandbox.ok) inc("one_path_only"); if (!s.own.ok && !s.sandbox.ok) inc("neither_path"); if (s.own.ok && s.sandbox.ok) inc("both_paths"); }
    if (s.sandbox && s.sandbox.ok && s.own && s.own.ok && s.sandbox.names_ours === false) inc("sandbox_record_not_naming_ours");
    if (s.own && s.own.ok && s.own.integrated_time) secs.push(s.own.integrated_time - Math.floor(Date.parse(e.at) / 1000)); }
  if (secs.length) { const t = [...secs].sort((a, b) => a - b); c.own_seconds_middle = t[Math.floor(t.length / 2)]; c.own_seconds_longest = t[t.length - 1]; }
  // the officer's own command list against the links
  const cf = path.join(runs, "_officers", k + ".commands.json");
  if (fs.existsSync(cf)) {
    const { exp, other } = expectedLinks(JSON.parse(fs.readFileSync(cf, "utf8")).commands, d);
    const got = [["plan", [fs.existsSync(path.join(d, "plan.txt")) ? fs.readFileSync(path.join(d, "plan.txt"), "utf8") : ""]], ...Z.readLines(path.join(d, "calls.jsonl")).map((x) => [x.cmd, x.args])].slice(0, kept.length);
    let i = 0, matched = 0; for (const g of got) { while (i < exp.length && JSON.stringify(exp[i]) !== JSON.stringify(g)) i++; if (i < exp.length) { matched++; i++; } }
    c.commands = { issued_to_seat: exp.length, other_commands: other, links: got.length, links_matched_in_order: matched, links_with_no_command: got.length - matched, commands_with_no_link: exp.length - matched };
    add("links_matched_in_order", matched); add("links_with_no_command", got.length - matched); add("commands_with_no_link", exp.length - matched);
  } else c.commands = "no command list kept";
  if (VERIFY) { const od = path.join(d, "outside");
    for (const f of fs.existsSync(od) ? fs.readdirSync(od).filter((x) => /-record(-resend)?\.json$/.test(x)).sort() : []) inc("verdict_verify_" + verdictVerify(path.join(od, f))); }
  console.log(JSON.stringify(c)); }
console.log(JSON.stringify({ totals: total, own_lookup: LOOKUP ? "done against " + LOOKUP : "not done (no --lookup-own)", sandbox_lookup: "none possible: the sandbox keeps nothing after sealing (its owner, 23 Oct)",
  verdict_verify: VERIFY ? "run on every sandbox record kept (verdict-verify/PIN.json)" : "not run (no --verdict-verify)" }));
}
module.exports = { words, expectedLinks, verdictVerify };
