#!/usr/bin/env python3
"""Reference verifier for SER v0.1 (Sealed Evidence Record). Standard library only.

Usage:
  verify.py record.json            offline self-consistency checks
  verify.py record.json --anchor   also confirm the Sigstore Rekor anchor (network)
      --rekor-key rekor.pem        pin Rekor's public key instead of fetching it from the log
      --rekor-entry entry.json     use a saved Rekor entry instead of fetching it (needs --rekor-key;
                                   with both, --anchor runs offline)
  verify.py --vectors vectors/ser-v0.1-vectors.json   reproduce every frozen vector
  verify.py --chain r1.json r2.json ...   records in chain order: each self-consistent, each
                                   record.metadata.prior_merkle_root names the previous record's
                                   commitment, metadata.step runs 1..N, and a declared metadata.of
                                   matches the number of records
      --anchor, --rekor-key        as above, for every record; give --rekor-entry once per record
      --head head.json             a separately held head record (metadata.chain_head) that the set
                                   must reach and agree with

Exit code 0 = every check passed, 1 = a check failed, 2 = usage.
"""
import base64, datetime, hashlib, json, math, re, subprocess, sys, tempfile, urllib.request

SCHEMA = "ser.v0.1.legal_ai_output"
DOMAIN = "verdict-ser-v0.1"
MAX_DEPTH = 50

class CanonicalError(ValueError):
    """The value has no SER v0.1 canonical form (SPEC.md §4.5)."""

def canonical(obj) -> str:
    """SER v0.1 canonical form (SPEC.md §4), byte-identical to the frozen TypeScript
    stableStringify. json.dumps is not a substitute: it sorts keys by code point,
    formats floats differently and has no depth limit (see the §4 erratum)."""
    return _canon(obj, 0)

def _canon(v, depth: int) -> str:
    if depth > MAX_DEPTH:                   # §4.5, checked for every value as stableStringify does
        raise CanonicalError(f"depth {depth}")
    if v is None: return "null"
    if v is True: return "true"
    if v is False: return "false"
    if isinstance(v, (int, float)): return _number(v)
    if isinstance(v, str): return _string(v)
    if isinstance(v, list):
        return "[" + ",".join(_canon(x, depth + 1) for x in v) + "]"
    if isinstance(v, dict):                 # §4.1: UTF-16 code-unit order, what JavaScript's < compares
        keys = sorted(v, key=lambda k: k.encode("utf-16-be", "surrogatepass"))
        return "{" + ",".join(_string(k) + ":" + _canon(v[k], depth + 1) for k in keys) + "}"
    raise TypeError(f"not a JSON value: {v!r}")

def _number(x) -> str:
    """ECMAScript Number::toString (§4.4). JSON numbers are IEEE-754 doubles, as JSON.parse reads them."""
    try:
        x = float(x)
    except OverflowError:                   # integer literal beyond double range: JSON.parse gives ±Infinity
        x = math.inf if x > 0 else -math.inf
    if not math.isfinite(x): return "null"  # JSON.stringify(NaN), JSON.stringify(±Infinity)
    if x == 0: return "0"                   # includes -0
    if x < 0: return "-" + _number(-x)
    # repr gives the shortest round-trip digits; recover s (k digits) and n with x = 0.s × 10^n
    mant, _, exp = repr(x).partition("e")
    whole, _, frac = mant.partition(".")
    digits = (whole + frac).lstrip("0")
    n = len(digits) - len(frac) + int(exp or 0)
    s = digits.rstrip("0"); k = len(s)
    if k <= n <= 21: return s + "0" * (n - k)
    if 0 < n <= 21: return s[:n] + "." + s[n:]
    if -6 < n <= 0: return "0." + "0" * -n + s
    e = n - 1
    return (s if k == 1 else s[0] + "." + s[1:]) + ("e+" if e >= 0 else "e-") + str(abs(e))

_ESCAPE = re.compile(r'["\\\x00-\x1f\ud800-\udfff]')
_SHORT = {'"': '\\"', "\\": "\\\\", "\b": "\\b", "\t": "\\t", "\n": "\\n", "\f": "\\f", "\r": "\\r"}

def _string(s: str) -> str:
    """ECMAScript JSON.stringify of a string (§4.3): short escapes, other C0 controls and lone
    surrogates as lowercase \\uXXXX, every other code point raw (including U+007F, U+2028, U+2029)."""
    return '"' + _ESCAPE.sub(lambda m: _SHORT.get(m[0]) or f"\\u{ord(m[0]):04x}", s) + '"'

def _reject_constant(name):
    raise ValueError(f"{name} is not JSON (RFC 8259)")

def load_json(path: str):
    """Read a file the way JSON.parse would: UTF-8, and NaN / Infinity rejected."""
    with open(path, encoding="utf-8") as f:
        return json.load(f, parse_constant=_reject_constant)

def sha256_hex(s: str) -> str:
    return hashlib.sha256(s.encode("utf-8")).hexdigest()

def derive(record: dict) -> dict:
    c = canonical(record)
    payload_hash = sha256_hex(c)
    commitment = sha256_hex(f"{DOMAIN}:{payload_hash}")
    return {
        "canonical": c,
        "payload_hash": payload_hash,
        "merkle_root": commitment,           # wire-format name of the record commitment
        "evidence_record_id": f"ser_{payload_hash[:32]}",
    }

def check_offline(ser: dict) -> list:
    try:
        d = derive(ser["record"])
    except CanonicalError as e:
        return [("canonical_form", f"depth <= {MAX_DEPTH} (SPEC.md §4.5)", e, False)]
    checks = [
        ("schema_version", SCHEMA, ser.get("schema"), ser.get("schema") == SCHEMA and ser["record"].get("schema") == SCHEMA),
        ("payload_hash", d["payload_hash"], ser.get("payload_hash"), d["payload_hash"] == ser.get("payload_hash")),
        ("record_commitment", d["merkle_root"], ser.get("merkle_root"), d["merkle_root"] == ser.get("merkle_root")),
        ("evidence_record_id", d["evidence_record_id"], ser.get("evidence_record_id"), d["evidence_record_id"] == ser.get("evidence_record_id")),
    ]
    return checks

REKOR_API = "https://rekor.sigstore.dev/api/v1"

def fetch(url: str) -> bytes:
    req = urllib.request.Request(url, headers={"User-Agent": "ser-spec-verify/0.1"})
    with urllib.request.urlopen(req, timeout=30) as r:
        return r.read()

def openssl_verify(pub_pem: bytes, sig: bytes, data: bytes) -> tuple:
    """ECDSA/SHA-256 signature check via openssl. Returns (ok, openssl's message)."""
    with tempfile.TemporaryDirectory() as t:
        for name, content in (("pub.pem", pub_pem), ("sig.der", sig), ("data", data)):
            with open(f"{t}/{name}", "wb") as f:
                f.write(content)
        r = subprocess.run(["openssl", "dgst", "-sha256", "-verify", f"{t}/pub.pem", "-signature", f"{t}/sig.der", f"{t}/data"],
                           capture_output=True, text=True)
    return r.returncode == 0, r.stdout.strip() or r.stderr.strip()

def pem_der(pem: bytes) -> bytes:
    """SubjectPublicKeyInfo DER from a PEM public key."""
    return base64.b64decode("".join(l for l in pem.decode().splitlines() if not l.startswith("-----")), validate=True)

def merkle_root_from_proof(leaf: bytes, index: int, size: int, path: list):
    """RFC 9162 §2.1.3.2: the root an inclusion proof implies, or None if the proof is malformed."""
    if not 0 <= index < size: return None
    fn, sn, r = index, size - 1, leaf
    for p in path:
        if sn == 0: return None
        if fn & 1 or fn == sn:
            r = hashlib.sha256(b"\x01" + p + r).digest()
            while not fn & 1 and fn != 0:
                fn >>= 1; sn >>= 1
        else:
            r = hashlib.sha256(b"\x01" + r + p).digest()
        fn >>= 1; sn >>= 1
    return r if sn == 0 else None

def _guard(name, expected, fn):
    """Run one check; malformed input fails the check instead of crashing the verifier."""
    try:
        actual, passed = fn()
    except Exception as e:
        actual, passed = f"error: {type(e).__name__}: {e}", False
    return (name, expected, actual, passed)

def check_anchor(ser: dict, entry_doc: dict = None, rekor_key: bytes = None) -> list:
    """entry_doc: a saved GET /log/entries/<uuid> response (fetched when None).
    rekor_key: Rekor's PEM public key, pinned by the caller (fetched from the log when None)."""
    a = ser.get("transparency_anchor")
    if not a or a.get("status") != "anchored":
        return [("anchor_present", "anchored", (a or {}).get("status"), False)]
    # SPEC.md §7: check the log against the commitment recomputed from `record`, never the envelope's
    # merkle_root. Otherwise a log entry can confirm a commitment the record does not produce.
    try:
        commitment = derive(ser["record"])["merkle_root"]
    except (CanonicalError, KeyError, TypeError, ValueError) as e:
        return [("anchor_commitment", "commitment recomputed from record (SPEC.md §7)", f"error: {type(e).__name__}: {e}", False)]
    expected_leaf = sha256_hex(commitment)   # Rekor hashedrekord stores sha256 of the commitment bytes
    url = a["rekor_url"]
    uuid = url.rstrip("/").split("/")[-1]
    if entry_doc is None:
        entry_doc = json.loads(fetch(f"{REKOR_API}/log/entries/{uuid}"))
    if uuid not in entry_doc:
        return [("rekor_entry_uuid", uuid, ",".join(entry_doc), False)]
    entry = entry_doc[uuid]
    body = json.loads(base64.b64decode(entry["body"]))
    logged = body["spec"]["data"]["hash"]["value"]
    checks = [("rekor_hash_matches_commitment", expected_leaf, logged, logged == expected_leaf),
              ("rekor_log_index", str(a.get("rekor_log_index")), str(entry.get("logIndex")), str(entry.get("logIndex")) == str(a.get("rekor_log_index")))]
    # signature over the commitment bytes, public key embedded in the log entry
    pub = base64.b64decode(body["spec"]["signature"]["publicKey"]["content"])
    sig = base64.b64decode(body["spec"]["signature"]["content"])
    ok, msg = openssl_verify(pub, sig, commitment.encode())
    checks.append(("rekor_signature_over_commitment", "Verified OK", msg, ok))
    # the key the file displays must be the key the log holds (same SPKI DER); keys are still unbound (§7)
    shown = a.get("public_key_pem")
    try:
        same = shown is not None and pem_der(shown.encode()) == pem_der(pub)
    except Exception:
        same = False
    checks.append(("displayed_key_matches_log_key", hashlib.sha256(pem_der(pub)).hexdigest()[:16],
                   (hashlib.sha256(pem_der(shown.encode())).hexdigest()[:16] if shown else "absent"), same))
    checks.append(("rekor_integrated_time", "present", str(entry.get("integratedTime")), entry.get("integratedTime") is not None))
    return checks + check_log_signatures(entry, rekor_key)

def check_log_signatures(entry: dict, rekor_key: bytes = None) -> list:
    """The log's own signatures over the entry: without these, integratedTime and inclusion
    rest on trusting whoever answered the API request."""
    source = "pinned key"
    if rekor_key is None:
        rekor_key, source = fetch(f"{REKOR_API}/log/publicKey"), "key fetched from the log"
    key_id = hashlib.sha256(pem_der(rekor_key)).hexdigest()   # Rekor's logID is sha256 of its SPKI DER
    v = entry.get("verification") or {}
    ip = v.get("inclusionProof") or {}
    checks = [("rekor_log_key_id", f"{key_id} ({source})", entry.get("logID"), entry.get("logID") == key_id)]

    def set_check():
        # signedEntryTimestamp: canonical JSON (sorted keys, no whitespace) of these four fields
        payload = json.dumps({"body": entry["body"], "integratedTime": entry["integratedTime"],
                              "logID": entry["logID"], "logIndex": entry["logIndex"]},
                             sort_keys=True, separators=(",", ":")).encode()
        ok, msg = openssl_verify(rekor_key, base64.b64decode(v["signedEntryTimestamp"]), payload)
        return msg, ok
    checks.append(_guard("rekor_signed_entry_timestamp", "Verified OK", set_check))

    proof_root = {}
    def inclusion_check():
        leaf = hashlib.sha256(b"\x00" + base64.b64decode(entry["body"])).digest()   # RFC 6962 leaf hash
        root = merkle_root_from_proof(leaf, ip["logIndex"], ip["treeSize"], [bytes.fromhex(h) for h in ip["hashes"]])
        proof_root["hex"] = root.hex() if root else None
        return (proof_root["hex"] or "malformed proof"), root is not None and root.hex() == ip["rootHash"]
    checks.append(_guard("rekor_inclusion_proof", ip.get("rootHash"), inclusion_check))

    checkpoint = {}
    def checkpoint_sig_check():
        # signed note: body text, blank line, then "— <name> <base64(4-byte key hint || DER signature)>"
        text, _, sigs = ip["checkpoint"].partition("\n\n")
        lines = text.split("\n")
        checkpoint.update(size=int(lines[1]), root=base64.b64decode(lines[2], validate=True).hex())
        for line in sigs.splitlines():
            if not line.startswith("\u2014 "): continue
            raw = base64.b64decode(line.split(" ", 2)[2], validate=True)
            if raw[:4] == bytes.fromhex(key_id)[:4]:
                ok, msg = openssl_verify(rekor_key, raw[4:], (text + "\n").encode())
                return msg, ok
        return "no signature line for this key", False
    checks.append(_guard("rekor_checkpoint_signature", "Verified OK", checkpoint_sig_check))

    def checkpoint_covers_proof():
        want = f"size={ip['treeSize']} root={proof_root.get('hex')}"
        got = f"size={checkpoint['size']} root={checkpoint['root']}"
        return got, got == want and proof_root.get("hex") is not None
    checks.append(_guard("rekor_checkpoint_matches_proof", f"size={ip.get('treeSize')} root={proof_root.get('hex')}", checkpoint_covers_proof))
    return checks

HEX64 = re.compile(r"[0-9a-f]{64}")

def _positive_int(v) -> bool:
    """A step or length as the seal tool reads it: JavaScript Number.isInteger(v) && v >= 1."""
    return (isinstance(v, (int, float)) and not isinstance(v, bool) and math.isfinite(v)
            and float(v).is_integer() and v >= 1)

def _metadata(ser) -> dict:
    record = ser.get("record") if isinstance(ser, dict) else None
    meta = record.get("metadata") if isinstance(record, dict) else None
    return meta if isinstance(meta, dict) else {}

def _commitment(ser):
    """The commitment recomputed from `record`, or None when the record has no canonical form."""
    try:
        return derive(ser["record"])["merkle_root"]
    except Exception:
        return None

def _gaps(present: set, upto: int) -> list:
    """Ranges of steps in 1..upto that are not in present, without enumerating 1..upto."""
    gaps, nxt = [], 1
    for s in sorted(p for p in present if p <= upto):
        if s > nxt: gaps.append((nxt, s - 1))
        nxt = max(nxt, s + 1)
    if nxt <= upto: gaps.append((nxt, upto))
    return gaps

def _utc(t) -> str:
    return datetime.datetime.fromtimestamp(t, datetime.timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")

def _record_checks(label: str, ser, anchor: bool, entry_docs, rekor_key) -> tuple:
    """Single-record checks under a [label] prefix, and the Rekor integratedTime when anchored."""
    try:
        checks = check_offline(ser)
    except Exception as e:
        checks = [("envelope", "SER envelope object (SPEC.md §1)", f"error: {type(e).__name__}: {e}", False)]
    when = None
    if anchor:
        try:
            uuid = ser["transparency_anchor"]["rekor_url"].rstrip("/").split("/")[-1]
            doc = entry_docs if entry_docs is not None else json.loads(fetch(f"{REKOR_API}/log/entries/{uuid}"))
            checks += check_anchor(ser, doc, rekor_key)
            when = (doc.get(uuid) or {}).get("integratedTime")
        except Exception as e:
            checks.append(("anchor", "an anchored Rekor entry (SPEC.md §6)", f"error: {type(e).__name__}: {e}", False))
    return [(f"[{label}] {n}", exp, act, ok) for n, exp, act, ok in checks], when

def _why_unlinked(i: int, prior, commits: list, claimed: list) -> str:
    """Why record [i]'s pointer does not name record [i-1]'s recomputed commitment."""
    if prior is None:
        return f"absent: [{i}] names no prior, so it starts another chain"
    if not isinstance(prior, str) or not HEX64.fullmatch(prior):
        return f"malformed pointer {json.dumps(prior)[:80]} (expected 64 lowercase hex)"
    if commits[i - 1] is not None and commits[i - 1] == commits[i - 2]:
        return f"[{i}] is the same record as [{i - 1}]: duplicated"
    for k, c in enumerate(commits, 1):
        if c == prior:
            return f"names [{k}]: records are out of order"
    if claimed[i - 2] == prior:
        return (f"names the commitment [{i - 1}] claims, which its content no longer produces: "
                f"[{i - 1}] was changed after [{i}] was sealed")
    return (f"{prior[:16]}... is not the commitment of [{i - 1}] or of any record in this set: a record between "
            f"[{i - 1}] and [{i}] is missing, [{i - 1}] was changed and re-derived, or [{i}] belongs to another chain")

def check_chain(sers: list, anchor: bool = False, entry_docs: dict = None, rekor_key: bytes = None, head: dict = None) -> list:
    """Records in chain order (step 1 first). Each must pass the single-record checks, each record's
    metadata.prior_merkle_root must equal the commitment recomputed from the record before it (never
    that record's envelope merkle_root, for the reason SPEC.md §7 gives for the anchor), and
    metadata.step must run 1..N. entry_docs: saved Rekor entries merged into one {uuid: entry} map
    (fetched per record when None). head: a head record (see check_head), held apart from the set."""
    if not sers:
        return [("chain records", ">= 1", 0, False)]
    checks, times = [], []
    for i, ser in enumerate(sers, 1):
        c, when = _record_checks(str(i), ser, anchor, entry_docs, rekor_key)
        checks += c; times.append(when)
    commits = [_commitment(s) for s in sers]
    claimed = [s.get("merkle_root") if isinstance(s, dict) else None for s in sers]
    metas = [_metadata(s) for s in sers]

    first_prior = metas[0].get("prior_merkle_root")
    if first_prior is None:
        why = "no prior: step 1 starts the chain"
    elif first_prior in commits:
        why = f"names [{commits.index(first_prior) + 1}] as its prior: records are out of order"
    else:
        why = "names a prior that is not in this set: the records before it were not supplied"
    checks.append(("[1] chain_start", "no prior_merkle_root", why, first_prior is None))

    for i, meta in enumerate(metas, 1):
        step = meta.get("step")
        checks.append((f"[{i}] step", str(i), "absent" if "step" not in meta else json.dumps(step),
                       _positive_int(step) and step == i))
        if i == 1: continue
        prior = meta.get("prior_merkle_root")
        linked = commits[i - 2] is not None and prior == commits[i - 2]
        checks.append((f"[{i - 1}->{i}] prior_merkle_root", commits[i - 2] or "commitment of the previous record",
                       prior if linked else _why_unlinked(i, prior, commits, claimed), linked))
        if anchor:
            t0, t1 = times[i - 2], times[i - 1]
            in_order = t0 is not None and t1 is not None and t0 <= t1
            checks.append((f"[{i - 1}->{i}] log_time_order", f"[{i - 1}] logged no later than [{i}]",
                           f"{_utc(t0)} -> {_utc(t1)}" if t0 is not None and t1 is not None else "integratedTime unavailable",
                           in_order))

    declared = [m["of"] for m in metas if "of" in m]
    if declared:
        first = declared[0]
        agree = all(_positive_int(v) and v == first for v in declared)
        checks.append(("chain declared_length", f"{int(first)} of {int(first)}" if agree else "one integer >= 1 on every record that declares metadata.of",
                       f"{len(sers)} of {int(first)}" if agree else "declared " + ", ".join(json.dumps(v) for v in declared),
                       agree and len(sers) == first))
    if head is not None:
        checks += check_head(head, sers, commits, metas, times, anchor, entry_docs, rekor_key)
    return checks

def check_head(head: dict, sers: list, commits: list, metas: list, times: list,
               anchor: bool = False, entry_docs: dict = None, rekor_key: bytes = None) -> list:
    """A head record is an ordinary SER record whose record.metadata.chain_head is
    {"genesis": <step 1 commitment>, "step": N, "merkle_root": <step N commitment>}. Held apart from
    the set, it makes a set that stops before step N, or differs from the chain at step N, fail."""
    checks, head_time = _record_checks("head", head, anchor, entry_docs, rekor_key)
    h = _metadata(head).get("chain_head")
    valid = (isinstance(h, dict) and _positive_int(h.get("step"))
             and all(isinstance(h.get(k), str) and HEX64.fullmatch(h[k]) for k in ("genesis", "merkle_root")))
    checks.append(("[head] chain_head", "{genesis, step, merkle_root} (64-hex commitments, step >= 1)",
                   "absent" if h is None else json.dumps(h)[:160], valid))
    if not valid:
        return checks
    n = int(h["step"])
    checks.append(("[head] genesis", h["genesis"], commits[0], commits[0] == h["genesis"]))
    present = {int(m["step"]) for m in metas if _positive_int(m.get("step"))}
    gaps = _gaps(present, n)
    checks.append(("[head] covers_step", f"steps 1..{n} in the set",
                   f"steps 1..{n} present" if not gaps else "steps " + ", ".join(
                       str(a) if a == b else f"{a}..{b}" for a, b in gaps) + f" of 1..{n} are not in the set",
                   not gaps))
    at = next((i for i, m in enumerate(metas) if _positive_int(m.get("step")) and m["step"] == n), None)
    got = commits[at] if at is not None else f"no record at step {n}"
    checks.append(("[head] merkle_root", h["merkle_root"],
                   got if at is None or got == h["merkle_root"] else
                   f"{got} (a different record from the one the head committed to: the chain was rewritten at or before step {n})",
                   at is not None and got == h["merkle_root"]))
    if anchor:
        t = times[at] if at is not None else None
        ok = t is not None and head_time is not None and t <= head_time
        checks.append(("[head] log_time_order", f"step {n} logged no later than the head",
                       f"{_utc(t)} -> {_utc(head_time)}" if t is not None and head_time is not None else "integratedTime unavailable", ok))
    return checks

def report(checks) -> bool:
    ok = True
    for name, expected, actual, passed in checks:
        ok &= bool(passed)
        print(f"{'PASS' if passed else 'FAIL'}  {name:34s} expected={expected}  actual={actual}")
    return ok

def run_vectors(path: str) -> bool:
    v = load_json(path)
    ok = True
    for vec in v["vectors"]:
        rec = build_record(vec["input"], vec["received_at"])
        d = derive(rec)
        for k in ("canonical", "payload_hash", "merkle_root", "evidence_record_id"):
            p = d[k] == vec["expected"][k]
            ok &= p
            if not p:
                print(f"FAIL  {vec['name']}.{k}\n  expected={vec['expected'][k]}\n  actual  ={d[k]}")
    print(f"{'PASS' if ok else 'FAIL'}  {len(v['vectors'])} vectors, schema {v['schema']}, domain {v['domain_separator']}")
    return ok

def build_record(inp: dict, received_at: str) -> dict:
    """Mirror of sealRecord()'s record construction (defaults applied, key order irrelevant)."""
    return {
        "schema": SCHEMA,
        "matter_id": inp["matter_id"],
        "workflow": inp["workflow"],
        "input_summary": inp["input_summary"],
        "output_summary": inp["output_summary"],
        "human_review_status": inp["human_review_status"],
        "attorney_reviewer": inp.get("attorney_reviewer"),
        "model_provider": inp.get("model_provider") or "unknown",
        "model": inp.get("model"),
        "prompt_hash": inp.get("prompt_hash"),
        "output_hash": inp.get("output_hash"),
        "source_system": inp.get("source_system") or "unknown",
        "citations": inp.get("citations") or [],
        "risk_flags": inp.get("risk_flags") or [],
        "metadata": inp.get("metadata") or {},
        "event_time": inp.get("event_time"),
        "received_at": received_at,
    }

def option(args: list, name: str):
    if name not in args: return None
    i = args.index(name)
    if i + 1 >= len(args):
        print(__doc__); sys.exit(2)
    return args[i + 1]

COVERED = {"schema", "evidence_record_id", "payload_hash", "merkle_root", "record", "transparency_anchor"}

def run_chain(args: list) -> int:
    files, values, anchor, i = [], {}, False, 0
    while i < len(args):
        a = args[i]
        if a in ("--rekor-key", "--rekor-entry", "--head"):
            if i + 1 >= len(args) or (a != "--rekor-entry" and a in values):
                print(__doc__); return 2
            values.setdefault(a, []).append(args[i + 1]); i += 2
        elif a == "--anchor":
            anchor = True; i += 1
        elif a.startswith("--"):
            print(__doc__); return 2
        else:
            files.append(a); i += 1
    key_path = (values.get("--rekor-key") or [None])[0]
    if not files:
        print("--chain needs the record files in chain order\n" + __doc__); return 2
    if values.get("--rekor-entry") and not key_path:
        print("--rekor-entry needs --rekor-key: an offline check cannot fetch the log's key\n" + __doc__); return 2
    sers = []
    for n, path in enumerate(files, 1):
        try:
            sers.append(load_json(path))
        except (OSError, ValueError) as e:
            print(f"FAIL  [{n}] load  {path}: {e}\n\nRESULT: FAILED"); return 1
    head = None
    if values.get("--head"):
        try:
            head = load_json(values["--head"][0])
        except (OSError, ValueError) as e:
            print(f"FAIL  [head] load  {values['--head'][0]}: {e}\n\nRESULT: FAILED"); return 1
    entry_docs = None
    if values.get("--rekor-entry"):
        entry_docs = {}
        for path in values["--rekor-entry"]:
            entry_docs.update(load_json(path))
    rekor_key = open(key_path, "rb").read() if key_path and anchor else None
    checks = check_chain(sers, anchor, entry_docs, rekor_key, head)
    good = report(checks)
    loose = sorted({k for s in sers + ([head] if head else []) if isinstance(s, dict) for k in s if k not in COVERED})
    if loose:
        print("note: NOT covered by any hash or by the log, treat as unverified display text: " + ", ".join(loose) + " (SPEC.md §1)")
    n = len(sers)
    if not good:
        print("\nRESULT: FAILED (each FAIL line names the record [i] or the link [i-1->i] that failed)")
        return 1
    print(f"\nRESULT: chain of {n} record{'s' if n != 1 else ''} intact: each record self-consistent"
          + (" and anchored" if anchor else "") + f", each names the one before it, steps 1..{n} unbroken"
          + ("" if anchor else "; anchor not checked (run with --anchor)"))
    print(f"covers: every record from step 1 to step {n} is present and in the order supplied. A second record "
          "sealed off the same predecessor (a fork) is not visible to this check.")
    h = _metadata(head).get("chain_head") if head else None
    if any("of" in _metadata(s) for s in sers):
        print(f"tail: the records commit to a length of {n}, and {n} are present.")
    elif h:
        print(f"tail: the head record commits to step {int(h['step'])}; records sealed after it are not covered by it.")
    else:
        print(f"tail: nothing in this set shows whether records were sealed after step {n}; a declared length "
              "(metadata.of) or a separately held head record (--head) is needed for that.")
    print("not covered: an action that was never sealed leaves no record to check.")
    if anchor and not key_path:
        print("note: Rekor's public key was fetched from the log being checked; pin it with --rekor-key for an independent check")
    return 0

if __name__ == "__main__":
    args = sys.argv[1:]
    if not args:
        print(__doc__); sys.exit(2)
    if args[0] == "--vectors":
        sys.exit(0 if run_vectors(args[1]) else 1)
    if args[0] == "--chain":
        sys.exit(run_chain(args[1:]))
    ser = load_json(args[0])
    key_path, entry_path = option(args, "--rekor-key"), option(args, "--rekor-entry")
    if entry_path and not key_path:
        print("--rekor-entry needs --rekor-key: an offline check cannot fetch the log's key\n" + __doc__); sys.exit(2)
    checks = check_offline(ser)
    if "--anchor" in args:
        rekor_key = open(key_path, "rb").read() if key_path else None
        entry_doc = load_json(entry_path) if entry_path else None
        checks += check_anchor(ser, entry_doc, rekor_key)
    good = report(checks)
    covered = {"schema", "evidence_record_id", "payload_hash", "merkle_root", "record", "transparency_anchor"}
    loose = sorted(k for k in ser if k not in covered)
    if loose:
        print("note: NOT covered by any hash or by the log, treat as unverified display text: " + ", ".join(loose) + " (SPEC.md §1)")
    print("\nRESULT: " + ("content self-consistent" + (" and anchor confirmed" if "--anchor" in args else "; anchor not checked (run with --anchor)") if good else "FAILED"))
    if good and "--anchor" in args and not key_path:
        print("note: Rekor's public key was fetched from the log being checked; pin it with --rekor-key for an independent check")
    sys.exit(0 if good else 1)
